﻿#Requires AutoHotkey v2.0
#SingleInstance Force
Persistent
ListLines False
KeyHistory 0

SendMode "Event"
SetKeyDelay -1, -1
SetMouseDelay -1

OnError(LogUnhandledError)

#Include src\00-constants.ahk
#Include src\10-state.ahk
#Include src\20-persistence.ahk
#Include src\30-input-raw.ahk
#Include src\31-input-mouse.ahk
#Include src\33-native-mouse-hook-blob.ahk
#Include src\34-native-mouse-hook.ahk
#Include src\32-input-keyboard.ahk
#Include src\40-dispatch.ahk
#Include src\50-modifiers.ahk
#Include src\60-gui-main.ahk
#Include src\61-gui-profiles.ahk
#Include src\62-gui-macros.ahk
#Include src\63-gui-sniffer.ahk
#Include src\64-gui-scripts.ahk
#Include src\70-system.ahk
#Include src\90-migrate-legacy.ahk

UniqueMappingId(wantedId, extraTaken := "") {
    global mappings
    hasExtra := IsObject(extraTaken)
    cand := wantedId
    n := 2
    loop {
        if !mappings.Has(cand) && !(hasExtra && extraTaken.Has(cand))
            return cand
        cand := wantedId "#" n
        n++
    }
}

NewCaptureInputHook(onDown, onUp := (*) => {}, suppress := false) {
    ih := InputHook(suppress ? "" : "V")
    if suppress
        ih.VisibleNonText := false
    ih.KeyOpt("{All}", "N")
    ih.OnKeyDown := onDown
    ih.OnKeyUp := onUp
    ih.Start()
    return ih
}

StartupRunElevatedPref() {
    if FileExist(SettingsFile())
        return IniRead(SettingsFile(), "Settings", "RunElevated", "0")
    legacyMapFile := A_ScriptDir "\remote_mappings.ini"
    if FileExist(legacyMapFile)
        return IniRead(legacyMapFile, "Settings", "RunElevated", "0")
    return "0"
}
if StartupRunElevatedPref() = "1" && !A_IsAdmin
    RelaunchElevated()

ProcessSetPriority("AboveAverage", ProcessExist())

InitAll() {
    global mapFile := A_ScriptDir "\remote_mappings.ini"
    global DEVICE_TAGS := ["Mouse", "Keyboard", "Remote"]
    EnsureDataDirs()
    global RunAtStartupTaskName := "MF Button Mapper Startup"
    global loadCompleted := false
    global legacyLoadFailed := false
    global saveBlockedNotified := false
    global saveFailureNotified := false
    global failedLoadProfiles := Map()
    global failedProfileSaveNotified := Map()
    global mappings := Map()
    global mapOrder := []
    global masterEnabled := true
    global capturedSC := 0
    global startHidden := false
    global runElevated := false
    global runAtStartup := false
    global runAtStartupMode := "shortcut"
    global launchOnExitApps := [
        {name: "Logitech G Hub", key: "LogitechGHub", path: "C:\Program Files\LGHUB\system_tray\lghub_system_tray.exe --background"},
        {name: "Razer Synapse", key: "RazerSynapse", path: ""},
        {name: "Steel Series GG", key: "SteelSeriesGG", path: ""},
        {name: "Glorious CORE", key: "GloriousCORE", path: ""}
    ]
    global launchOnExitSelected := Map()
    for lApp in launchOnExitApps
        launchOnExitSelected[lApp.key] := false
    global suppressLaunchOnExit := false
    global terminateApps := [
        {name: "Logitech G Hub", key: "LogitechGHub", procs: ["lghub_agent.exe", "lghub_gl.exe", "lghub_system_tray.exe"]},
        {name: "Razer Synapse", key: "RazerSynapse", procs: []},
        {name: "Steel Series GG", key: "SteelSeriesGG", procs: []},
        {name: "Glorious CORE", key: "GloriousCORE", procs: []}
    ]
    global TerminateAppsForceAfterMs := 3000
    global terminateAppsSelected := Map()
    for tApp in terminateApps
        terminateAppsSelected[tApp.key] := false
    global terminateMenuX := 0
    global terminateMenuY := 0
    global launchMenuX := 0
    global launchMenuY := 0
    global targetSendString := ""
    global captureHook := ""
    global captureSuspended := false
    global captureSuspendDepth := 0
    global profiles := Map("Default", {processNames: []})
    global profileOrder := []
    global profileFiles := Map()
    global activeProfileNameByTab := Map("Mouse", "Default", "Keyboard", "Default", "Remote", "Default")
    global editingProfileName := "Default"
    global editingProfileNameByTab := Map("Mouse", "Default", "Keyboard", "Default", "Remote", "Default")
    global appWatchEnabled := false
    global g_lastCheckedExeName := "?unset?"
    global g_foregroundEventHook := 0
    global g_foregroundEventCallback := 0
    global g_minimizeEndEventHook := 0
    global g_minimizeEndEventCallback := 0
    global g_pendingRestoredHwnd := 0
    global g_pwPolls := 0
    global g_pwEvents := 0
    global g_pwSwitches := 0
    global g_pwLookupFailStreak := 0
    global disableMultiMapWarning := false
    global notifyModifierToggleByTag := Map("Mouse", false, "Keyboard", false, "Remote", false)
    global ledIndicatorChoiceByTag := Map("Mouse", "Off", "Keyboard", "Off", "Remote", "Off")
    global lockFlashEnabledByTagSlot := Map(
        "ScrollLock", Map("Mouse", Map(1, false, 2, false), "Keyboard", Map(1, false, 2, false), "Remote", Map(1, false, 2, false)),
        "CapsLock", Map("Mouse", Map(1, false, 2, false), "Keyboard", Map(1, false, 2, false), "Remote", Map(1, false, 2, false)),
        "NumLock", Map("Mouse", Map(1, false, 2, false), "Keyboard", Map(1, false, 2, false), "Remote", Map(1, false, 2, false))
    )
    global lockFlashIntervalMsByTagSlot := Map(
        "ScrollLock", Map("Mouse", Map(1, 500, 2, 500), "Keyboard", Map(1, 500, 2, 500), "Remote", Map(1, 500, 2, 500)),
        "CapsLock", Map("Mouse", Map(1, 500, 2, 500), "Keyboard", Map(1, 500, 2, 500), "Remote", Map(1, 500, 2, 500)),
        "NumLock", Map("Mouse", Map(1, 500, 2, 500), "Keyboard", Map(1, 500, 2, 500), "Remote", Map(1, 500, 2, 500))
    )
    global ledIndicatorChoiceByTag2 := Map("Mouse", "Off", "Keyboard", "Off", "Remote", "Off")
    global flashTimerFuncByTag := Map()
    global flashLedPhaseByTag := Map("Mouse", false, "Keyboard", false, "Remote", false)
    global capsLockLedDeviceIndex := 0
    global editingListName := "Main"
    global editingListNameByProfileKey := Map()
    global editingDevTab := "Remote"
    global profileTabButtons := []
    global profileTabStartIdx := 1
    global profileTabPageStack := []
    global profileTabDisabledHwnds := Map()
    global legacyLongPressMs := 500
    global buttonPressState := Map()
    global kbdListGateOn := true
    global kbdGateLatch := Map()
    global KBD_GATE_STALE_MS := 2000
    global lvColW1 := 43
    global lvColW2 := 169
    global lvColW3 := 206
    global lvColW4 := 66
    global macroLvColW1 := 30
    global macroLvColW2 := 85
    global macroLvColW3 := 335
    global macroLvColW4 := 100
    global captureModifierRawModeBySlot := Map("Mod", false, "Mod2", false)
    global modCaptureHookBySlot := Map("Mod", "", "Mod2", "")
    global modCaptureSuspendedBySlot := Map("Mod", false, "Mod2", false)
    global modRawCaptureArmedBySlot := Map("Mod", false, "Mod2", false)
    global modRawCaptureAwaitingReleaseBySlot := Map("Mod", false, "Mod2", false)
    global modRawCaptureDownHDeviceBySlot := Map("Mod", 0, "Mod2", 0)
    global modRawCaptureDownTickBySlot := Map("Mod", 0, "Mod2", 0)
    global modRawCaptureReleaseWindowTokenBySlot := Map("Mod", 0, "Mod2", 0)
    global modMouseCaptureCbs := Map()
    global modMouseCaptureArmed := false
    global CAPS_LOCK_LED_DEVICE_CHOICES := []
    loop 8
        CAPS_LOCK_LED_DEVICE_CHOICES.Push("KeyboardClass" (A_Index - 1))
    global deviceModifiers := Map(
        "Mouse",    {kind: "none", sc: 0, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: "toggle", lpOn: false, lpMs: 500, ptOn: false},
        "Keyboard", {kind: "none", sc: 0, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: "toggle", lpOn: false, lpMs: 500, ptOn: false},
        "Remote",   {kind: "none", sc: 0, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: "toggle", lpOn: false, lpMs: 500, ptOn: false}
    )
    global deviceModifiers2 := Map(
        "Mouse",    {kind: "none", sc: 0, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: "", lpOn: false, lpMs: 500, ptOn: false},
        "Keyboard", {kind: "none", sc: 0, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: "", lpOn: false, lpMs: 500, ptOn: false},
        "Remote",   {kind: "none", sc: 0, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: "", lpOn: false, lpMs: 500, ptOn: false}
    )
    global deviceModifiersBySlot := Map("Mod", deviceModifiers, "Mod2", deviceModifiers2)
    global mod1HeldByTag := Map("Mouse", false, "Keyboard", false, "Remote", false)
    global mod2HeldByTag := Map("Mouse", false, "Keyboard", false, "Remote", false)
    global modHeldByTagSlot := Map("Mod", mod1HeldByTag, "Mod2", mod2HeldByTag)
    global mod1ArmedRawByTag := Map("Mouse", {page: 0, upBytesHex: ""}, "Keyboard", {page: 0, upBytesHex: ""}, "Remote", {page: 0, upBytesHex: ""})
    global mod2ArmedRawByTag := Map("Mouse", {page: 0, upBytesHex: ""}, "Keyboard", {page: 0, upBytesHex: ""}, "Remote", {page: 0, upBytesHex: ""})
    global mod1ArmedScByTag := Map("Mouse", "", "Keyboard", "", "Remote", "")
    global mod2ArmedScByTag := Map("Mouse", "", "Keyboard", "", "Remote", "")
    global heldOwnerByTag := Map("Mouse", "", "Keyboard", "", "Remote", "")
    global mod1ComboUsedByTag := Map("Mouse", false, "Keyboard", false, "Remote", false)
    global mod2ComboUsedByTag := Map("Mouse", false, "Keyboard", false, "Remote", false)
    global modComboUsedByTagSlot := Map("Mod", mod1ComboUsedByTag, "Mod2", mod2ComboUsedByTag)
    global modLpPhysDownByTag := Map("Mouse", {Mod: false, Mod2: false}, "Keyboard", {Mod: false, Mod2: false}, "Remote", {Mod: false, Mod2: false})
    global modLpTokenByTag := Map("Mouse", {Mod: 0, Mod2: 0}, "Keyboard", {Mod: 0, Mod2: 0}, "Remote", {Mod: 0, Mod2: 0})
    global modLpPendingRawByTag := Map("Mouse", {Mod: "", Mod2: ""}, "Keyboard", {Mod: "", Mod2: ""}, "Remote", {Mod: "", Mod2: ""})
    global modPairStateByTag := Map("Mouse", {long: "", fired: false}, "Keyboard", {long: "", fired: false}, "Remote", {long: "", fired: false})
    global activeListByTag := Map("Mouse", "Main", "Keyboard", "Main", "Remote", "Main")
    global latchedListByTag := Map("Mouse", "Main", "Keyboard", "Main", "Remote", "Main")
    global modifierHotkeyRegisteredScByTag := Map("Mouse", 0, "Keyboard", 0, "Remote", 0)
    global modifier2HotkeyRegisteredScByTag := Map("Mouse", 0, "Keyboard", 0, "Remote", 0)
    global modCaptureTagBySlot := Map("Mod", "", "Mod2", "")
    global profileModCaptureHookBySlot := Map("Mod", "", "Mod2", "")
    global profileModCaptureSuspendedBySlot := Map("Mod", false, "Mod2", false)
    global profileModRawCaptureArmedBySlot := Map("Mod", false, "Mod2", false)
    global profileModCaptureCallbackBySlot := Map("Mod", "", "Mod2", "")
    global profileModCaptureStatusCallbackBySlot := Map("Mod", "", "Mod2", "")
    global profileModRawCaptureAwaitingReleaseBySlot := Map("Mod", false, "Mod2", false)
    global profileModRawCaptureDownHDeviceBySlot := Map("Mod", 0, "Mod2", 0)
    global profileModRawCaptureDownTickBySlot := Map("Mod", 0, "Mod2", 0)
    global profileModRawCaptureDownPageBySlot := Map("Mod", 0, "Mod2", 0)
    global profileModRawCaptureDownBytesHexBySlot := Map("Mod", "", "Mod2", "")
    global profileModRawCaptureReleaseWindowTokenBySlot := Map("Mod", 0, "Mod2", 0)
    global rawMapCaptureArmed := false
    global rawMapCaptureExpectedPage := 0
    global rawMapCaptureExpectedBytesHex := ""
    global rawMapCaptureCallback := ""
    global rawMapCaptureStatusCallback := ""
    global rawMapCaptureAwaitingRelease := false
    global rawMapCaptureDownHDevice := 0
    global rawMapCaptureDownTick := 0
    global rawMapCaptureReleaseWindowToken := 0
    global repeatActive := Map()
    global repeatTimerFns := Map()
    global repeatStartQpc := Map()
    global repeatFireCount := Map()
    global currentMacroSteps := []
    global captureRawMode := false
    global rawCaptureArmed := false
    global capturedRawPage := 0
    global capturedRawBytesHex := ""
    global capturedRawUpBytesHex := ""
    global rawCaptureAwaitingRelease := false
    global rawCaptureDownHDevice := 0
    global rawCaptureDownTick := 0
    global rawCaptureReleaseWindowToken := 0
    global RawCaptureReleaseWindowMs := 3000
    global MinHoldReleaseGapMs := 100
    global lastCaptureKind := "sc"
    global mouseCaptureArmed := false
    global capturedMouseButton := ""
    global mainCaptureOpen := false
    global editingId := ""
    global targetHeldMods := Map()
    global targetComboFired := false
    global targetCaptureHook := ""
    global RIDEV_INPUTSINK := 0x00000100
    global rawSniffing := false
    global gRaw := ""
    global lstRawLog := ""
    global gRawStartBtn := ""
    global g_lastDeviceCount := 0
    global g_lastEntryCount := 0
    global g_regLog := []
    global g_rawLogCount := 0
    global g_rawLogData := []
    global WH_MOUSE_LL := 14
    global mouseHookHandle := 0
    global mouseHookProcPtr := 0
    global WM_MOUSEMOVE := 0x200
    global WM_LBUTTONDOWN := 0x201
    global WM_LBUTTONUP := 0x202
    global WM_RBUTTONDOWN := 0x204
    global WM_RBUTTONUP := 0x205
    global WM_MBUTTONDOWN := 0x207
    global WM_MBUTTONUP := 0x208
    global WM_MOUSEWHEEL := 0x20A
    global WM_XBUTTONDOWN := 0x20B
    global WM_XBUTTONUP := 0x20C
    global WM_MOUSEHWHEEL := 0x20E
    global LLMHF_INJECTED := 0x1
    global mouseSwallowedDown := Map()
    global mouseModSwallowed := Map()
    global mouseReplayIgnore := Map()
    global mouseDispatchSeq := 0
    global mouseDispatchNextSeq := 1
    global MOUSE_DISPATCH_STALL_MS := 2000
    global mouseDownInFlight := Map()
    global WHEEL_DELTA := 120
    global WHEEL_ACCUM_TIMEOUT_MS := 500
    global WHEEL_MAX_NOTCHES_PER_MSG := 10
    global wheelAccum := Map("V", 0, "H", 0)
    global wheelAccumTick := Map("V", 0, "H", 0)
    global mouseBlockDecisionCache := Map()
    global mouseBlockCacheDirty := true
    global MOUSE_HOOK_STANDARD_BUTTONS := ["LButton", "RButton", "MButton", "XButton1", "XButton2"]
    global MOUSE_HOOK_LATENCY_BUFFER_SIZE := 2000
    global mouseHookLatencyBuf := []
    global mouseHookLatencyWriteIdx := 1
    global mouseHookWaitBuf := []
    global mouseHookWaitWriteIdx := 1
    global mouseHookWaitCount := 0
    global mouseHookWaitOver50 := 0
    global mouseHookWaitOver100 := 0
    global mouseHookWaitMaxMs := 0
    global mouseHookWaitMaxStamp := ""
    global nativeHookCtx := 0
    global nativeHookCode := 0
    global nativeHookCodeSize := 0
    global nativeHookThread := 0
    global nativeHookThreadId := 0
    global nativeHookMode := 0
    global nativeHookRunning := false
    global nativeHookBusy := false
    global nativeHookLeaked := false
    global nativeHookLastFailure := ""
    global nativeMouseHookSetting := "On"
    global nativeHookTrayMenu := 0
    global nativeHookPubSigTable := ""
    global nativeHookPubSigRects := ""
    global nativeHookPubCount := 0
    global nativeHookPubGate := false
    OnMessage(NativeHookWakeMsg(), NativeMouseWake)
    global nativeHookDrainBusy := false
    global nativeHookLastDrainSeq := -1
    global nativeHookLastDrainDropped := 0
    global nativeHookDrained := 0
    global nativeHookRecoveries := 0
    global nativeHookResyncTailPending := Map()
    global nativeHookResyncCount := 0
    global g_lastMouseHookTick := 0
    global MOUSE_HOOK_WATCHDOG_IDLE_MS := 30000
    global MOUSE_HOOK_WATCHDOG_SILENT_MS := 300000
    global modifierIndicatorDirty := true
    global g_lastModifierIndicatorText := ""
    OnMessage(0x00FF, OnRawInput)
    global rawMapTargetString := ""
    global rawMacroSteps := []
    global macroEditSteps := []
    global gMacro := ""
    global lvMacroSteps := ""
    global macroStepCapturedTarget := ""
    global savedMacros := Map()
    global savedMacroOrder := []
    global savedPsScripts := Map()
    global savedPsScriptOrder := []
    global savedCmdScripts := Map()
    global savedCmdScriptOrder := []
    global savedPsScriptHide := Map()
    global savedCmdScriptHide := Map()
    global gScript := ""
    global lbSavedScripts := ""
    global scriptEditKind := ""
    global scriptEditInitialBody := ""
    global scriptEditOnSave := ""
    global scriptEditSelectedName := ""
    global edScriptBody := ""
    global chkHideScript := ""
    global currentPsScriptBody := ""
    global currentPsScriptName := ""
    global currentCmdScriptBody := ""
    global currentCmdScriptName := ""
    global currentPsScriptHide := false
    global currentCmdScriptHide := false
    global lbSavedMacros := ""
    global macroRecording := false
    global recordHook := ""
    global recordLastEventTick := 0
    global recordHeldKeys := Map()
    global macroStepControls := []
    global macroStepCaptureHook := ""
    global macroStepHeldMods := Map()
    global macroStepComboFired := false
    global repeatPendingHoldUp := Map()
    global spDesktopSwitchHook := 0
    global spDesktopSwitchCallback := 0
    global spGuardStatus := {desktopHook: false, wtsNotify: false}
    global heldMappings := Map()
    global lvKeys := []
    global NM_CUSTOMDRAW := -12
    global CDDS_PREPAINT := 0x00000001
    global CDDS_ITEMPREPAINT := 0x00010001
    global CDDS_SUBITEM := 0x00020000
    global CDRF_DODEFAULT := 0x00000000
    global CDRF_NEWFONT := 0x00000002
    global CDRF_SKIPDEFAULT := 0x00000004
    global CDRF_NOTIFYITEMDRAW := 0x00000020
    global CDRF_NOTIFYSUBITEMDRAW := 0x00000020
    global DISABLED_BK := 0x00000099
    global DISABLED_TX := 0x00FFFFFF
    global g_CapsLockLedLastError := ""
    global g_ScrollLockLedLastError := ""
    global g_NumLockLedLastError := ""
    global g_LedFlagsCache := -1
}

BuildGui() {
    global g, grpLearnButton, btnCapture, btnCaptureRaw, btnRawSniffer, txtCaptureHelp
    global txtCaptureStatus, editDesc, ddlActionType, ActionTypeDdlItems, lblSends, txtTarget, actionRow1X
    global ACTION_KEY, ACTION_APP, ACTION_MULTIMEDIA, ACTION_MOUSE, ACTION_MACRO, ACTION_PS, ACTION_CMD
    global RUNMODE_TYPEMATIC, RUNMODE_SINGLE, RUNMODE_REPEAT, RUNMODE_TOGGLE_REPEAT, RUNMODE_HOLD, RUNMODE_TOGGLE_HOLD
    global PRESSTYPE_IMMEDIATE, PRESSTYPE_SHORT_TAP, PRESSTYPE_LONG_PRESS, PRESSTYPE_ANY_DURATION
    global actionRow1Y, actionRow1H, lblAppPath, editAppPath, btnBrowseApp, editAppArgs
    global btnAppArgs, lblMacroSelect, ddlMacroSelect, btnEditMacro, lblMultimedia, ddlMultimedia
    global lblPsScriptSelect, ddlPsScriptSelect, btnEditPsScript, lblCmdScriptSelect, ddlCmdScriptSelect, btnEditCmdScript
    global lblMouse, ddlMouse, lblMouseNotches, edMouseNotches, udMouseNotches, spdLblX
    global spdLblY, spdEdX, spdEdY, lblMouseSpeed, edMouseSpeed, udMouseSpeed
    global HoldOnlyTriggerIdx, HoldOnlyRunModeIdx, HoldUnsupportedActionRunModeIdx, TypematicUnsupportedActionRunModeIdx, DrawItemHwndOff, DrawItemHdcOff
    global DrawItemRectOff, firstOptionRowY, lblRunMode, RunModeDdlItems, ddlRunMode, chkDelay
    global repeatRowX, delayRowY, delayRowW, lblDelayFixed, edDelayMs, lblDelayMsUnit
    global dmuX, dmuY, dmuW, dmuH, delayTopRowY, repeatBottomRowY
    global lblRepeatMs, edRepeatMs, lblRepeatMsUnit, repeatMsX, delayNeededX, alignedInputX
    global edDelayMsX, edDelayMsY, edDelayMsW, edRepeatMsX, edRepeatMsY, edRepeatMsW
    global appExtraRowShift, actionAreaExpanded, lblTrigger, PressTypeDdlItems, ddlPressType, lblLongPress
    global edLongPressMs, lblLongPressUnit, lblAddDevTab, radAddMouse, radAddKeyboard, radAddRemote
    global lblAddTo, btnAddNew, btnAddMod, btnAddMod2, btnUpdate, btnTest
    global btnClearForm, glbX, glbY, glbW, glbH, leftColBottomY
    global leftColRight, rightColGap, rightColX, listRadioColExtra, mapsX, radListMain
    global radListMod, radListMod2, lbmX, lbmY, lbmW, lbmH
    global devTabH, rowY, lvTopY, btnMacros, btnPsScripts, btnCmdScripts, macX, macY
    global macW, macH, tabCaptionPadPerTab, tabStripEndPad, tabW, capName
    global tmpCapText, tcW, tabDevFilter, devTabStripW, tabDevCaptions, tabDevBoldFont
    global rightGroupGap, groupX, groupY, keymapsBoxW, macWWide, modMod2GapPx
    global tmpProfileTabBtn, profileTabBtnFullH, profileTabBtnH, profileTabAreaX, profileTabAreaW, profileTabAreaY
    global profileTabRowH, profileTabGap, profileTabAreaH, listRadioW, listRadioX, tmpLblM
    global listLblH, listRadioGlyphW, listRadioItemH, listRadioCaptions, listRadioLabels, idx
    global item, itemY, lblCap, profileTabArrowW, profileTabArrowsReserveW, btnProfileTabPrev
    global btnProfileTabNext, lv, lvX, lvY, lvW, lvH
    global btnMoveKeymapUp, btnMoveKeymapDown, btnRemove, rmX, rmY, rmW
    global rmH, btnNewProfile, btnRenameProfile, btnToggleProfileEnabled, btnDeleteProfile, btnMoveProfileLeft
    global btnMoveProfileRight, dpX, dpY, dpW, dpH, belowProfileColsY
    global modTabW, tmpModCapText, tmcW, tabModifierSection, tmsX, tmsY
    global tmsW, tmsH, tmpModTitleProbe, modTitleMaxW, lmtH, lblModifierSectionTitle
    global modTitleGap, grpModifier, modSectionRowY, btnCaptureModifier, btnCaptureModifierRaw, btnClearModifier
    global txtModifierStatus, modStatusRowY, mod2RowX, mod2RowY, btnCaptureModifier2, btnCaptureModifier2Raw
    global btnClearModifier2, txtModifierStatus2, modStatusH, modRow2Y, lblModifierModeLabel, ddlModifierMode
    global chkModLp, edModLpMs, lblModLpMsUnit, txtModLpHint, lblMod2ModeLabel, ddlMod2Mode
    global chkMod2Lp, edMod2LpMs, lblMod2LpMsUnit, modRow2Ctls, modRow2H, mrCtl
    global chkModPt, chkMod2Pt
    global mrCtlH, chkNotifyModifierToggle, lblLedIndicator, radLedOff, ddlCapsLockLedDevice, radLedScroll
    global chkScrollLockFlash, edScrollLockFlashMs, lblScrollLockFlashMsUnit, radLedCaps, chkCapsLockFlash, edCapsLockFlashMs
    global lblCapsLockFlashMsUnit, radLedNum, chkNumLockFlash, edNumLockFlashMs, lblNumLockFlashMsUnit, chkMaster
    global chkAppWatch, chkDisableMultiMapWarning, chkRunElevated, lblElevatedInfo, chkRunStartup
    global ddlRunStartupMode, chkStartHidden, lblLaunchOnExit, btnLaunchOnExit, launchOnExitMenu, lApp
    global lblTerminateApps, btnTerminateApps, terminateMenu, tApp, txtStatus, txtActiveProfile
    global txtModifierActive, btnKofi, bkX, bkY, bkW, bkH
    global nativeHookTrayMenu
    global gmX2, gmY2, gmW2, gmH2, bkX2, bkY2
    global tmaH, tapH, tsH, tmaNewY, tapNewY, tsNewY
    global controlsBelowActionRow

    A_TrayMenu.Delete()
    A_TrayMenu.Add("Show Mapper", (*) => ShowGui())
    A_TrayMenu.Add()
    A_TrayMenu.Add("Remapping Enabled", ToggleMasterFromTray)
    A_TrayMenu.Check("Remapping Enabled")
    A_TrayMenu.Add("Start Hidden", ToggleStartHiddenFromTray)
    A_TrayMenu.Add("Enable App-Based Auto Profile Switching", ToggleAppWatchFromTray)
    A_TrayMenu.Add()
    A_TrayMenu.Add("Open Log Folder", (*) => OpenLogFolder())
    A_TrayMenu.Add("Dump Mouse Hook Latency Stats", DumpMouseHookLatencyStats)
    nativeHookTrayMenu := Menu()
    for nhMode in ["Off", "Observe", "On"]
        nativeHookTrayMenu.Add(NativeHookTrayLabel(nhMode), NativeHookTrayPick.Bind(nhMode))
    A_TrayMenu.Add("Native Mouse Hook (test)", nativeHookTrayMenu)
    A_TrayMenu.Add("Run Mapping .ini Self-Test", MappingIniSelfTest)
    A_TrayMenu.Add()
    A_TrayMenu.Add("Exit", (*) => ExitApp())
    A_TrayMenu.Default := "Show Mapper"
    A_IconTip := "MF Button Mapper"
    OnMessage(0x404, OnTrayMsg)
    OnExit(MainOnExitBackstop)
    OnExit((*) => UninstallOwnWindowRectTracking(), -1)
    OnExit((*) => UninstallMouseHook(), -1)
    OnExit(NativeMouseHookOnExit, -1)
    OnExit(LaunchAppOnExit)
    g := Gui("", "MF Button Mapper")
    g.OnEvent("Close", (*) => (CancelPendingButtonCapture(), CancelPendingModifierCapture(), SaveKeymapColumnWidths(), g.Hide()))
    g.SetFont("s10", "Segoe UI")
    grpLearnButton := g.Add("GroupBox", "x8 y10 w572 h390", "Learn a button")
    g.Add("Text", "x20 y30", "1. Click Capture, then press a button:")
    btnCapture := g.Add("Button", "x20 y+8 w100", "Capture")
    btnCapture.OnEvent("Click", StartCapture)
    btnCaptureRaw := g.Add("Button", "x+10 yp w130", "Capture raw HID")
    btnCaptureRaw.OnEvent("Click", StartRawCapture)
    btnRawSniffer := g.Add("Button", "x+10 yp w130", "Raw HID Sniffer...")
    btnRawSniffer.OnEvent("Click", OpenRawSniffer)
    txtCaptureHelp := g.Add("Text", "x20 y+8 w380 r2", "Press a key or click a mouse button/scroll wheel. Nothing detected? Try `"Capture raw HID`".")
    txtCaptureStatus := g.Add("Text", "x20 y+8 w437", "Not captured yet.")
    g.Add("Text", "x20 y+15", "Description:")
    editDesc := g.Add("Edit", "x+10 w150")
    g.Add("Text", "x+15", "Action:")
    ActionTypeDdlItems := ["Send Key/Combo", "Launch App", "Multimedia", "Mouse", "Macro", "PS Script", "CMD"]
    ddlActionType := g.Add("DropDownList", "x+10 w150 Choose1", ActionTypeDdlItems)
    ddlActionType.OnEvent("Change", (*) => OnActionTypeChange())
    ACTION_KEY        := DdlIndexOf(ActionTypeDdlItems, "Send Key/Combo")
    ACTION_APP        := DdlIndexOf(ActionTypeDdlItems, "Launch App")
    ACTION_MULTIMEDIA := DdlIndexOf(ActionTypeDdlItems, "Multimedia")
    ACTION_MOUSE      := DdlIndexOf(ActionTypeDdlItems, "Mouse")
    ACTION_MACRO      := DdlIndexOf(ActionTypeDdlItems, "Macro")
    ACTION_PS         := DdlIndexOf(ActionTypeDdlItems, "PS Script")
    ACTION_CMD        := DdlIndexOf(ActionTypeDdlItems, "CMD")
    lblSends := g.Add("Text", "x20 y+8", "Sends:")
    txtTarget := g.Add("Edit", "x+10 w200 ReadOnly Background0xFFFFFF")
    txtTarget.OnEvent("Focus", StartTargetCapture)
    txtTarget.OnEvent("LoseFocus", StopTargetCapture)
    lblSends.GetPos(&actionRow1X, &actionRow1Y, , &actionRow1H)
    lblAppPath := g.Add("Text", "x20 y" actionRow1Y, "File path:")
    editAppPath := g.Add("Edit", "x+10 w230")
    btnBrowseApp := g.Add("Button", "x+8 w60", "Browse")
    btnBrowseApp.OnEvent("Click", (*) => BrowseForAppInto(editAppPath))
    editAppArgs := {Value: ""}
    btnAppArgs := g.Add("Button", "x+5 w60", "Args...")
    btnAppArgs.OnEvent("Click", (*) => EditArgsValue(editAppArgs))
    lblMacroSelect := g.Add("Text", "x20 y" actionRow1Y, "Macro:")
    ddlMacroSelect := g.Add("DropDownList", "x+10 w220 Choose1", ["(Custom / unsaved)"])
    ddlMacroSelect.OnEvent("Change", OnMacroSelectChange)
    btnEditMacro := g.Add("Button", "x+5 w70", "Macros")
    btnEditMacro.OnEvent("Click", OnEditMacroClick)
    lblPsScriptSelect := g.Add("Text", "x20 y" actionRow1Y " Hidden", "PS Script:")
    ddlPsScriptSelect := g.Add("DropDownList", "x+10 w220 Choose1 Hidden", ["(Custom / unsaved)"])
    ddlPsScriptSelect.OnEvent("Change", OnPsScriptSelectChange)
    btnEditPsScript := g.Add("Button", "x+5 w85 Hidden", "PS Scripts")
    btnEditPsScript.OnEvent("Click", OnEditPsScriptClick)
    lblCmdScriptSelect := g.Add("Text", "x20 y" actionRow1Y " Hidden", "CMD:")
    ddlCmdScriptSelect := g.Add("DropDownList", "x+10 w220 Choose1 Hidden", ["(Custom / unsaved)"])
    ddlCmdScriptSelect.OnEvent("Change", OnCmdScriptSelectChange)
    btnEditCmdScript := g.Add("Button", "x+5 w70 Hidden", "CMD")
    btnEditCmdScript.OnEvent("Click", OnEditCmdScriptClick)
    lblMultimedia := g.Add("Text", "x20 y" actionRow1Y, "Multimedia action:")
    ddlMultimedia := g.Add("DropDownList", "x+10 w200 Choose1", MultimediaNames())
    ddlMultimedia.OnEvent("Change", OnMultimediaChange)
    lblMouse := g.Add("Text", "x20 y" actionRow1Y, "Mouse action:")
    ddlMouse := g.Add("DropDownList", "x+10 w200 Choose1", MouseNames())
    ddlMouse.OnEvent("Change", OnMouseChange)
    lblMouseNotches := g.Add("Text", "x+15", "Notches:")
    edMouseNotches := g.Add("Edit", "x+10 w45 Number", "1")
    udMouseNotches := g.Add("UpDown", "Range1-19", 1)
    lblMouseNotches.GetPos(&spdLblX, &spdLblY)
    edMouseNotches.GetPos(&spdEdX, &spdEdY)
    lblMouseSpeed := g.Add("Text", "x" spdLblX " y" spdLblY, "Speed:")
    edMouseSpeed := g.Add("Edit", "x" spdEdX " y" spdEdY " w45 Number", "10")
    udMouseSpeed := g.Add("UpDown", "Range1-20", 10)
    HoldOnlyTriggerIdx := [2, 3]
    HoldOnlyRunModeIdx := [0, 2, 4]
    HoldUnsupportedActionRunModeIdx := [4, 5]
    TypematicUnsupportedActionRunModeIdx := [0]
    DrawItemHwndOff := A_PtrSize = 8 ? 24 : 20
    DrawItemHdcOff := DrawItemHwndOff + A_PtrSize
    DrawItemRectOff := DrawItemHdcOff + A_PtrSize
    OnMessage(0x002B, OnDdlDrawItem)
    OnMessage(0x002C, OnDdlMeasureItem)
    firstOptionRowY := actionRow1Y + actionRow1H + 17
    lblRunMode := g.Add("Text", "x20 y" firstOptionRowY, "Run mode:")
    RunModeDdlItems := ["Typematic", "Single run", "Repeat while holding", "Toggle Repeat", "Hold", "Toggle Hold"]
    ddlRunMode := g.Add("DropDownList", "x+10 w150 Choose1 +0x10", RunModeDdlItems)
    ddlRunMode.OnEvent("Change", (*) => (OnRunModeChange(), ApplyRunModeDelayDefault()))
    RUNMODE_TYPEMATIC     := DdlIndexOf(RunModeDdlItems, "Typematic")
    RUNMODE_SINGLE        := DdlIndexOf(RunModeDdlItems, "Single run")
    RUNMODE_REPEAT        := DdlIndexOf(RunModeDdlItems, "Repeat while holding")
    RUNMODE_TOGGLE_REPEAT := DdlIndexOf(RunModeDdlItems, "Toggle Repeat")
    RUNMODE_HOLD          := DdlIndexOf(RunModeDdlItems, "Hold")
    RUNMODE_TOGGLE_HOLD   := DdlIndexOf(RunModeDdlItems, "Toggle Hold")
    chkDelay := g.Add("Checkbox", "x+15", "Repeat delay")
    chkDelay.OnEvent("Click", (*) => OnDelayCheckChange())
    chkDelay.GetPos(&repeatRowX, &delayRowY, &delayRowW)
    lblDelayFixed := g.Add("Text", "x" repeatRowX " y" delayRowY " Hidden", "Repeat delay")
    edDelayMs := g.Add("Edit", "x" (repeatRowX + delayRowW + 5) " y" delayRowY " w60 Disabled", "200")
    lblDelayMsUnit := g.Add("Text", "x+3", "ms")
    lblDelayMsUnit.GetPos(&dmuX, &dmuY, &dmuW, &dmuH)
    delayTopRowY := delayRowY
    repeatBottomRowY := dmuY + dmuH + 8
    lblRepeatMs := g.Add("Text", "x" repeatRowX " y" repeatBottomRowY, "Repeat interval")
    edRepeatMs := g.Add("Edit", "x+5 w60", "100")
    lblRepeatMsUnit := g.Add("Text", "x+3", "ms")
    edRepeatMs.GetPos(&repeatMsX)
    delayNeededX := repeatRowX + delayRowW + 5
    alignedInputX := Max(delayNeededX, repeatMsX)
    edDelayMs.Move(alignedInputX)
    edDelayMs.GetPos(&edDelayMsX, &edDelayMsY, &edDelayMsW)
    lblDelayMsUnit.Move(edDelayMsX + edDelayMsW + 3)
    edRepeatMs.Move(alignedInputX)
    edRepeatMs.GetPos(&edRepeatMsX, &edRepeatMsY, &edRepeatMsW)
    lblRepeatMsUnit.Move(edRepeatMsX + edRepeatMsW + 3)
    appExtraRowShift := 0
    actionAreaExpanded := false
    lblTrigger := g.Add("Text", "x20 y" (dmuY + dmuH + 18), "Trigger:")
    PressTypeDdlItems := ["On press (immediate)", "On release (short tap)", "On long press (while held)", "On release (any duration)"]
    ddlPressType := g.Add("DropDownList", "x+10 w184 Choose1 +0x10", PressTypeDdlItems)
    PRESSTYPE_IMMEDIATE    := DdlIndexOf(PressTypeDdlItems, "On press (immediate)")
    PRESSTYPE_SHORT_TAP    := DdlIndexOf(PressTypeDdlItems, "On release (short tap)")
    PRESSTYPE_LONG_PRESS   := DdlIndexOf(PressTypeDdlItems, "On long press (while held)")
    PRESSTYPE_ANY_DURATION := DdlIndexOf(PressTypeDdlItems, "On release (any duration)")
    lblLongPress := g.Add("Text", "x+10 yp+2", "Fire after")
    edLongPressMs := g.Add("Edit", "x+10 yp-2 w53", String(legacyLongPressMs))
    lblLongPressUnit := g.Add("Text", "x+3 yp+2", "ms")
    RegisterHoldDdl(ddlPressType, PressTypeDdlItems, HoldOnlyTriggerIdx, IsMainCaptureSingleShot)
    RegisterHoldDdl(ddlRunMode, RunModeDdlItems, HoldOnlyRunModeIdx, IsMainCaptureSingleShot)
    AddHoldDdlRule(ddlRunMode, HoldUnsupportedActionRunModeIdx, IsHoldUnsupportedAction)
    AddHoldDdlRule(ddlRunMode, TypematicUnsupportedActionRunModeIdx, IsTypematicUnsupportedAction)
    ddlPressType.OnEvent("Change", (*) => EnforceHoldDdlSelection(ddlPressType, DdlIndexFromPressType("short")))
    ddlPressType.OnEvent("Change", (*) => UpdateLongPressFieldVisibility())
    ddlRunMode.OnEvent("Change", (*) => EnforceHoldDdlSelection(ddlRunMode, RUNMODE_SINGLE, OnRunModeChange))
    lblAddDevTab := g.Add("Text", "x20 y+18", "Tag as:")
    radAddMouse := g.Add("Radio", "x+8 yp w60 +0x8 Group", "Mouse")
    radAddMouse.OnEvent("Click", (*) => SetAddDevTabSelection("Mouse"))
    radAddKeyboard := g.Add("Radio", "x+5 yp +0x8", "Keyboard")
    radAddKeyboard.OnEvent("Click", (*) => SetAddDevTabSelection("Keyboard"))
    radAddRemote := g.Add("Radio", "x+5 yp w70 +0x8 Checked", "Remote")
    radAddRemote.OnEvent("Click", (*) => SetAddDevTabSelection("Remote"))
    lblAddTo := g.Add("Text", "x20 y+18", "Add to:")
    btnAddNew := g.Add("Button", "x+8 yp-4", "Main")
    btnAddNew.OnEvent("Click", (*) => SaveMapping(true, "Main"))
    btnAddMod := g.Add("Button", "x+0", "Mod 1")
    btnAddMod.OnEvent("Click", (*) => SaveMapping(true, "Mod"))
    btnAddMod2 := g.Add("Button", "x+0", "Mod 2")
    btnAddMod2.OnEvent("Click", (*) => SaveMapping(true, "Mod2"))
    btnUpdate := g.Add("Button", "x+8", "Update Map")
    btnUpdate.OnEvent("Click", (*) => SaveMapping(false))
    btnTest := g.Add("Button", "x+8", "Test Send")
    btnTest.OnEvent("Click", TestSend)
    btnClearForm := g.Add("Button", "x+8", "Clear")
    btnClearForm.OnEvent("Click", (*) => ResetCaptureUI())
    ResizeLearnButtonBox()
    grpLearnButton.GetPos(&glbX, &glbY, &glbW, &glbH)
    leftColBottomY := glbY + glbH + 15
    leftColRight := glbX + glbW
    rightColGap := 20
    rightColX := leftColRight + rightColGap
    listRadioColExtra := 6
    mapsX := rightColX + 12 + listRadioColExtra
    radListMain := g.Add("Radio", "x0 y0 w60 +0x8 Group Checked", "")
    radListMain.OnEvent("Click", (*) => SetEditingList("Main"))
    radListMod := g.Add("Radio", "x+6 yp w60 +0x8", "")
    radListMod.OnEvent("Click", (*) => SetEditingList("Mod"))
    radListMod2 := g.Add("Radio", "x+6 yp w60 +0x8", "")
    radListMod2.OnEvent("Click", (*) => SetEditingList("Mod2"))
    radListMain.GetPos(&lbmX, &lbmY, &lbmW, &lbmH)
    devTabH := lbmH + 10
    rowY := 20
    lvTopY := rowY + devTabH
    btnMacros := g.Add("Button", "x0 y0", "Macros")
    btnMacros.OnEvent("Click", (*) => OpenMacroEditor([], (*) => ""))
    btnMacros.GetPos(&macX, &macY, &macW, &macH)
    btnPsScripts := g.Add("Button", "x0 y0", "PS Scripts")
    btnPsScripts.OnEvent("Click", (*) => OpenScriptEditor("ps", "", (*) => ""))
    btnPsScripts.GetPos(, , &psBtnW)
    btnCmdScripts := g.Add("Button", "x0 y0", "CMD")
    btnCmdScripts.OnEvent("Click", (*) => OpenScriptEditor("cmd", "", (*) => ""))
    btnCmdScripts.GetPos(, , &cmdBtnW)
    tabCaptionPadPerTab := 18
    tabStripEndPad := 10
    tabW := 0
    for capName in ["Mouse", "Keyboard", "Remote"] {
        tmpCapText := g.Add("Text", "x-1000 y-1000", capName)
        tmpCapText.GetPos(, , &tcW)
        DestroyGuiControl(tmpCapText)
        tabW += tcW + tabCaptionPadPerTab
    }
    tabW += tabStripEndPad
    tabDevFilter := g.Add("Tab3", "x" mapsX " y" rowY " w" tabW " h" devTabH, ["Mouse", "Keyboard", "Remote"])
    tabDevFilter.UseTab(0)
    tabDevFilter.Opt("+0x2000")
    DllCall("InvalidateRect", "Ptr", tabDevFilter.Hwnd, "Ptr", 0, "Int", true)
    tabDevFilter.Value := 3
    tabDevFilter.OnEvent("Change", (*) => OnDevFilterTabChanged())
    devTabStripW := DevTabFitToLastTab(tabDevFilter)
    SetTimer(() => DevTabFitToLastTab(tabDevFilter, false), -150)
    tabDevCaptions := ["Mouse", "Keyboard", "Remote"]
    tabDevBoldFont := 0
    OnMessage(0x002B, OnDevTabDrawItem)
    rightGroupGap := 8
    groupX := mapsX + (devTabStripW > 0 ? devTabStripW : tabW) + rightGroupGap
    groupY := rowY + Round((devTabH - lbmH) / 2)
    keymapsBoxW := 532
    macWWide := Round(macW * 1.5)
    modMod2GapPx := 6
    scriptBtnGap := 4
    groupAvailW := keymapsBoxW - (devTabStripW > 0 ? devTabStripW : tabW) - rightGroupGap
    macBtnW := macWWide
    overflowW := macBtnW + psBtnW + cmdBtnW + 2 * scriptBtnGap - groupAvailW
    if overflowW > 0
        macBtnW := Max(macW, macBtnW - overflowW)
    btnMacros.Move(, groupY - 8, macBtnW)
    btnPsScripts.Move(, groupY - 8, psBtnW)
    btnCmdScripts.Move(, groupY - 8, cmdBtnW)
    PositionMacroScriptButtons(mapsX + keymapsBoxW)
    tmpProfileTabBtn := g.Add("Button", "x-1000 y-1000", "Tab")
    tmpProfileTabBtn.GetPos(, , , &profileTabBtnFullH)
    DestroyGuiControl(tmpProfileTabBtn)
    profileTabBtnH := Round(profileTabBtnFullH * 0.9)
    profileTabAreaX := mapsX
    profileTabAreaW := 532
    profileTabAreaY := lvTopY
    profileTabRowH := profileTabBtnH
    profileTabGap := 0
    profileTabAreaH := profileTabRowH + 4
    lvTopY := profileTabAreaY + profileTabAreaH
    listRadioW := 30
    listRadioX := leftColRight + 8
    tmpLblM := g.Add("Text", "x-1000 y-1000", "M1")
    tmpLblM.GetPos(, , , &listLblH)
    DestroyGuiControl(tmpLblM)
    listRadioGlyphW := 16
    listRadioItemH := listLblH + lbmH + 6
    listRadioCaptions := [["M", "Main", radListMain], ["M1", "Mod", radListMod], ["M2", "Mod2", radListMod2]]
    listRadioLabels := []
    for idx, item in listRadioCaptions {
        itemY := lvTopY - 3 + (idx - 1) * listRadioItemH
        lblCap := g.Add("Text", "x" listRadioX " y" itemY " w" listRadioW " h" listLblH " +Center +0x100", item[1])
        lblCap.OnEvent("Click", ((listName, *) => SetEditingList(listName)).Bind(item[2]))
        listRadioLabels.Push(lblCap)
        item[3].Move(listRadioX + Round((listRadioW - listRadioGlyphW) / 2), itemY + listLblH, listRadioGlyphW, lbmH)
    }
    profileTabArrowW := 22
    profileTabArrowsReserveW := profileTabArrowW * 2 + 4
    btnProfileTabPrev := g.Add("Button", "x-1000 y-1000 w" profileTabArrowW " h" profileTabBtnH, "◀")
    btnProfileTabPrev.OnEvent("Click", (*) => ProfileTabPagePrev())
    btnProfileTabPrev.Visible := false
    btnProfileTabNext := g.Add("Button", "x-1000 y-1000 w" profileTabArrowW " h" profileTabBtnH, "▶")
    btnProfileTabNext.OnEvent("Click", (*) => ProfileTabPageNext())
    btnProfileTabNext.Visible := false
    lv := g.Add("ListView", "x" mapsX " y" lvTopY " w532 h411", ["On", "Button", "Sends", "Mode"])
    lv.OnEvent("ItemSelect", LVSelect)
    lv.OnEvent("ContextMenu", LVContextMenu)
    lv.OnEvent("DoubleClick", OnKeymapDoubleClick)
    lv.ModifyCol(1, lvColW1)
    lv.ModifyCol(2, lvColW2)
    lv.ModifyCol(3, lvColW3)
    lv.ModifyCol(4, lvColW4)
    OnMessage(0x004E, LVKeymapCustomDraw)
    OnMessage(0x004E, ProfileTabButtonCustomDraw)
    lv.GetPos(&lvX, &lvY, &lvW, &lvH)
    btnMoveKeymapUp := g.Add("Button", "x" lvX " y" (lvY + lvH + 10) " w30", "▲")
    btnMoveKeymapUp.OnEvent("Click", (*) => MoveKeymapRow(-1))
    btnMoveKeymapDown := g.Add("Button", "x+0 w30", "▼")
    btnMoveKeymapDown.OnEvent("Click", (*) => MoveKeymapRow(1))
    btnRemove := g.Add("Button", "x+0", "Remove Map/s")
    btnRemove.OnEvent("Click", RemoveSelected)
    btnRemove.GetPos(&rmX, &rmY, &rmW, &rmH)
    btnNewProfile := g.Add("Button", "x+8", "New Profile")
    btnNewProfile.OnEvent("Click", (*) => OpenProfileDialog("new"))
    btnRenameProfile := g.Add("Button", "x+0", "Edit Profile")
    btnRenameProfile.OnEvent("Click", (*) => OpenProfileDialog("rename"))
    btnToggleProfileEnabled := g.Add("Button", "x+0", "Disable Profile")
    btnToggleProfileEnabled.OnEvent("Click", (*) => ToggleProfileEnabledFlow())
    btnDeleteProfile := g.Add("Button", "x+0", "Delete Profile")
    btnDeleteProfile.OnEvent("Click", (*) => DeleteProfileFlow())
    btnMoveProfileLeft := g.Add("Button", "x+8 w30", "◀")
    btnMoveProfileLeft.OnEvent("Click", (*) => MoveEditingProfileOrder(-1))
    btnMoveProfileRight := g.Add("Button", "x+0 w30", "▶")
    btnMoveProfileRight.OnEvent("Click", (*) => MoveEditingProfileOrder(1))
    btnMoveProfileRight.GetPos(&dpX, &dpY, &dpW, &dpH)
    keymapsBoxW := dpX + dpW - mapsX
    profileTabAreaW := keymapsBoxW
    lv.Move(, , keymapsBoxW)
    PositionMacroScriptButtons(mapsX + keymapsBoxW)
    belowProfileColsY := Max(dpY + dpH, rmY + rmH) + 15
    modTabW := 0
    for capName in ["Mod 1", "Mod 2"] {
        tmpModCapText := g.Add("Text", "x-1000 y-1000", capName)
        tmpModCapText.GetPos(, , &tmcW)
        DestroyGuiControl(tmpModCapText)
        modTabW += tmcW + tabCaptionPadPerTab
    }
    modTabW += tabStripEndPad
    tabModifierSection := g.Add("Tab3", "x" mapsX " y" belowProfileColsY " w" modTabW " h" devTabH, ["Mod 1", "Mod 2"])
    tabModifierSection.UseTab(0)
    tabModifierSection.OnEvent("Change", (*) => OnModifierSectionTabChanged())
    tabModifierSection.GetPos(&tmsX, &tmsY, &tmsW, &tmsH)
    tmpModTitleProbe := g.Add("Text", "x-1000 y-1000", "Modifier button (Keyboard)")
    tmpModTitleProbe.GetPos(, , &modTitleMaxW, &lmtH)
    DestroyGuiControl(tmpModTitleProbe)
    lblModifierSectionTitle := g.Add("Text", "x0 y0", "Modifier button (" editingDevTab ")")
    modTitleGap := 8
    lblModifierSectionTitle.Move(mapsX + modTabW + modTitleGap, tmsY + Round((tmsH - lmtH) / 2), modTitleMaxW, lmtH)
    grpModifier := g.Add("GroupBox", "x" mapsX " y" (tmsY + tmsH - 10) " w544 h98", "")
    modSectionRowY := tmsY + tmsH + 8
    btnCaptureModifier := g.Add("Button", "x" (mapsX + 12) " y" (modSectionRowY + 6), "Capture Mod 1")
    btnCaptureModifier.OnEvent("Click", StartModifierCapture)
    btnCaptureModifierRaw := g.Add("Button", "x+10 yp", "Capture Mod 1 (raw HID)")
    btnCaptureModifierRaw.OnEvent("Click", StartModifierRawCapture)
    btnClearModifier := g.Add("Button", "x+10 yp", "Clear Mod 1")
    btnClearModifier.OnEvent("Click", ClearModifierForTag)
    txtModifierStatus := g.Add("Text", "x" (mapsX + 12) " y+10 w468", "Modifier: not set")
    txtModifierStatus.GetPos(, &modStatusRowY)
    mod2RowX := mapsX + 12
    mod2RowY := modSectionRowY
    btnCaptureModifier2 := g.Add("Button", "x" mod2RowX " y" (mod2RowY + 6), "Capture Mod 2")
    btnCaptureModifier2.OnEvent("Click", StartModifierCapture2)
    btnCaptureModifier2Raw := g.Add("Button", "x+10 yp", "Capture Mod 2 raw HID")
    btnCaptureModifier2Raw.OnEvent("Click", StartModifierRawCapture2)
    btnClearModifier2 := g.Add("Button", "x+10 yp", "Clear Mod 2")
    btnClearModifier2.OnEvent("Click", ClearModifierForTag2)
    txtModifierStatus2 := g.Add("Text", "x" (mapsX + 12) " y" modStatusRowY " w468", "Mod 2: not set")
    txtModifierStatus2.GetPos(, , , &modStatusH)
    modRow2Y := modStatusRowY + modStatusH + 6
    lblModifierModeLabel := g.Add("Text", "x" (mapsX + 12) " y" modRow2Y, "Mode:")
    ddlModifierMode := g.Add("DropDownList", "x+8 yp w100 Choose1", ["Held", "Toggle"])
    ddlModifierMode.OnEvent("Change", (*) => OnModifierModeChange())
    chkModLp := g.Add("Checkbox", "x+20 yp", "Long press")
    chkModLp.OnEvent("Click", OnModLpChange)
    edModLpMs := g.Add("Edit", "x+8 yp w45", "500")
    edModLpMs.OnEvent("LoseFocus", (*) => SetModLpMs(edModLpMs.Value))
    lblModLpMsUnit := g.Add("Text", "x+6 yp", "ms")
    txtModLpHint := g.Add("Text", "x+12 yp c808080", "Unavailable: no release report")
    lblMod2ModeLabel := g.Add("Text", "x" (mapsX + 12) " y" modRow2Y, "Mode:")
    ddlMod2Mode := g.Add("DropDownList", "x+8 yp w100 Choose1", ["Held", "Toggle"])
    ddlMod2Mode.OnEvent("Change", OnMod2ModeChange)
    chkMod2Lp := g.Add("Checkbox", "x+20 yp", "Long press")
    chkMod2Lp.OnEvent("Click", OnMod2LpChange)
    edMod2LpMs := g.Add("Edit", "x+8 yp w45", "500")
    edMod2LpMs.OnEvent("LoseFocus", (*) => SetMod2LpMs(edMod2LpMs.Value))
    lblMod2LpMsUnit := g.Add("Text", "x+6 yp", "ms")
    modRow2Ctls := [lblModifierModeLabel, ddlModifierMode, chkModLp, edModLpMs, lblModLpMsUnit, txtModLpHint
        , lblMod2ModeLabel, ddlMod2Mode, chkMod2Lp, edMod2LpMs, lblMod2LpMsUnit]
    modRow2H := 0
    for mrCtl in modRow2Ctls {
        mrCtl.GetPos(, , , &mrCtlH)
        if mrCtlH > modRow2H
            modRow2H := mrCtlH
    }
    for mrCtl in modRow2Ctls {
        mrCtl.GetPos(, , , &mrCtlH)
        mrCtl.Move(, modRow2Y + Round((modRow2H - mrCtlH) / 2))
    }
    modRow3Y := modRow2Y + modRow2H + 10
    chkModPt := g.Add("Checkbox", "x" (mapsX + 12) " y" modRow3Y, "Passthrough (don't suppress on combo)")
    chkModPt.OnEvent("Click", OnModPtChange)
    chkMod2Pt := g.Add("Checkbox", "x" (mapsX + 12) " y" modRow3Y, "Passthrough (don't suppress on combo)")
    chkMod2Pt.OnEvent("Click", OnMod2PtChange)
    chkModPt.GetPos(, , , &modRow3H)
    chkNotifyModifierToggle := g.Add("Checkbox", "x" (mapsX + 12) " y" (modRow3Y + modRow3H + 10), "Show notification on modifier toggle")
    chkNotifyModifierToggle.OnEvent("Click", (*) => SetNotifyModifierToggle(chkNotifyModifierToggle.Value))
    lblLedIndicator := g.Add("Text", "x" (mapsX + 12) " y+6", "LED indicator when `"Mod 1`" active:")
    radLedOff := g.Add("Radio", "x+6 yp w40 +0x8 Group Checked", "Off")
    radLedOff.OnEvent("Click", (*) => SetLedIndicatorChoice("Off"))
    ddlCapsLockLedDevice := g.Add("DropDownList", "x+10 yp-3 w160", CAPS_LOCK_LED_DEVICE_CHOICES)
    ddlCapsLockLedDevice.OnEvent("Change", (*) => SetCapsLockLedDeviceChoice(ddlCapsLockLedDevice.Value))
    radLedScroll := g.Add("Radio", "x" (mapsX + 12) " y+11 w90 +0x8", "Scroll Lock")
    radLedScroll.OnEvent("Click", (*) => SetLedIndicatorChoice("ScrollLock"))
    chkScrollLockFlash := g.Add("Checkbox", "x+8 yp w50", "Flash")
    chkScrollLockFlash.OnEvent("Click", (*) => SetLockFlashEnabled("Scroll", chkScrollLockFlash.Value))
    edScrollLockFlashMs := g.Add("Edit", "x+4 yp-2 w40", "500")
    edScrollLockFlashMs.OnEvent("LoseFocus", (*) => SetLockFlashIntervalMs("Scroll", edScrollLockFlashMs.Value))
    lblScrollLockFlashMsUnit := g.Add("Text", "x+4 yp+2", "ms")
    radLedCaps := g.Add("Radio", "x" (mapsX + 12) " y+8 w90 +0x8", "Caps Lock")
    radLedCaps.OnEvent("Click", (*) => SetLedIndicatorChoice("CapsLock"))
    chkCapsLockFlash := g.Add("Checkbox", "x+8 yp w50", "Flash")
    chkCapsLockFlash.OnEvent("Click", (*) => SetLockFlashEnabled("Caps", chkCapsLockFlash.Value))
    edCapsLockFlashMs := g.Add("Edit", "x+4 yp-2 w40", "500")
    edCapsLockFlashMs.OnEvent("LoseFocus", (*) => SetLockFlashIntervalMs("Caps", edCapsLockFlashMs.Value))
    lblCapsLockFlashMsUnit := g.Add("Text", "x+4 yp+2", "ms")
    radLedNum := g.Add("Radio", "x" (mapsX + 12) " y+8 w90 +0x8", "Num Lock")
    radLedNum.OnEvent("Click", (*) => SetLedIndicatorChoice("NumLock"))
    chkNumLockFlash := g.Add("Checkbox", "x+8 yp w50", "Flash")
    chkNumLockFlash.OnEvent("Click", (*) => SetLockFlashEnabled("Num", chkNumLockFlash.Value))
    edNumLockFlashMs := g.Add("Edit", "x+4 yp-2 w40", "500")
    edNumLockFlashMs.OnEvent("LoseFocus", (*) => SetLockFlashIntervalMs("Num", edNumLockFlashMs.Value))
    lblNumLockFlashMsUnit := g.Add("Text", "x+4 yp+2", "ms")
    ResizeModifierGroupBox()
    chkMaster := g.Add("Checkbox", "x20 y" leftColBottomY, "Remapping enabled")
    chkMaster.OnEvent("Click", (*) => SetMasterEnabled(chkMaster.Value))
    chkAppWatch := g.Add("Checkbox", "x20 y+10", "Enable app-based auto profile switching")
    chkAppWatch.OnEvent("Click", (*) => SetAppWatchEnabled(chkAppWatch.Value))
    chkDisableMultiMapWarning := g.Add("Checkbox", "x20 y+10", "Disable multiple Maps per button Warning")
    chkDisableMultiMapWarning.OnEvent("Click", (*) => SetDisableMultiMapWarning(chkDisableMultiMapWarning.Value))
    chkRunElevated := g.Add("Checkbox", "x20 y+10", "Run elevated (Administrator)")
    chkRunElevated.OnEvent("Click", (*) => SetRunElevated(chkRunElevated.Value))
    lblElevatedInfo := g.Add("Text", "x38 y+2 w" (leftColRight - 38) " cGray", "Fixes mappings getting blocked by system apps with special permissions.")
    chkRunStartup := g.Add("Checkbox", "x20 y+10", "Run on startup")
    chkRunStartup.OnEvent("Click", (*) => SetRunAtStartup(chkRunStartup.Value))
    ddlRunStartupMode := g.Add("DropDownList", "x+10 yp-2 w220", ["Shortcut in shell:startup", "As admin (Task Scheduler)"])
    ddlRunStartupMode.Choose(1)
    ddlRunStartupMode.OnEvent("Change", (*) => OnRunStartupModeChange())
    chkStartHidden := g.Add("Checkbox", "x20 y+8", "Start hidden in systray (don't show this window on launch)")
    chkStartHidden.OnEvent("Click", (*) => SetStartHidden(chkStartHidden.Value))
    lblLaunchOnExit := g.Add("Text", "x20 y+10", "Launch app on Exit:")
    btnLaunchOnExit := g.Add("Button", "x+10 yp-5 w190", "None " Chr(0x25BE))
    btnLaunchOnExit.OnEvent("Click", (*) => ShowLaunchOnExitMenu())
    launchOnExitMenu := Menu()
    for lApp in launchOnExitApps
        launchOnExitMenu.Add(lApp.name, ToggleLaunchOnExitApp.Bind(lApp.key))
    lblTerminateApps := g.Add("Text", "x20 y+14", "Terminate app on Start:")
    btnTerminateApps := g.Add("Button", "x+10 yp-5 w190", "None " Chr(0x25BE))
    btnTerminateApps.OnEvent("Click", (*) => ShowTerminateAppsMenu())
    terminateMenu := Menu()
    for tApp in terminateApps
        terminateMenu.Add(tApp.name, ToggleTerminateApp.Bind(tApp.key))
    txtStatus := g.Add("Text", "x20 y+15 w" (leftColRight - 20), "Ready.")
    txtActiveProfile := g.Add("Text", "x20 y+8 w" (leftColRight - 20), "Active Profiles: Default")
    txtModifierActive := g.Add("Text", "x20 y+8 w" (leftColRight - 20), "Modifier: Mouse: off | Keyboard: off | Remote: off")
    btnKofi := g.Add("Text", "x20 y+12 cBlue", "☕ To build a better app... with Blackjack... and Hookers")
    btnKofi.SetFont("cBlue underline")
    btnKofi.OnEvent("Click", (*) => Run("https://ko-fi.com/Y0F226ZBQV"))
    btnKofi.GetPos(&bkX, &bkY, &bkW, &bkH)
    grpModifier.GetPos(&gmX2, &gmY2, &gmW2, &gmH2)
    btnKofi.Move(, Max(bkY, gmY2 + gmH2 - bkH))
    btnKofi.GetPos(&bkX2, &bkY2)
    txtModifierActive.GetPos(, , , &tmaH)
    txtActiveProfile.GetPos(, , , &tapH)
    txtStatus.GetPos(, , , &tsH)
    tmaNewY := bkY2 - 12 - tmaH
    tapNewY := tmaNewY - 8 - tapH
    tsNewY := tapNewY - 8 - tsH
    txtModifierActive.Move(, tmaNewY)
    txtActiveProfile.Move(, tapNewY)
    txtStatus.Move(, tsNewY)
    controlsBelowActionRow := [lblTrigger, ddlPressType, lblLongPress, edLongPressMs, lblLongPressUnit, lblRunMode, ddlRunMode, chkDelay, lblDelayFixed, edDelayMs, lblDelayMsUnit, lblRepeatMs, edRepeatMs, lblRepeatMsUnit,
        lblAddDevTab, radAddMouse, radAddKeyboard, radAddRemote,
        btnAddNew, btnAddMod, btnAddMod2, btnUpdate, btnTest, btnClearForm,
        chkMaster, chkAppWatch, chkDisableMultiMapWarning, chkRunElevated, lblElevatedInfo,
        chkRunStartup, ddlRunStartupMode, chkStartHidden,
        lblLaunchOnExit, btnLaunchOnExit,
        lblTerminateApps, btnTerminateApps,
        txtStatus, txtActiveProfile, txtModifierActive, btnKofi]
    OnActionTypeChange()
    OnRunModeChange()
    ApplyRunModeDelayDefault()
}

LoadAll() {
    chkMaster.Value := masterEnabled
    chkStartHidden.Value := startHidden
    chkAppWatch.Value := appWatchEnabled
    chkDisableMultiMapWarning.Value := disableMultiMapWarning
    chkRunElevated.Value := runElevated
    UpdateLedIndicatorOptionForTag()
    chkNotifyModifierToggle.Value := notifyModifierToggleByTag[editingDevTab]
    chkRunStartup.Value := runAtStartup
    ddlRunStartupMode.Choose(runAtStartupMode = "admin" ? 2 : 1)
    RefreshLaunchOnExitUI()
    RefreshTerminateAppsUI()
    edLongPressMs.Value := legacyLongPressMs
    LoadMappings()
    RefreshModifierGroupBoxForTag()
    for tag in DEVICE_TAGS {
        RegisterDeviceModifierHotkey(tag)
        RegisterDeviceModifier2Hotkey(tag)
    }
    RefreshProfileList()
    UpdateAddDevTabLock()
}

Activate() {
    RegisterAllRawInputDevices()
    InstallOwnWindowRectTracking()
    InstallMouseHook()
    SPGuardStart()
    RefreshList()
    CheckActiveProfile("init")
    UpdateActiveProfileStatus()
    CheckActiveProfileStartEventWatch()
    CheckActiveProfileStartMinimizeEndWatch()
    SetTimer(CheckActiveProfile, 250)
    SetTimer(CheckMouseHookWatchdog, 2000)
    NativeMouseHookApplySetting()
    TerminateSelectedAppsOnStart()
    if !startHidden
        ShowGui()
}

InitAll()
BuildGui()
LoadAll()
Activate()

QpcFreq() {
    static freq := 0
    if freq = 0 {
        DllCall("QueryPerformanceFrequency", "Int64*", &f := 0)
        freq := f
    }
    return freq
}

QpcNow() {
    DllCall("QueryPerformanceCounter", "Int64*", &t := 0)
    return t
}

InstallOwnWindowRectTracking() {
    global g
    OnMessage(0x0047, OnOwnWindowPosChanged)
    OnMessage(0x0002, OnOwnWindowDestroyed)
    RefreshOwnWindowRect(g.Hwnd)
}

UninstallOwnWindowRectTracking() {
    OnMessage(0x0047, OnOwnWindowPosChanged, 0)
    OnMessage(0x0002, OnOwnWindowDestroyed, 0)
}

OnOwnWindowPosChanged(wParam, lParam, msg, hwnd) {
    RefreshOwnWindowRect(hwnd)
}

OnOwnWindowDestroyed(wParam, lParam, msg, hwnd) {
    global ownWindowRects
    if !IsSet(ownWindowRects)
        return
    if ownWindowRects.Has(hwnd) {
        ownWindowRects.Delete(hwnd)
        NativeHookRequestPublish()
    }
}

RefreshOwnWindowRect(hwnd) {
    global ownWindowRects
    if !IsSet(ownWindowRects)
        return
    if !DllCall("IsWindow", "ptr", hwnd)
        return
    if DllCall("GetParent", "ptr", hwnd, "ptr")
        return
    if !DllCall("IsWindowVisible", "ptr", hwnd) {
        if ownWindowRects.Has(hwnd) {
            ownWindowRects.Delete(hwnd)
            NativeHookRequestPublish()
        }
        return
    }
    rect := Buffer(16, 0)
    if !DllCall("GetWindowRect", "ptr", hwnd, "ptr", rect)
        return
    ownWindowRects[hwnd] := [NumGet(rect, 0, "Int"), NumGet(rect, 4, "Int"), NumGet(rect, 8, "Int"), NumGet(rect, 12, "Int")]
    NativeHookRequestPublish()
}

RecordMouseHookLatency(tStart) {
    global mouseHookLatencyBuf, mouseHookLatencyWriteIdx, MOUSE_HOOK_LATENCY_BUFFER_SIZE, g_lastMouseHookTick
    elapsedMs := (QpcNow() - tStart) * 1000.0 / QpcFreq()
    if mouseHookLatencyBuf.Length < MOUSE_HOOK_LATENCY_BUFFER_SIZE
        mouseHookLatencyBuf.Push(elapsedMs)
    else {
        mouseHookLatencyBuf[mouseHookLatencyWriteIdx] := elapsedMs
        mouseHookLatencyWriteIdx := Mod(mouseHookLatencyWriteIdx, MOUSE_HOOK_LATENCY_BUFFER_SIZE) + 1
    }
    g_lastMouseHookTick := A_TickCount
}

RecordMouseHookQueueWait(waitMs) {
    global mouseHookWaitBuf, mouseHookWaitWriteIdx, MOUSE_HOOK_LATENCY_BUFFER_SIZE
    global mouseHookWaitCount, mouseHookWaitOver50, mouseHookWaitOver100, mouseHookWaitMaxMs, mouseHookWaitMaxStamp
    if waitMs < 0 || waitMs > 0x7FFFFFFF
        waitMs := 0
    if mouseHookWaitBuf.Length < MOUSE_HOOK_LATENCY_BUFFER_SIZE
        mouseHookWaitBuf.Push(waitMs)
    else {
        mouseHookWaitBuf[mouseHookWaitWriteIdx] := waitMs
        mouseHookWaitWriteIdx := Mod(mouseHookWaitWriteIdx, MOUSE_HOOK_LATENCY_BUFFER_SIZE) + 1
    }
    mouseHookWaitCount += 1
    if waitMs > 50 {
        mouseHookWaitOver50 += 1
        if waitMs > 100
            mouseHookWaitOver100 += 1
    }
    if waitMs > mouseHookWaitMaxMs {
        mouseHookWaitMaxMs := waitMs
        mouseHookWaitMaxStamp := A_Now
    }
}

DumpMouseHookLatencyStats(*) {
    global mouseHookLatencyBuf
    global mouseHookWaitBuf, mouseHookWaitWriteIdx, mouseHookWaitCount, mouseHookWaitOver50
    global mouseHookWaitOver100, mouseHookWaitMaxMs, mouseHookWaitMaxStamp
    waitText := DumpMouseHookQueueWaitSection() . NativeHookDumpSection()
    buf := mouseHookLatencyBuf.Clone()
    n := buf.Length
    if n = 0 {
        MsgBox(waitText "`n`nNo MouseHookProc() body-latency samples recorded yet.", "Mouse hook latency", "Iconi")
        return
    }
    loop n - 1 {
        i := A_Index
        key := buf[i + 1]
        j := i
        while j > 0 && buf[j] > key {
            buf[j + 1] := buf[j]
            j--
        }
        buf[j + 1] := key
    }
    Percentile(p) {
        idx := Max(1, Ceil(p * n))
        return buf[Min(idx, n)]
    }
    msg := waitText "`n`n" Format("MouseHookProc() BODY latency over the last {} sample(s):`n"
        . "  median (p50): {:.3f} ms`n"
        . "  p95:          {:.3f} ms`n"
        . "  p99:          {:.3f} ms`n"
        . "  max:          {:.3f} ms",
        n, Percentile(0.50), Percentile(0.95), Percentile(0.99), buf[n])
    MsgBox(msg, "Mouse hook latency", "Iconi")
    LogWarn("F-27a", Format("MouseHookProc latency n={} p50={:.3f}ms p95={:.3f}ms p99={:.3f}ms max={:.3f}ms",
        n, Percentile(0.50), Percentile(0.95), Percentile(0.99), buf[n]))
}

DumpMouseHookQueueWaitSection() {
    global mouseHookWaitBuf, mouseHookWaitCount, mouseHookWaitOver50, mouseHookWaitOver100
    global mouseHookWaitMaxMs, mouseHookWaitMaxStamp
    cnt := mouseHookWaitCount
    over50 := mouseHookWaitOver50
    over100 := mouseHookWaitOver100
    maxMs := mouseHookWaitMaxMs
    maxStamp := mouseHookWaitMaxStamp
    mouseHookWaitCount := 0
    mouseHookWaitOver50 := 0
    mouseHookWaitOver100 := 0
    mouseHookWaitMaxMs := 0
    mouseHookWaitMaxStamp := ""
    buf := mouseHookWaitBuf.Clone()
    n := buf.Length
    if n = 0
        return "Mouse hook QUEUE WAIT: no samples recorded yet (hook not installed, or no mouse activity)."
    loop n - 1 {
        i := A_Index
        key := buf[i + 1]
        j := i
        while j > 0 && buf[j] > key {
            buf[j + 1] := buf[j]
            j--
        }
        buf[j + 1] := key
    }
    p50 := buf[Min(Max(1, Ceil(0.50 * n)), n)]
    p95 := buf[Min(Max(1, Ceil(0.95 * n)), n)]
    p99 := buf[Min(Max(1, Ceil(0.99 * n)), n)]
    stampText := maxStamp != "" ? FormatTime(maxStamp, "HH:mm:ss") : "-"
    text := Format("Mouse hook QUEUE WAIT (event timestamp -> callback start; ~15.6 ms resolution)`n"
        . "  recent {} sample(s): p50 {} ms, p95 {} ms, p99 {} ms`n"
        . "  since last dump: {} event(s), {} over 50 ms, {} over 100 ms`n"
        . "  worst since last dump: {} ms (at {})",
        n, p50, p95, p99, cnt, over50, over100, maxMs, stampText)
    LogWarn("B1", Format("MouseHook queue wait recent n={} p50={}ms p95={}ms p99={}ms; since last dump events={} over50={} over100={} max={}ms at {}",
        n, p50, p95, p99, cnt, over50, over100, maxMs, stampText))
    return text
}

BlockWinKeyStartMenu(vk) {
    if (vk = 0x5B || vk = 0x5C)
        Send("{Blind}{vkFF}")
}

NowStamp() {
    return FormatTime(A_Now, "HH:mm:ss") "." Format("{:03}", A_MSec)
}

IsGenuineHoldRelease(downTick) {
    global MinHoldReleaseGapMs
    return (A_TickCount - downTick) >= MinHoldReleaseGapMs
}

UninstallMouseHook() {
    global mouseHookHandle, mouseHookProcPtr
    if mouseHookHandle {
        DllCall("UnhookWindowsHookEx", "ptr", mouseHookHandle)
        mouseHookHandle := 0
    }
    if mouseHookProcPtr {
        CallbackFree(mouseHookProcPtr)
        mouseHookProcPtr := 0
    }
}

WheelNotchesForDelta(axis, delta) {
    global wheelAccum, wheelAccumTick, WHEEL_DELTA, WHEEL_ACCUM_TIMEOUT_MS, WHEEL_MAX_NOTCHES_PER_MSG
    now := A_TickCount
    acc := wheelAccum[axis]
    if acc != 0 && ((acc > 0) != (delta > 0) || now - wheelAccumTick[axis] > WHEEL_ACCUM_TIMEOUT_MS)
        acc := 0
    acc += delta
    wheelAccumTick[axis] := now
    notches := Abs(acc) // WHEEL_DELTA
    wheelAccum[axis] := Mod(acc, WHEEL_DELTA)
    if notches > WHEEL_MAX_NOTCHES_PER_MSG {
        notches := WHEEL_MAX_NOTCHES_PER_MSG
        wheelAccum[axis] := 0
    }
    return notches
}

MouseButtonShouldBlock(buttonKey) {
    global masterEnabled, mouseBlockDecisionCache, mouseBlockCacheDirty
    if !masterEnabled || A_IsSuspended
        return false
    if mouseBlockCacheDirty
        RebuildMouseBlockDecisionCache()
    return mouseBlockDecisionCache.Has(buttonKey) ? mouseBlockDecisionCache[buttonKey].block : false
}

ComputeMouseButtonShouldBlock(buttonKey) {
    global mapOrder, mappings, DEVICE_TAGS, activeListByTag
    for tag in DEVICE_TAGS {
        activeList := activeListByTag[tag]
        effProfile := EffectiveProfileForButton(buttonKey, "mouse", tag, activeList)
        if MouseButtonRemapBlockedInProfile(buttonKey, effProfile, activeList)
            continue
        for id in mapOrder {
            m := mappings[id]
            if !MappingOwnsButtonStatic(m, buttonKey, "mouse", effProfile, tag)
                continue
            return true
        }
    }
    return false
}

RebuildMouseBlockDecisionCache() {
    global mapOrder, mappings, mouseBlockDecisionCache, mouseBlockCacheDirty, MOUSE_HOOK_STANDARD_BUTTONS
    candidates := Map()
    for id in mapOrder {
        m := mappings[id]
        if MapKind(m) = "mouse" && m.enabled && !MouseButtonRemapBlockedInProfile(m.button, MapProfile(m), MapList(m))
            candidates[m.button] := true
    }
    for bk in MOUSE_HOOK_STANDARD_BUTTONS
        candidates[bk] := true
    fresh := Map()
    for buttonKey in candidates
        fresh[buttonKey] := {block: ComputeMouseButtonShouldBlock(buttonKey), modRoles: ComputeMouseModifierSwallowRoles(buttonKey)}
    mouseBlockDecisionCache := fresh
    mouseBlockCacheDirty := false
}

InvalidateMouseBlockCache() {
    global mouseBlockCacheDirty
    mouseBlockCacheDirty := true
    NativeHookRequestPublish()
}

MouseEventOverOwnProcess(lParam) {
    global ownWindowRects
    if !IsSet(ownWindowRects)
        return false
    x := NumGet(lParam, 0, "Int")
    y := NumGet(lParam, 4, "Int")
    for hwnd, rect in ownWindowRects {
        if (x >= rect[1] && x < rect[3] && y >= rect[2] && y < rect[4])
            return true
    }
    return false
}

ComputeMouseModifierSwallowRoles(buttonKey) {
    global DEVICE_TAGS, activeProfileNameByTab
    roles := []
    raw := StdMouseRawReportFromButton(buttonKey)
    if !IsObject(raw) || raw.upBytesHex = ""
        return roles
    for tag in DEVICE_TAGS {
        prof := activeProfileNameByTab[tag]
        effMod := EffectiveModifier(prof, tag)
        effMod2 := EffectiveModifier2(prof, tag)
        isMod1 := effMod.kind = "raw" && effMod.rawPage = raw.page && effMod.rawBytesHex = raw.bytesHex
            && effMod.rawUpBytesHex != "" && effMod.mode = "hold"
        isMod2 := effMod2.kind = "raw" && effMod2.rawPage = raw.page && effMod2.rawBytesHex = raw.bytesHex
            && effMod2.rawUpBytesHex != "" && ResolvedMod2ModeOf(effMod, effMod2) = "hold"
        if !isMod1 && !isMod2
            continue
        pkey := ProfileKey(tag, prof)
        if isMod1 && !EffectivePassthroughSetting(pkey, "Mod", tag)
            roles.Push({tag: tag, which: "Mod"})
        if isMod2 && !EffectivePassthroughSetting(pkey, "Mod2", tag)
            roles.Push({tag: tag, which: "Mod2"})
    }
    return roles
}

ModSwallowedDispatch(buttonKey, isDown, roles) {
    global mod1ComboUsedByTag, mod2ComboUsedByTag, activeProfileNameByTab
    suppress := false
    for r in roles {
        if isDown {
            if r.which = "Mod"
                mod1ComboUsedByTag[r.tag] := false
            else
                mod2ComboUsedByTag[r.tag] := false
            continue
        }
        used := r.which = "Mod" ? mod1ComboUsedByTag[r.tag] : mod2ComboUsedByTag[r.tag]
        if r.which = "Mod"
            mod1ComboUsedByTag[r.tag] := false
        else
            mod2ComboUsedByTag[r.tag] := false
        if used && !EffectivePassthroughSetting(ProfileKey(r.tag, activeProfileNameByTab[r.tag]), r.which, r.tag)
            suppress := true
    }
    if !isDown && !suppress
        ReplayMouseClick(buttonKey)
}

ReplayMouseClick(buttonKey) {
    global mouseReplayIgnore
    mouseReplayIgnore[buttonKey] := {n: 2, t: A_TickCount}
    Send("{" buttonKey "}")
}

MouseReplayRawShouldIgnore(bytesNorm, isUp, hDevice) {
    global mouseReplayIgnore
    if hDevice || mouseReplayIgnore.Count = 0
        return false
    downBytes := isUp ? Format("{:04X}", Integer("0x" bytesNorm) >> 1) : bytesNorm
    key := StdMouseButtonFromRawReport(1, downBytes)
    if key = "" || !mouseReplayIgnore.Has(key)
        return false
    st := mouseReplayIgnore[key]
    if Abs(A_TickCount - st.t) > 300 {
        mouseReplayIgnore.Delete(key)
        return false
    }
    st.n -= 1
    if st.n <= 0
        mouseReplayIgnore.Delete(key)
    return true
}

StrJoin(arr, sep) {
    out := ""
    for i, v in arr
        out .= (i = 1 ? "" : sep) v
    return out
}

GenerateId(profile, buttonKey) {
    base := profile "::" buttonKey
    onDisk := DiskSectionNamesForProfileName(profile)
    if !mappings.Has(base) && !onDisk.Has(MappingSectionName(base))
        return base
    n := 2
    loop {
        cand := base "#" n
        if !mappings.Has(cand) && !onDisk.Has(MappingSectionName(cand))
            return cand
        n++
    }
}

DiskSectionNamesForProfileName(profile) {
    global profileFiles, DEVICE_TAGS
    names := Map()
    names.CaseSense := "Off"
    seenPaths := Map()
    seenPaths.CaseSense := "Off"
    for tag in DEVICE_TAGS {
        pkey := ProfileKey(tag, profile)
        if !profileFiles.Has(pkey)
            continue
        pf := profileFiles[pkey]
        if seenPaths.Has(pf) || !FileExist(pf)
            continue
        seenPaths[pf] := true
        try {
            for section in StrSplit(IniRead(pf), "`n", "`r") {
                if section != ""
                    names[section] := true
            }
        } catch as e {
            LogWarn("profile", pf ": could not read section names: " e.Message)
        }
    }
    return names
}

SaveMapping(isNew, targetList := "Main") {
    global lastCaptureKind, capturedSC, capturedRawPage, capturedRawBytesHex, capturedRawUpBytesHex, editingId, editingProfileName, editingDevTab, currentMacroSteps
    global disableMultiMapWarning, capturedMouseButton, ACTION_APP, ACTION_MULTIMEDIA, ACTION_MOUSE, ACTION_MACRO
    global ACTION_PS, ACTION_CMD, currentPsScriptBody, currentPsScriptName, currentCmdScriptBody, currentCmdScriptName
    global currentPsScriptHide, currentCmdScriptHide
    global RUNMODE_TYPEMATIC, RUNMODE_REPEAT, RUNMODE_TOGGLE_REPEAT, RUNMODE_HOLD, RUNMODE_TOGGLE_HOLD
    actionVal := ddlActionType.Value
    isApp := actionVal = ACTION_APP
    isMultimedia := actionVal = ACTION_MULTIMEDIA
    isMouse := actionVal = ACTION_MOUSE
    isMacro := actionVal = ACTION_MACRO
    isPs := actionVal = ACTION_PS
    isCmd := actionVal = ACTION_CMD
    macroStepsToSave := []
    macroNameToSave := ""
    scriptNameToSave := ""
    hideToSave := false
    if isApp {
        target := editAppPath.Value
        if target = "" {
            MsgBox("Enter a path first (or use Browse).", "Missing target", "Icon!")
            return
        }
        appArgs := editAppArgs.Value
    } else if isMacro {
        if currentMacroSteps.Length = 0 {
            MsgBox("Choose a saved macro from the dropdown, or add steps via Macros, first.", "Empty macro", "Icon!")
            return
        }
        target := ""
        appArgs := ""
        for s in currentMacroSteps
            macroStepsToSave.Push({type: s.type, target: s.target, args: s.args, delayAfterMs: s.delayAfterMs})
        macroNameToSave := FindSavedMacroNameForSteps(macroStepsToSave)
    } else if isPs || isCmd {
        target := isPs ? currentPsScriptBody : currentCmdScriptBody
        scriptNameToSave := isPs ? currentPsScriptName : currentCmdScriptName
        hideToSave := isPs ? currentPsScriptHide : currentCmdScriptHide
        if target = "" {
            MsgBox(isPs ? "Choose a saved PS Script from the dropdown, or write one via PS Scripts, first." : "Choose a saved CMD entry from the dropdown, or write one via CMD, first.", "Missing target", "Icon!")
            return
        }
        appArgs := ""
    } else {
        target := isMultimedia ? MultimediaSendForIndex(ddlMultimedia.Value) : (isMouse ? MouseTargetFromForm() : targetSendString)
        if target = "" {
            MsgBox(isMultimedia ? "Choose a multimedia action first." : (isMouse ? "Choose a mouse action first." : "Capture a key/combo to send first."), "Missing target", "Icon!")
            return
        }
        appArgs := ""
    }
    actionType := SelectedActionType()

    runModeVal := ddlRunMode.Value
    runMode := runModeVal = RUNMODE_TYPEMATIC ? "typematic" : (runModeVal = RUNMODE_REPEAT ? "repeat" : (runModeVal = RUNMODE_TOGGLE_REPEAT ? "toggle" : (runModeVal = RUNMODE_HOLD ? "hold" : (runModeVal = RUNMODE_TOGGLE_HOLD ? "toggleHold" : "single"))))
    repeatMs := IsInteger(edRepeatMs.Value) ? Integer(edRepeatMs.Value) : 100
    if repeatMs < 10
        repeatMs := 10
    delayMs := IsInteger(edDelayMs.Value) ? Integer(edDelayMs.Value) : 200
    if delayMs < 0
        delayMs := 0
    delayOn := chkDelay.Value ? true : false
    longPressMs := IsInteger(edLongPressMs.Value) ? Integer(edLongPressMs.Value) : 500
    if longPressMs < 50
        longPressMs := 50

    if !isNew && (editingId = "" || !mappings.Has(editingId)) {
        MsgBox("Select a mapping in the list first, then click Update Mapping.`n`nTo create a new mapping (even on the same button), use Add to Main, Add to Mod 1, or Add to Mod 2 instead.", "Nothing selected", "Icon!")
        return
    }

    id := ""
    if lastCaptureKind = "raw" {
        if capturedRawBytesHex = "" {
            MsgBox("Capture a button first.", "Missing input", "Icon!")
            return
        }
        buttonKey := MakeRawButtonKey(capturedRawPage, capturedRawBytesHex)
        if isNew {
            devTabForCheck := SelectedAddDevTab()
            conflictId := FindConflictingMapping("raw", buttonKey, editingProfileName, devTabForCheck, targetList)
            if conflictId != "" && !disableMultiMapWarning {
                conflictM := mappings[conflictId]
                choice := MsgBox("Already Mapped on the `"" targetList "`" list in " (MapDevTab(conflictM)) ">" (MapProfile(conflictM)) " profile.`n`nIf mapped to the same profile, or to a one in a different device tab and both profiles are active, both Maps will fire when the button is pressed.`n`nAdd the Map anyway?", "Button already mapped", "YesNo Icon!")
                if choice = "No"
                    return
            }
            conflictModRole := FindConflictingModifier("raw", buttonKey, editingProfileName, devTabForCheck)
            if conflictModRole != "" && !disableMultiMapWarning {
                choice := MsgBox("Already used as " conflictModRole " for the '" editingProfileName "' profile on the '" devTabForCheck "' tab.`n`nPressing this button will still toggle/hold " conflictModRole " AND fire this new mapping - it won't act as a normal button on its own.`n`nAdd the Map anyway?", "Button already mapped as modifier", "YesNo Icon!")
                if choice = "No"
                    return
            }
        }
        id := isNew ? GenerateId(editingProfileName, buttonKey) : editingId
        prevEnabled := mappings.Has(id) ? mappings[id].enabled : true
        mList := isNew ? targetList : (MapList(mappings[id]))
        mDevTab := isNew ? SelectedAddDevTab() : (MapDevTab(mappings[id]))
        dispId := SubStr(id, StrLen(editingProfileName) + 3)
        desc := editDesc.Value != "" ? editDesc.Value : Format("Raw 0x{:X} {} ({})", capturedRawPage, capturedRawBytesHex, dispId)
        if !mappings.Has(id)
            mapOrder.Push(id)
        rawHoldCapable := capturedRawUpBytesHex != ""
        rawRunMode := rawHoldCapable ? runMode : "single"
        rawPressType := rawRunMode = "single" ? PressTypeFromDdlIndex(ddlPressType.Value) : "short"
        mappings[id] := {profile: editingProfileName, kind: "raw", actionType: actionType, page: capturedRawPage, bytesHex: capturedRawBytesHex, upBytesHex: capturedRawUpBytesHex, desc: desc, target: target, appArgs: appArgs, macroSteps: macroStepsToSave, macroName: macroNameToSave, scriptName: scriptNameToSave, hideWindow: hideToSave, enabled: prevEnabled, pressType: rawPressType, runMode: rawRunMode, repeatMs: repeatMs, delayEnabled: delayOn, delayMs: delayMs, longPressMs: longPressMs, list: mList, devTab: mDevTab}
        StopRepeat(id)
    } else if lastCaptureKind = "mouse" {
        if capturedMouseButton = "" {
            MsgBox("Capture a button first.", "Missing input", "Icon!")
            return
        }
        buttonKey := capturedMouseButton
        id := isNew ? GenerateId(editingProfileName, buttonKey) : editingId
        mList := isNew ? targetList : (MapList(mappings[id]))
        if MouseButtonRemapBlockedInProfile(buttonKey, editingProfileName, mList) {
            MsgBox("Left and Right click can't be remapped on the M (Main) list of the Default profile: it applies everywhere with no modifier needed, so a mapping there could lock you out of clicking.`n`nUse the M1 or M2 list instead, select or create another profile, or capture a different button.", "Not allowed on Default/Main", "Icon!")
            return
        }
        if isNew {
            devTabForCheck := SelectedAddDevTab()
            conflictId := FindConflictingMapping("mouse", buttonKey, editingProfileName, devTabForCheck, targetList)
            if conflictId != "" && !disableMultiMapWarning {
                conflictM := mappings[conflictId]
                choice := MsgBox("Already Mapped on the `"" targetList "`" list in " (MapDevTab(conflictM)) ">" (MapProfile(conflictM)) " profile.`n`nIf mapped to the same profile, or to a one in a different device tab and both profiles are active, both Maps will fire when the button is pressed.`n`nAdd the Map anyway?", "Button already mapped", "YesNo Icon!")
                if choice = "No"
                    return
            }
        }
        prevEnabled := mappings.Has(id) ? mappings[id].enabled : true
        mDevTab := isNew ? SelectedAddDevTab() : (MapDevTab(mappings[id]))
        desc := editDesc.Value != "" ? editDesc.Value : MouseButtonDisplayName(buttonKey)
        if !mappings.Has(id)
            mapOrder.Push(id)
        mouseRunMode := IsMouseWheelKey(buttonKey) ? "single" : runMode
        mousePressType := mouseRunMode = "single" ? PressTypeFromDdlIndex(ddlPressType.Value) : "short"
        mappings[id] := {profile: editingProfileName, kind: "mouse", actionType: actionType, button: buttonKey, desc: desc, target: target, appArgs: appArgs, macroSteps: macroStepsToSave, macroName: macroNameToSave, scriptName: scriptNameToSave, hideWindow: hideToSave, enabled: prevEnabled, pressType: mousePressType, runMode: mouseRunMode, repeatMs: repeatMs, delayEnabled: delayOn, delayMs: delayMs, longPressMs: longPressMs, list: mList, devTab: mDevTab}
        StopRepeat(id)
    } else {
        if !capturedSC {
            MsgBox("Capture a button first.", "Missing input", "Icon!")
            return
        }
        buttonKey := Format("SC{:03X}", capturedSC)
        if isNew {
            devTabForCheck := SelectedAddDevTab()
            conflictId := FindConflictingMapping("sc", buttonKey, editingProfileName, devTabForCheck, targetList)
            if conflictId != "" && !disableMultiMapWarning {
                conflictM := mappings[conflictId]
                choice := MsgBox("Already Mapped on the `"" targetList "`" list in " (MapDevTab(conflictM)) ">" (MapProfile(conflictM)) " profile.`n`nIf mapped to the same profile, or to a one in a different device tab and both profiles are active, both Maps will fire when the button is pressed.`n`nAdd the Map anyway?", "Button already mapped", "YesNo Icon!")
                if choice = "No"
                    return
            }
            conflictModRole := FindConflictingModifier("sc", buttonKey, editingProfileName, devTabForCheck)
            if conflictModRole != "" && !disableMultiMapWarning {
                choice := MsgBox("Already used as " conflictModRole " for the '" editingProfileName "' profile on the '" devTabForCheck "' tab.`n`nPressing this button will still toggle/hold " conflictModRole " AND fire this new mapping - it won't act as a normal button on its own.`n`nAdd the Map anyway?", "Button already mapped as modifier", "YesNo Icon!")
                if choice = "No"
                    return
            }
        }
        id := isNew ? GenerateId(editingProfileName, buttonKey) : editingId

        oldButtonKey := ""
        if !isNew && (MapKind(mappings[editingId])) = "sc" {
            ob := Format("SC{:03X}", mappings[editingId].sc)
            if ob != buttonKey
                oldButtonKey := ob
        }

        prevEnabled := mappings.Has(id) ? mappings[id].enabled : true
        mList := isNew ? targetList : (MapList(mappings[id]))
        mDevTab := isNew ? SelectedAddDevTab() : (MapDevTab(mappings[id]))
        dispId := SubStr(id, StrLen(editingProfileName) + 3)
        desc := editDesc.Value != "" ? editDesc.Value : dispId
        if !mappings.Has(id)
            mapOrder.Push(id)
        mappings[id] := {profile: editingProfileName, kind: "sc", actionType: actionType, sc: capturedSC, desc: desc, target: target, appArgs: appArgs, macroSteps: macroStepsToSave, macroName: macroNameToSave, scriptName: scriptNameToSave, hideWindow: hideToSave, enabled: prevEnabled, pressType: (runMode = "single" ? PressTypeFromDdlIndex(ddlPressType.Value) : "short"), runMode: runMode, repeatMs: repeatMs, delayEnabled: delayOn, delayMs: delayMs, longPressMs: longPressMs, list: mList, devTab: mDevTab}
        StopRepeat(id)
        RegisterHotkeyForButton(buttonKey)
        if oldButtonKey != ""
            RegisterHotkeyForButton(oldButtonKey)
    }

    SaveProfileMapping(ProfileKey(editingDevTab, editingProfileName), id)
    InvalidateMouseBlockCache()
    RefreshList()
    ResetCaptureUI()
    txtStatus.Value := (isNew ? "Added mapping " : "Updated mapping ") id "."
}

BuildScButtonIndex() {
    global mapOrder, mappings
    idx := Map()
    for id in mapOrder {
        m := mappings[id]
        if (MapKind(m)) != "sc"
            continue
        bk := Format("SC{:03X}", m.sc)
        if !idx.Has(bk)
            idx[bk] := []
        idx[bk].Push(id)
    }
    return idx
}

EffectiveProfileForButton(buttonKey, kind := "sc", devTab := "", list := "") {
    global activeProfileNameByTab, mapOrder, mappings
    if devTab = ""
        devTab := DevTabForButtonKey(buttonKey, kind)
    effProfile := activeProfileNameByTab.Has(devTab) ? activeProfileNameByTab[devTab] : "Default"
    if effProfile = "Default"
        return "Default"
    for id in mapOrder {
        m := mappings[id]
        mKind := MapKind(m)
        if mKind != kind
            continue
        if (MapProfile(m)) != effProfile
            continue
        if (MapDevTab(m)) != devTab
            continue
        if list != "" && (MapList(m)) != list
            continue
        mButtonKey := MappingButtonKey(m)
        if mButtonKey = buttonKey
            return effProfile
    }
    return "Default"
}

FindRawMappingUpBytes(page, downBytesHex) {
    global mapOrder, mappings
    for id in mapOrder {
        m := mappings[id]
        if (MapKind(m)) != "raw"
            continue
        if m.page != page || m.bytesHex != downBytesHex
            continue
        up := MapUpBytesHex(m)
        if up != ""
            return up
    }
    return ""
}

FindRawMappingDownBytesForUp(page, upBytesHexCandidate) {
    global mapOrder, mappings
    for id in mapOrder {
        m := mappings[id]
        if (MapKind(m)) != "raw"
            continue
        if m.page != page
            continue
        up := MapUpBytesHex(m)
        if up != "" && up = upBytesHexCandidate
            return m.bytesHex
    }
    return ""
}

MappingButtonKey(m) {
    mKind := MapKind(m)
    if mKind = "mouse"
        return m.button
    return mKind = "raw" ? (MakeRawButtonKey(m.page, m.bytesHex)) : Format("SC{:03X}", m.sc)
}

MappingOwnsButton(m, buttonKey, kind, effProfile, devTab, activeList) {
    if (MapKind(m)) != kind
        return false
    if (MapProfile(m)) != effProfile
        return false
    if effProfile != "Default" && (MapDevTab(m)) != devTab
        return false
    if MouseButtonRemapBlockedInProfile(buttonKey, effProfile, MapList(m))
        return false
    if MappingButtonKey(m) != buttonKey || !m.enabled
        return false
    if (MapList(m)) != activeList
        return false
    return true
}

MappingOwnsButtonStatic(m, buttonKey, kind, effProfile, devTab) {
    if (MapKind(m)) != kind
        return false
    if (MapProfile(m)) != effProfile
        return false
    if effProfile != "Default" && (MapDevTab(m)) != devTab
        return false
    if MouseButtonRemapBlockedInProfile(buttonKey, effProfile, MapList(m))
        return false
    if MappingButtonKey(m) != buttonKey || !m.enabled
        return false
    return true
}

MatchingMappingIds(buttonKey, kind) {
    global mapOrder, mappings, activeListByTag
    devTab := DevTabForButtonKey(buttonKey, kind)
    activeList := activeListByTag[devTab]
    effProfile := EffectiveProfileForButton(buttonKey, kind, devTab, activeList)
    ids := []
    for id in mapOrder {
        m := mappings[id]
        if MappingOwnsButton(m, buttonKey, kind, effProfile, devTab, activeList)
            ids.Push(id)
    }
    return ids
}

FindConflictingMapping(kind, buttonKey, profile, devTab, list) {
    global mappings
    for id, m in mappings {
        if (MapKind(m)) != kind
            continue
        if (MapProfile(m)) != profile
            continue
        if profile != "Default" && (MapDevTab(m)) != devTab
            continue
        if MappingButtonKey(m) != buttonKey
            continue
        if (MapList(m)) != list
            continue
        return id
    }
    return ""
}

FindLongPressMappingIds(buttonKey, kind, candidateIds := "") {
    global mappings
    if !IsObject(candidateIds)
        candidateIds := MatchingMappingIds(buttonKey, kind)
    ids := []
    for id in candidateIds {
        m := mappings[id]
        if MapRunMode(m) != "single"
            continue
        if MapPressType(m) != "long"
            continue
        ids.Push(id)
    }
    return ids
}

ToggleLatched(devTab, which) {
    global latchedListByTag
    latchedListByTag[devTab] := (latchedListByTag[devTab] = which) ? "Main" : which
    RecomputeHeldActiveList(devTab)
}

PairShortAction(devTab, longWhich) {
    shortWhich := (longWhich = "Mod") ? "Mod2" : "Mod"
    ToggleLatched(devTab, shortWhich)
    NotifyModifierToggled(devTab)
}

CheckLongPress(buttonKey, token, id) {
    global buttonPressState, mappings
    if !buttonPressState.Has(buttonKey)
        return
    st := buttonPressState[buttonKey]
    if st.token != token || !st.pressed
        return
    if !mappings.Has(id)
        return
    st.longFired := true
    FireMapping(mappings[id])
}

ScheduleNextRepeatTick(id, ms) {
    global repeatStartQpc, repeatFireCount, repeatTimerFns
    if !repeatTimerFns.Has(id) || !repeatStartQpc.Has(id) || !repeatFireCount.Has(id)
        return
    nextDueElapsedMs := repeatFireCount[id] * ms
    elapsedMs := (QpcNow() - repeatStartQpc[id]) * 1000 / QpcFreq()
    dueInMs := nextDueElapsedMs - elapsedMs
    SetTimer(repeatTimerFns[id], -Max(1, dueInMs))
}

ToggleRepeat(id) {
    global repeatActive
    if repeatActive.Has(id) && repeatActive[id]
        StopRepeat(id)
    else
        StartRepeat(id)
}

ToggleHold(id, m) {
    global heldMappings
    if heldMappings.Has(id)
        FireHoldUp(id, m)
    else
        FireHoldDown(id, m)
}

StopAllRepeats() {
    global repeatActive, repeatTimerFns, repeatStartQpc, repeatFireCount, repeatPendingHoldUp
    activeCount := 0
    for id, isOn in repeatActive
        if isOn
            activeCount += 1
    ReleaseAllHolds()
    for id, upStr in repeatPendingHoldUp
        Send(upStr)
    repeatPendingHoldUp := Map()
    for id, fn in repeatTimerFns
        SetTimer(fn, 0)
    repeatTimerFns := Map()
    repeatActive := Map()
    repeatStartQpc := Map()
    repeatFireCount := Map()
    loop activeCount
        ReleaseHighResTimer()
}

ResolveMacroSteps(m) {
    global savedMacros
    macroName := MapMacroName(m)
    if macroName != "" && savedMacros.Has(macroName)
        return savedMacros[macroName]
    return m.HasOwnProp("macroSteps") ? m.macroSteps : []
}

FireHoldDown(id, m) {
    global heldMappings
    actionType := MapActionType(m)
    if actionType != "key" || IsCursorSpeedTarget(m.target) {
        FireMapping(m)
        return
    }
    strs := BuildHoldSendStrings(m.target)
    heldMappings[id] := strs.up
    Send(strs.down)
}

FireHoldUp(id, m) {
    global heldMappings
    actionType := MapActionType(m)
    if actionType != "key" || IsCursorSpeedTarget(m.target)
        return
    if heldMappings.Has(id) {
        Send(heldMappings[id])
        heldMappings.Delete(id)
    } else {
        Send(BuildHoldSendStrings(m.target).up)
    }
}

ReleaseAllHolds() {
    global heldMappings
    for id, upStr in heldMappings
        Send(upStr)
    heldMappings := Map()
}

BuildHoldSendStrings(sendStr) {
    mods := []
    i := 1
    len := StrLen(sendStr)
    while i <= len {
        c := SubStr(sendStr, i, 1)
        if c = "^"
            mods.Push("Ctrl")
        else if c = "!"
            mods.Push("Alt")
        else if c = "+"
            mods.Push("Shift")
        else if c = "#"
            mods.Push("Win")
        else
            break
        i++
    }
    rest := SubStr(sendStr, i)
    keyName := ""
    if rest != "" {
        if SubStr(rest, 1, 1) = "{" && SubStr(rest, -1) = "}"
            keyName := SubStr(rest, 2, StrLen(rest) - 2)
        else
            keyName := rest
    }
    downStr := ""
    for modName in mods
        downStr .= "{" modName " down}"
    if keyName != ""
        downStr .= "{" keyName " down}"
    upStr := ""
    if keyName != ""
        upStr .= "{" keyName " up}"
    loop mods.Length {
        upStr .= "{" mods[mods.Length - A_Index + 1] " up}"
    }
    return {down: downStr, up: upStr}
}

ProfileForProcess(exeName, devTab) {
    global profiles, profileOrder, appWatchEnabled
    if !appWatchEnabled
        return "Default"
    seen := Map()
    for pkey in profileOrder {
        if !profiles.Has(pkey)
            continue
        seen[pkey] := true
        if ProfileKeyTab(pkey) != devTab
            continue
        pdata := profiles[pkey]
        if !ProfileIsEnabled(pkey)
            continue
        for procName in pdata.processNames {
            if procName = exeName
                return ProfileKeyName(pkey)
        }
    }
    for pkey, pdata in profiles {
        if pkey = "Default" || seen.Has(pkey)
            continue
        if ProfileKeyTab(pkey) != devTab
            continue
        if !ProfileIsEnabled(pkey)
            continue
        for procName in pdata.processNames {
            if procName = exeName
                return ProfileKeyName(pkey)
        }
    }
    return "Default"
}

CheckActiveProfile(source := "poll") {
    global appWatchEnabled, activeProfileNameByTab, DEVICE_TAGS, g_lastCheckedExeName
    global g_pwPolls, g_pwEvents, g_pwSwitches, g_pwLookupFailStreak
    if source = "poll" {
        g_pwPolls += 1
        if Mod(g_pwPolls, 2400) = 0
            LogWarn("profwatch", Format("heartbeat polls={} events={} switches={}", g_pwPolls, g_pwEvents, g_pwSwitches))
    }
    if !appWatchEnabled {
        g_lastCheckedExeName := "?unset?"
        anySwitched := false
        for tag in DEVICE_TAGS {
            if activeProfileNameByTab[tag] != "Default" {
                SwitchActiveProfile(tag, "Default", true)
                anySwitched := true
            }
        }
        if anySwitched
            RefreshAllScHotkeyStates()
        return
    }
    try
        exeName := WinGetProcessName("A")
    catch as e {
        g_lastCheckedExeName := "?unset?"
        g_pwLookupFailStreak += 1
        if g_pwLookupFailStreak = 1
            LogWarn("profwatch", "foreground exe lookup failed: " e.Message " A_LastError=" A_LastError " src=" source)
        return
    }
    if g_pwLookupFailStreak > 0 {
        LogWarn("profwatch", "lookup recovered after " g_pwLookupFailStreak " failures")
        g_pwLookupFailStreak := 0
    }
    ApplyActiveProfileForExeName(exeName, source)
}

ApplyActiveProfileForExeName(exeName, source := "poll") {
    global activeProfileNameByTab, DEVICE_TAGS, g_lastCheckedExeName, g_pwSwitches
    anySwitched := false
    try {
        for tag in DEVICE_TAGS {
            newProfile := ProfileForProcess(exeName, tag)
            oldProfile := activeProfileNameByTab[tag]
            if newProfile != oldProfile {
                g_pwSwitches += 1
                LogWarn("profwatch", Format("switch tab={} {}->{} exe={} src={}", tag, oldProfile, newProfile, exeName, source))
                if source = "poll"
                    LogWarn("profwatch", "poll corrected drift (event path did not switch) exe=" exeName)
                SwitchActiveProfile(tag, newProfile, true)
                anySwitched := true
            }
        }
        if anySwitched
            RefreshAllScHotkeyStates()
        g_lastCheckedExeName := exeName
    } catch as e {
        g_lastCheckedExeName := "?unset?"
        LogWarn("profwatch", "Apply failed for '" exeName "': " e.Message " (" e.What ") - will retry on next check")
        try InvalidateMouseBlockCache()
        try RefreshAllScHotkeyStates()
    }
}

InvalidateActiveProfileExeCache() {
    global g_lastCheckedExeName
    g_lastCheckedExeName := "?unset?"
}

CheckMouseHookWatchdog() {
    global mouseHookHandle, g_lastMouseHookTick, MOUSE_HOOK_WATCHDOG_IDLE_MS, MOUSE_HOOK_WATCHDOG_SILENT_MS
    NativeHookWatchdog()
    if !mouseHookHandle
        return
    if g_lastMouseHookTick = 0
        return
    lii := Buffer(8, 0)
    NumPut("UInt", 8, lii, 0)
    if !DllCall("GetLastInputInfo", "ptr", lii)
        return
    idleMs := A_TickCount - NumGet(lii, 4, "UInt")
    if idleMs > MOUSE_HOOK_WATCHDOG_IDLE_MS
        return
    silentMs := A_TickCount - g_lastMouseHookTick
    if silentMs < MOUSE_HOOK_WATCHDOG_SILENT_MS
        return
    LogWarn("F-27b", Format("Mouse hook watchdog: no MouseHookProc() invocation in {}ms despite input activity {}ms ago - reinstalling", silentMs, idleMs))
    UninstallMouseHook()
    if !InstallMouseHook()
        LogWarn("F-27b", "Mouse hook watchdog: reinstall attempt failed - see the Mouse hook error dialog")
    g_lastMouseHookTick := 0
    if NativeMouseHookIsRunning()
        SetTimer(NativeMouseHookRestartForOrder, -1)
}

CheckActiveProfileStartEventWatch() {
    global g_foregroundEventHook, g_foregroundEventCallback
    static EVENT_SYSTEM_FOREGROUND := 0x0003
    static WINEVENT_OUTOFCONTEXT := 0x0000
    try {
        g_foregroundEventCallback := CallbackCreate(CheckActiveProfileForegroundProc, "", 7)
        g_foregroundEventHook := DllCall("SetWinEventHook"
            , "UInt", EVENT_SYSTEM_FOREGROUND
            , "UInt", EVENT_SYSTEM_FOREGROUND
            , "Ptr", 0
            , "Ptr", g_foregroundEventCallback
            , "UInt", 0
            , "UInt", 0
            , "UInt", WINEVENT_OUTOFCONTEXT
            , "Ptr")
        if !g_foregroundEventHook
            LogWarn("f10b", "SetWinEventHook (EVENT_SYSTEM_FOREGROUND) returned NULL - event-driven profile switching inactive, falling back to the backstop poll only. A_LastError=" A_LastError)
        else
            LogWarn("profwatch", "foreground event hook installed")
    } catch as e {
        LogWarn("f10b", "SetWinEventHook (EVENT_SYSTEM_FOREGROUND) threw: " e.Message " - falling back to the backstop poll only.")
    }
    OnExit(CheckActiveProfileEventWatchOnExit)
}

CheckActiveProfileForegroundProc(hWinEventHook, event, hwnd, idObject, idChild, dwEventThread, dwmsEventTime) {
    SetTimer(CheckActiveProfileFromEvent, -1)
}

CheckActiveProfileFromEvent() {
    global g_pwEvents
    g_pwEvents += 1
    CheckActiveProfile("fg-event")
}

CheckActiveProfileStartMinimizeEndWatch() {
    global g_minimizeEndEventHook, g_minimizeEndEventCallback
    static EVENT_SYSTEM_MINIMIZEEND := 0x0017
    static WINEVENT_OUTOFCONTEXT := 0x0000
    try {
        g_minimizeEndEventCallback := CallbackCreate(CheckActiveProfileMinimizeEndProc, "", 7)
        g_minimizeEndEventHook := DllCall("SetWinEventHook"
            , "UInt", EVENT_SYSTEM_MINIMIZEEND
            , "UInt", EVENT_SYSTEM_MINIMIZEEND
            , "Ptr", 0
            , "Ptr", g_minimizeEndEventCallback
            , "UInt", 0
            , "UInt", 0
            , "UInt", WINEVENT_OUTOFCONTEXT
            , "Ptr")
        if !g_minimizeEndEventHook
            LogWarn("minimizeend", "SetWinEventHook (EVENT_SYSTEM_MINIMIZEEND) returned NULL - restore-from-taskbar detection inactive; the FOREGROUND hook and 2000ms poll still cover the normal case. A_LastError=" A_LastError)
        else
            LogWarn("profwatch", "minimize-end event hook installed")
    } catch as e {
        LogWarn("minimizeend", "SetWinEventHook (EVENT_SYSTEM_MINIMIZEEND) threw: " e.Message " - restore-from-taskbar detection inactive.")
    }
}

CheckActiveProfileMinimizeEndProc(hWinEventHook, event, hwnd, idObject, idChild, dwEventThread, dwmsEventTime) {
    global g_pendingRestoredHwnd
    g_pendingRestoredHwnd := hwnd
    SetTimer(CheckActiveProfileForRestoredHwnd, -1)
}

CheckActiveProfileForRestoredHwnd() {
    global g_pendingRestoredHwnd, appWatchEnabled
    if !appWatchEnabled
        return
    hwnd := g_pendingRestoredHwnd
    if !hwnd || !DllCall("IsWindow", "ptr", hwnd)
        return
    try
        exeName := WinGetProcessName("ahk_id " hwnd)
    catch {
        return
    }
    ApplyActiveProfileForExeName(exeName, "restore")
}

CheckActiveProfileEventWatchOnExit(exitReason, exitCode) {
    global g_foregroundEventHook, g_minimizeEndEventHook
    if g_foregroundEventHook
        try DllCall("UnhookWinEvent", "Ptr", g_foregroundEventHook)
    if g_minimizeEndEventHook
        try DllCall("UnhookWinEvent", "Ptr", g_minimizeEndEventHook)
    return 0
}

SwitchActiveProfile(devTab, newName, deferRefresh := false) {
    global activeProfileNameByTab, buttonPressState, activeListByTag
    StopRepeatsForTab(devTab)
    oldName := activeProfileNameByTab.Has(devTab) ? activeProfileNameByTab[devTab] : "Default"
    ledResync := oldName != newName && activeListByTag.Has(devTab) && activeListByTag[devTab] != "Main"
        && LedSettingsDifferBetweenProfiles(devTab, oldName, newName)
    if ledResync
        ReleaseLedsForProfile(devTab, oldName)
    activeProfileNameByTab[devTab] := newName
    if newName != oldName
        InvalidateMouseBlockCache()
    newPressState := Map()
    for bk, st in buttonPressState {
        if DevTabForButtonKey(bk, KindForButtonKey(bk)) != devTab
            newPressState[bk] := st
    }
    buttonPressState := newPressState
    if !deferRefresh
        RefreshAllScHotkeyStates()
    UpdateActiveProfileStatus()
    if ledResync
        ApplyLedIndicatorForTag(devTab)
}

KindForButtonKey(buttonKey) => SubStr(buttonKey, 1, 4) = "RAW_" ? "raw" : (IsMouseButtonKey(buttonKey) ? "mouse" : "sc")

StopRepeatsForTab(devTab) {
    global repeatActive, mappings
    ReleaseHoldsForTab(devTab)
    for id, isOn in repeatActive.Clone() {
        if !isOn
            continue
        if mappings.Has(id) && (MapDevTab(mappings[id])) != devTab
            continue
        StopRepeat(id)
    }
}

ReleaseHoldsForTab(devTab) {
    global heldMappings, mappings
    for id, upStr in heldMappings.Clone() {
        if mappings.Has(id) && (MapDevTab(mappings[id])) != devTab
            continue
        Send(upStr)
        heldMappings.Delete(id)
    }
}

UpdateActiveProfileStatus() {
    global activeProfileNameByTab, DEVICE_TAGS, spGuardStatus
    parts := []
    for tag in DEVICE_TAGS
        parts.Push(tag ": " activeProfileNameByTab[tag])
    summary := StrJoin(parts, "  |  ")
    if !spGuardStatus.desktopHook || !spGuardStatus.wtsNotify {
        missing := []
        if !spGuardStatus.desktopHook
            missing.Push("desktop-switch")
        if !spGuardStatus.wtsNotify
            missing.Push("session-change")
        summary .= "  |  " Chr(0x26A0) " Stuck-key guard inactive (" StrJoin(missing, ", ") ") - see mapper.log"
    }
    if IsObject(txtActiveProfile) && DllCall("IsWindowVisible", "ptr", g.Hwnd)
        txtActiveProfile.Value := "Active Profiles: " summary
    A_IconTip := "MF Button Mapper (" StrJoin(parts, " | ") ")"
}

DestroyGuiControl(ctrl) {
    DllCall("DestroyWindow", "Ptr", ctrl.Hwnd)
}

SetAppWatchEnabled(val) {
    global appWatchEnabled
    appWatchEnabled := !!val
    chkAppWatch.Value := appWatchEnabled
    if appWatchEnabled
        A_TrayMenu.Check("Enable App-Based Auto Profile Switching")
    else
        A_TrayMenu.Uncheck("Enable App-Based Auto Profile Switching")
    SaveAppWatchEnabled()
    CheckActiveProfile("toggle")
    txtStatus.Value := appWatchEnabled
        ? "App-based profile switching enabled - profiles will follow the foreground app."
        : "App-based profile switching disabled - Default profile is always active."
}

ToggleAppWatchFromTray(*) {
    SetAppWatchEnabled(!appWatchEnabled)
}

SetDisableMultiMapWarning(val) {
    global disableMultiMapWarning
    disableMultiMapWarning := !!val
    chkDisableMultiMapWarning.Value := disableMultiMapWarning
    SaveDisableMultiMapWarning()
}

TestSend(*) {
    global currentMacroSteps, ACTION_APP, ACTION_MACRO, ACTION_MOUSE
    global ACTION_PS, ACTION_CMD, currentPsScriptBody, currentCmdScriptBody
    global currentPsScriptHide, currentCmdScriptHide
    if ddlActionType.Value = ACTION_PS || ddlActionType.Value = ACTION_CMD {
        isPsTest := ddlActionType.Value = ACTION_PS
        testBody := isPsTest ? currentPsScriptBody : currentCmdScriptBody
        if Trim(testBody, " `t`r`n") = "" {
            MsgBox(isPsTest ? "Choose a saved PS Script from the dropdown, or write one via PS Scripts, first." : "Choose a saved CMD entry from the dropdown, or write one via CMD, first.", "Nothing to run", "Icon!")
            return
        }
        testHide := isPsTest ? currentPsScriptHide : currentCmdScriptHide
        if isPsTest
            RunPsScript(testBody, testHide)
        else
            RunCmdScript(testBody, testHide)
        txtStatus.Value := "Ran " (isPsTest ? "PS Script" : "CMD") (testHide ? " (test, hidden)." : " (test).")
        return
    }
    if ddlActionType.Value = ACTION_APP {
        path := editAppPath.Value
        if path = "" {
            MsgBox("Enter an app/file path first.", "Nothing to launch", "Icon!")
            return
        }
        LaunchApp(path, editAppArgs.Value)
        txtStatus.Value := "Launched: " path
        return
    }
    if ddlActionType.Value = ACTION_MACRO {
        if currentMacroSteps.Length = 0 {
            MsgBox("Add at least one step with Edit Macro... first.", "Nothing to run", "Icon!")
            return
        }
        stepsCopy := currentMacroSteps
        ToolTip("Switch to a text field now`nRunning macro in 3 seconds...")
        SetTimer(() => TestSendRunMacro(stepsCopy), -3000)
        return
    }
    t := ddlActionType.Value = ACTION_MOUSE ? MouseTargetFromForm() : targetSendString
    if IsCursorSpeedTarget(t) {
        RunCursorSpeedTarget(t)
        return
    }
    if t = "" {
        MsgBox("Capture a target key/combo first.", "Nothing to send", "Icon!")
        return
    }
    ToolTip("Switch to a text field now`nSending in 3 seconds...")
    SetTimer(() => (ToolTip(), Send(t)), -3000)
}

TestSendRunMacro(steps) {
    ToolTip()
    RunMacroOnce(steps)
}

JoinCsv(arr) {
    s := ""
    for i, v in arr {
        if i > 1
            s .= ","
        s .= v
    }
    return s
}

SaveKeymapColumnWidths() {
    global lvColW1, lvColW2, lvColW3, lvColW4
    if !PersistenceAllowed(false)
        return
    lvColW1 := LV_GetColumnWidth(lv, 1)
    lvColW2 := LV_GetColumnWidth(lv, 2)
    lvColW3 := LV_GetColumnWidth(lv, 3)
    lvColW4 := LV_GetColumnWidth(lv, 4)
    try {
        sf := SettingsFile()
        IniWrite(lvColW1, sf, "Settings", "LvColW1")
        IniWrite(lvColW2, sf, "Settings", "LvColW2")
        IniWrite(lvColW3, sf, "Settings", "LvColW3")
        IniWrite(lvColW4, sf, "Settings", "LvColW4")
    } catch as e {
        LogWarn("save", "SaveKeymapColumnWidths: " e.Message)
    }
}

SaveMacroColumnWidths() {
    global macroLvColW1, macroLvColW2, macroLvColW3, macroLvColW4
    if !PersistenceAllowed(false)
        return
    try {
        sf := SettingsFile()
        IniWrite(macroLvColW1, sf, "Settings", "MacroLvColW1")
        IniWrite(macroLvColW2, sf, "Settings", "MacroLvColW2")
        IniWrite(macroLvColW3, sf, "Settings", "MacroLvColW3")
        IniWrite(macroLvColW4, sf, "Settings", "MacroLvColW4")
    } catch as e {
        LogWarn("save", "SaveMacroColumnWidths: " e.Message)
    }
}

ComputeAllProfileKeys() {
    global profiles, profileOrder, mapOrder, mappings
    seenProfiles := Map()
    allProfileKeys := []
    for pkey in profileOrder {
        if profiles.Has(pkey) && !seenProfiles.Has(pkey) {
            seenProfiles[pkey] := true
            allProfileKeys.Push(pkey)
        }
    }
    for pkey, pdata in profiles {
        if !seenProfiles.Has(pkey) {
            seenProfiles[pkey] := true
            allProfileKeys.Push(pkey)
        }
    }
    for key in mapOrder {
        mp := MapProfileKey(mappings[key])
        if !seenProfiles.Has(mp) {
            seenProfiles[mp] := true
            allProfileKeys.Push(mp)
        }
    }
    return allProfileKeys
}

SaveEditingDevTab() {
    global editingDevTab
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(editingDevTab, SettingsFile(), "Settings", "EditingDevTab")
    } catch as e {
        LogWarn("save", "SaveEditingDevTab: " e.Message)
    }
}

SaveAppWatchEnabled() {
    global appWatchEnabled
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(appWatchEnabled ? "1" : "0", SettingsFile(), "Settings", "AppWatchEnabled")
    } catch as e {
        LogWarn("save", "SaveAppWatchEnabled: " e.Message)
    }
}

SaveDisableMultiMapWarning() {
    global disableMultiMapWarning
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(disableMultiMapWarning ? "1" : "0", SettingsFile(), "Settings", "DisableMultiMapWarning")
    } catch as e {
        LogWarn("save", "SaveDisableMultiMapWarning: " e.Message)
    }
}

SaveNotifyModifierToggleForTag(tag) {
    global notifyModifierToggleByTag
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(notifyModifierToggleByTag[tag] ? "1" : "0", SettingsFile(), "Settings", "NotifyModifierToggle_" tag)
    } catch as e {
        LogWarn("save", "SaveNotifyModifierToggleForTag(" tag "): " e.Message)
    }
}

SaveProfileOrderSetting() {
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(JoinCsv(ComputeAllProfileKeys()), SettingsFile(), "Settings", "ProfileOrder")
    } catch as e {
        LogWarn("save", "SaveProfileOrderSetting: " e.Message)
    }
}

SaveMacros() {
    global savedMacros, savedMacroOrder
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    mf := MacrosFile()
    content := "[Macros]`r`n"
    content .= "Names=" JoinCsv(savedMacroOrder) "`r`n"
    content .= "`r`n"
    for name in savedMacroOrder {
        content .= "[Macro::" name "]`r`n"
        content .= "Steps=" MacroStepsEncode(savedMacros[name]) "`r`n"
        content .= "`r`n"
    }
    errMsg := ""
    if !WriteFileAtomic(mf, content, &errMsg) {
        LogWarn("save", mf ": " errMsg)
        NotifySaveFailure(mf, errMsg)
    }
}

SavePsScripts() {
    global savedPsScripts, savedPsScriptOrder, savedPsScriptHide
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    pf := PsScriptsFile()
    content := "[Scripts]`r`n"
    content .= "Names=" JoinCsv(savedPsScriptOrder) "`r`n"
    content .= "`r`n"
    for name in savedPsScriptOrder {
        content .= "[Script::" name "]`r`n"
        content .= "Body=" MacroStepsEscapeField(savedPsScripts[name]) "`r`n"
        content .= "Hide=" (savedPsScriptHide.Has(name) && savedPsScriptHide[name] ? "1" : "0") "`r`n"
        content .= "`r`n"
    }
    errMsg := ""
    if !WriteFileAtomic(pf, content, &errMsg) {
        LogWarn("save", pf ": " errMsg)
        NotifySaveFailure(pf, errMsg)
    }
}

SaveCmdScripts() {
    global savedCmdScripts, savedCmdScriptOrder, savedCmdScriptHide
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    cf := CmdScriptsFile()
    content := "[Scripts]`r`n"
    content .= "Names=" JoinCsv(savedCmdScriptOrder) "`r`n"
    content .= "`r`n"
    for name in savedCmdScriptOrder {
        content .= "[Script::" name "]`r`n"
        content .= "Body=" MacroStepsEscapeField(savedCmdScripts[name]) "`r`n"
        content .= "Hide=" (savedCmdScriptHide.Has(name) && savedCmdScriptHide[name] ? "1" : "0") "`r`n"
        content .= "`r`n"
    }
    errMsg := ""
    if !WriteFileAtomic(cf, content, &errMsg) {
        LogWarn("save", cf ": " errMsg)
        NotifySaveFailure(cf, errMsg)
    }
}

MappingIniFields(m) {
    kind := MapKind(m)
    actionType := MapActionType(m)
    targetOut := (actionType = "ps" || actionType = "cmd") ? MacroStepsEscapeField(m.target) : m.target
    fields := [
        {key: "Kind", value: kind},
        {key: "ActionType", value: actionType},
        {key: "Desc", value: m.desc},
        {key: "Target", value: targetOut},
        {key: "AppArgs", value: MapAppArgs(m)},
        {key: "Enabled", value: m.enabled ? "1" : "0"},
        {key: "PressType", value: MapPressType(m)},
        {key: "List", value: MapList(m)},
        {key: "DevTab", value: MapDevTab(m)},
        {key: "RunMode", value: MapRunMode(m)},
        {key: "RepeatMs", value: MapRepeatMs(m)},
        {key: "DelayEnabled", value: MapDelayEnabled(m) ? "1" : "0"},
        {key: "DelayMs", value: MapDelayMs(m)},
        {key: "LongPressMs", value: MapLongPressMs(m)},
    ]
    if actionType = "macro" {
        fields.Push({key: "MacroName", value: MapMacroName(m)})
        fields.Push({key: "MacroSteps", value: MacroStepsEncode(ResolveMacroSteps(m))})
    }
    if actionType = "ps" || actionType = "cmd" {
        fields.Push({key: "ScriptName", value: MapScriptName(m)})
        fields.Push({key: "HideWindow", value: MapHideWindow(m) ? "1" : "0"})
    }
    if kind = "raw" {
        fields.Push({key: "Page", value: m.page})
        fields.Push({key: "BytesHex", value: m.bytesHex})
        fields.Push({key: "UpBytesHex", value: MapUpBytesHex(m)})
    } else if kind = "mouse" {
        fields.Push({key: "Button", value: MapButton(m)})
    } else {
        fields.Push({key: "ScHex", value: Format("{:X}", m.sc)})
    }
    return fields
}

SyntheticMappingForSelfTest(kind, actionType) {
    m := {
        kind: kind,
        actionType: actionType,
        desc: "F-11b self-test desc",
        target: "F-11b self-test target",
        appArgs: "--f11b-self-test",
        enabled: true,
        pressType: "short",
        list: "Main",
        devTab: "Keyboard",
        runMode: "single",
        repeatMs: 137,
        delayEnabled: true,
        delayMs: 246,
        longPressMs: 611,
    }
    if actionType = "macro" {
        m.macroName := ""
        m.macroSteps := [
            {type: "key", target: "a|b~c\d", args: "arg1|arg2", delayAfterMs: 10},
            {type: "key", target: "e", args: "", delayAfterMs: 20},
        ]
    }
    if actionType = "ps" || actionType = "cmd" {
        m.scriptName := "PSX-3b-2 self-test script"
        m.hideWindow := true
        m.target := "line one" "`n" "line two with a \backslash, a | pipe and 100%" "`n" "[not-a-section]"
    }
    if kind = "raw" {
        m.page := 1
        m.bytesHex := "0102"
        m.upBytesHex := "0304"
    } else if kind = "mouse" {
        m.button := "MButton"
    } else {
        m.sc := 0x1E
    }
    return m
}

MappingIniSelfTest(*) {
    kinds := ["sc", "raw", "mouse"]
    actionTypes := ["key", "app", "multimedia", "mouse", "macro", "ps", "cmd"]
    failures := []
    casesRun := 0

    for kind in kinds {
        for actionType in actionTypes {
            casesRun += 1
            m := SyntheticMappingForSelfTest(kind, actionType)
            section := "F11bSelfTest"
            fields := MappingIniFields(m)

            textA := FormatMappingSection(section, m)
            fileA := A_Temp "\RBM_F11bSelfTest_A_" A_TickCount "_" A_Index ".ini"
            try FileDelete(fileA)
            FileAppend(textA, fileA, "UTF-8-RAW")

            fileB := A_Temp "\RBM_F11bSelfTest_B_" A_TickCount "_" A_Index ".ini"
            try FileDelete(fileB)
            WriteMappingSection(fileB, section, m)

            for f in fields {
                expected := String(f.value)
                gotA := ""
                gotB := ""
                try gotA := IniRead(fileA, section, f.key)
                catch as e
                    failures.Push(kind "/" actionType ": key '" f.key "' missing from Path A (FormatMappingSection) temp file - " e.Message)
                try gotB := IniRead(fileB, section, f.key)
                catch as e
                    failures.Push(kind "/" actionType ": key '" f.key "' missing from Path B (WriteMappingSection) temp file - " e.Message)
                if gotA != expected
                    failures.Push(kind "/" actionType ": key '" f.key "' - Path A (FormatMappingSection) read back '" gotA "', expected '" expected "'")
                if gotB != expected
                    failures.Push(kind "/" actionType ": key '" f.key "' - Path B (WriteMappingSection) read back '" gotB "', expected '" expected "'")
                if gotA != gotB
                    failures.Push(kind "/" actionType ": key '" f.key "' - Path A and Path B disagree ('" gotA "' vs '" gotB "')")
            }

            if actionType = "ps" || actionType = "cmd" {
                decodedA := ""
                decodedB := ""
                try decodedA := MacroStepsUnescapeField(IniRead(fileA, section, "Target"))
                try decodedB := MacroStepsUnescapeField(IniRead(fileB, section, "Target"))
                if decodedA != m.target
                    failures.Push(kind "/" actionType ": Target did not decode back to the original script body from Path A (FormatMappingSection)")
                if decodedB != m.target
                    failures.Push(kind "/" actionType ": Target did not decode back to the original script body from Path B (WriteMappingSection)")
            }

            try FileDelete(fileA)
            try FileDelete(fileB)
        }
    }

    if failures.Length = 0 {
        msg := "MappingIniFields() round-trip self-test: all " casesRun " kind x actionType combination(s) agree between FormatMappingSection() and WriteMappingSection()."
        MsgBox(msg, "Mapping .ini self-test", "Iconi")
        LogWarn("F-11b", "self-test passed: " casesRun " cases, all agree")
    } else {
        shown := failures[1]
        msg := "MappingIniFields() round-trip self-test FAILED (" failures.Length " mismatch(es) across " casesRun " case(s)):`n`n" shown
        if failures.Length > 1
            msg .= "`n`n(" (failures.Length - 1) " more mismatch(es) - see log.)"
        MsgBox(msg, "Mapping .ini self-test", "Iconx")
        for f in failures
            LogWarn("F-11b", "self-test FAILED: " f)
    }
}

MappingSectionName(key) => (dpos := InStr(key, "::")) ? SubStr(key, dpos + 2) : key

SaveProfileMapping(pkey, key) {
    global mappings, profileFiles
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    if !profileFiles.Has(pkey) {
        RebuildProfileIndex()
        return
    }
    if !mappings.Has(key)
        return
    pf := profileFiles[pkey]
    if !FileExist(pf) {
        SaveProfile(pkey)
        return
    }
    section := MappingSectionName(key)
    WriteMappingSection(pf, section, mappings[key])

    found := false
    order := []
    for s in StrSplit(IniRead(pf, "Profile", "Order", ""), ",") {
        s := Trim(s)
        if s = ""
            continue
        if s = section
            found := true
        order.Push(s)
    }
    if !found {
        order.Push(section)
        IniWrite(JoinCsv(order), pf, "Profile", "Order")
    }
}

SaveProfileOrder(pkey) {
    global mapOrder, mappings, profileFiles
    if !PersistenceAllowed()
        return
    if !profileFiles.Has(pkey)
        return
    pf := profileFiles[pkey]
    if !FileExist(pf)
        return
    orderList := []
    for key in mapOrder {
        if (MapProfileKey(mappings[key])) != pkey
            continue
        orderList.Push(MappingSectionName(key))
    }
    IniWrite(JoinCsv(orderList), pf, "Profile", "Order")
}

DeleteProfileMappingSection(pkey, key) {
    global profileFiles
    if !PersistenceAllowed()
        return
    if !profileFiles.Has(pkey) {
        RebuildProfileIndex()
        return
    }
    pf := profileFiles[pkey]
    if !FileExist(pf)
        return
    section := MappingSectionName(key)
    try
        IniDelete(pf, section)
    catch as e
        LogWarn("profile", pf ": IniDelete(" section ") failed: " e.Message)
    order := []
    for s in StrSplit(IniRead(pf, "Profile", "Order", ""), ",") {
        s := Trim(s)
        if s != "" && s != section
            order.Push(s)
    }
    IniWrite(JoinCsv(order), pf, "Profile", "Order")
}

SaveProfiles(pkeys) {
    seen := Map()
    for pkey in pkeys {
        if seen.Has(pkey)
            continue
        seen[pkey] := true
        SaveProfile(pkey)
    }
}

DistinctProfilesOf(keys) {
    global mappings
    seen := Map()
    out := []
    for key in keys {
        p := MapProfileKey(mappings[key])
        if !seen.Has(p) {
            seen[p] := true
            out.Push(p)
        }
    }
    return out
}

ApplyLoadedStateToUI() {
    lv.ModifyCol(1, lvColW1)
    lv.ModifyCol(2, lvColW2)
    lv.ModifyCol(3, lvColW3)
    lv.ModifyCol(4, lvColW4)
    chkMaster.Value := masterEnabled
    if masterEnabled
        A_TrayMenu.Check("Remapping Enabled")
    else
        A_TrayMenu.Uncheck("Remapping Enabled")
    chkStartHidden.Value := startHidden
    if startHidden
        A_TrayMenu.Check("Start Hidden")
    else
        A_TrayMenu.Uncheck("Start Hidden")
    chkAppWatch.Value := appWatchEnabled
    if appWatchEnabled
        A_TrayMenu.Check("Enable App-Based Auto Profile Switching")
    else
        A_TrayMenu.Uncheck("Enable App-Based Auto Profile Switching")
    chkDisableMultiMapWarning.Value := disableMultiMapWarning
    chkRunElevated.Value := runElevated
    UpdateLedIndicatorOptionForTag()
    UpdateNotifyModifierToggleOptionForTag()
    chkRunStartup.Value := runAtStartup
    ddlRunStartupMode.Choose(runAtStartupMode = "admin" ? 2 : 1)
    RefreshLaunchOnExitUI()
    RefreshTerminateAppsUI()
    if runAtStartup {
        if runAtStartupMode = "admin" {
            if !IsStartupTaskRegistered()
                SetStartupTask(true)
        } else {
            if !FileExist(StartupShortcutPath())
                CreateStartupShortcut()
        }
    }
    edLongPressMs.Value := legacyLongPressMs
    tabDevFilter.Value := (editingDevTab = "Mouse") ? 1 : (editingDevTab = "Keyboard") ? 2 : 3
    UpdateMacroSelectDdl()
    UpdatePsScriptSelectDdl()
    UpdateCmdScriptSelectDdl()
}

LoadSettingsSection(sf) {
    global masterEnabled, startHidden, legacyLongPressMs, MinHoldReleaseGapMs
    global appWatchEnabled, disableMultiMapWarning
    global nativeMouseHookSetting
    global kbdListGateOn
    global notifyModifierToggleByTag, DEVICE_TAGS
    global ledIndicatorChoiceByTag
    global ledIndicatorChoiceByTag2
    global lockFlashEnabledByTagSlot, lockFlashIntervalMsByTagSlot
    global capsLockLedDeviceIndex, runElevated, runAtStartup, runAtStartupMode
    global launchOnExitApps, launchOnExitSelected
    global modifierKind, modifierSc, modifierRawPage, modifierRawBytesHex, modifierRawUpBytesHex, modifierMode
    global deviceModifiers, deviceModifiers2, mod1HeldByTag, mod2HeldByTag, heldOwnerByTag
    global lvColW1, lvColW2, lvColW3, lvColW4
    global macroLvColW1, macroLvColW2, macroLvColW3, macroLvColW4
    global editingDevTab

    masterEnabled := IniRead(sf, "Settings", "MasterEnabled", "1") = "1"
    startHidden := IniRead(sf, "Settings", "StartHidden", "0") = "1"
    longPressMsRaw := IniRead(sf, "Settings", "LongPressMs", "500")
    legacyLongPressMs := IsInteger(longPressMsRaw) ? Integer(longPressMsRaw) : 500
    minHoldGapRaw := IniRead(sf, "Settings", "MinHoldReleaseGapMs", "100")
    MinHoldReleaseGapMs := IsInteger(minHoldGapRaw) ? Integer(minHoldGapRaw) : 100
    appWatchEnabled := IniRead(sf, "Settings", "AppWatchEnabled", "0") = "1"
    disableMultiMapWarning := IniRead(sf, "Settings", "DisableMultiMapWarning", "0") = "1"
    nativeMouseHookSetting := NativeMouseHookNormalizeSetting(IniRead(sf, "Settings", "NativeMouseHook", "On"))
    kbdListGateOn := StrLower(Trim(IniRead(sf, "Settings", "KeyboardListGate", "On"))) != "off"
    anyNewNotifySettingPresent := false
    for tag in DEVICE_TAGS {
        if IniRead(sf, "Settings", "NotifyModifierToggle_" tag, "") != ""
            anyNewNotifySettingPresent := true
    }
    if !anyNewNotifySettingPresent {
        legacyNotify := IniRead(sf, "Settings", "NotifyModifierToggle", "0") = "1"
        for tag in DEVICE_TAGS
            notifyModifierToggleByTag[tag] := legacyNotify
    } else {
        for tag in DEVICE_TAGS
            notifyModifierToggleByTag[tag] := IniRead(sf, "Settings", "NotifyModifierToggle_" tag, "0") = "1"
    }
    anyNewLedSettingPresent := false
    for tag in DEVICE_TAGS {
        if IniRead(sf, "Settings", "LedIndicatorChoice_" tag, "") != ""
            anyNewLedSettingPresent := true
    }
    if anyNewLedSettingPresent {
        for tag in DEVICE_TAGS
            ledIndicatorChoiceByTag[tag] := IniRead(sf, "Settings", "LedIndicatorChoice_" tag, "Off")
    } else {
        anyOldPerTagLedSettingPresent := false
        for tag in DEVICE_TAGS {
            if IniRead(sf, "Settings", "SendScrollLockOnModifierToggle_" tag, "") != "" || IniRead(sf, "Settings", "SendCapsLockOnModifierToggle_" tag, "") != ""
                anyOldPerTagLedSettingPresent := true
        }
        if anyOldPerTagLedSettingPresent {
            for tag in DEVICE_TAGS {
                oldScrollLock := IniRead(sf, "Settings", "SendScrollLockOnModifierToggle_" tag, "0") = "1"
                oldCapsLock := IniRead(sf, "Settings", "SendCapsLockOnModifierToggle_" tag, "0") = "1"
                ledIndicatorChoiceByTag[tag] := oldCapsLock ? "CapsLock" : (oldScrollLock ? "ScrollLock" : "Off")
            }
        } else {
            legacyScrollLock := IniRead(sf, "Settings", "SendScrollLockOnModifierToggle", "0") = "1"
            legacyCapsLock := IniRead(sf, "Settings", "SendCapsLockOnModifierToggle", "0") = "1"
            legacyChoice := legacyCapsLock ? "CapsLock" : (legacyScrollLock ? "ScrollLock" : "Off")
            for tag in DEVICE_TAGS
                ledIndicatorChoiceByTag[tag] := legacyChoice
        }
    }
    for tag in DEVICE_TAGS {
        lockFlashEnabledByTagSlot["ScrollLock"][tag][1] := IniRead(sf, "Settings", "ScrollLockFlashEnabled_" tag, "0") = "1"
        scrollFlashRaw := IniRead(sf, "Settings", "ScrollLockFlashIntervalMs_" tag, "500")
        lockFlashIntervalMsByTagSlot["ScrollLock"][tag][1] := IsInteger(scrollFlashRaw) ? Integer(scrollFlashRaw) : 500
        lockFlashEnabledByTagSlot["CapsLock"][tag][1] := IniRead(sf, "Settings", "CapsLockFlashEnabled_" tag, "0") = "1"
        capsFlashRaw := IniRead(sf, "Settings", "CapsLockFlashIntervalMs_" tag, "500")
        lockFlashIntervalMsByTagSlot["CapsLock"][tag][1] := IsInteger(capsFlashRaw) ? Integer(capsFlashRaw) : 500
        lockFlashEnabledByTagSlot["NumLock"][tag][1] := IniRead(sf, "Settings", "NumLockFlashEnabled_" tag, "0") = "1"
        numFlashRaw := IniRead(sf, "Settings", "NumLockFlashIntervalMs_" tag, "500")
        lockFlashIntervalMsByTagSlot["NumLock"][tag][1] := IsInteger(numFlashRaw) ? Integer(numFlashRaw) : 500
    }
    for tag in DEVICE_TAGS {
        ledIndicatorChoiceByTag2[tag] := IniRead(sf, "Settings", "LedIndicatorChoice2_" tag, "Off")
        lockFlashEnabledByTagSlot["ScrollLock"][tag][2] := IniRead(sf, "Settings", "ScrollLockFlashEnabled2_" tag, "0") = "1"
        scrollFlashRaw2 := IniRead(sf, "Settings", "ScrollLockFlashIntervalMs2_" tag, "500")
        lockFlashIntervalMsByTagSlot["ScrollLock"][tag][2] := IsInteger(scrollFlashRaw2) ? Integer(scrollFlashRaw2) : 500
        lockFlashEnabledByTagSlot["CapsLock"][tag][2] := IniRead(sf, "Settings", "CapsLockFlashEnabled2_" tag, "0") = "1"
        capsFlashRaw2 := IniRead(sf, "Settings", "CapsLockFlashIntervalMs2_" tag, "500")
        lockFlashIntervalMsByTagSlot["CapsLock"][tag][2] := IsInteger(capsFlashRaw2) ? Integer(capsFlashRaw2) : 500
        lockFlashEnabledByTagSlot["NumLock"][tag][2] := IniRead(sf, "Settings", "NumLockFlashEnabled2_" tag, "0") = "1"
        numFlashRaw2 := IniRead(sf, "Settings", "NumLockFlashIntervalMs2_" tag, "500")
        lockFlashIntervalMsByTagSlot["NumLock"][tag][2] := IsInteger(numFlashRaw2) ? Integer(numFlashRaw2) : 500
    }
    capsLockLedIdxRaw := IniRead(sf, "Settings", "CapsLockLedDeviceIndex", "0")
    capsLockLedDeviceIndex := (IsInteger(capsLockLedIdxRaw) && Integer(capsLockLedIdxRaw) >= 0) ? Integer(capsLockLedIdxRaw) : 0
    runElevated := IniRead(sf, "Settings", "RunElevated", "0") = "1"
    runAtStartup := IniRead(sf, "Settings", "RunAtStartup", "0") = "1"
    runAtStartupMode := IniRead(sf, "Settings", "RunAtStartupMode", "shortcut")
    for lApp in launchOnExitApps
        launchOnExitSelected[lApp.key] := IniRead(sf, "Settings", "LaunchOnExit_" lApp.key, "0") = "1"
    for tApp in terminateApps
        terminateAppsSelected[tApp.key] := IniRead(sf, "Settings", "TerminateOnStart_" tApp.key, "0") = "1"
    modifierKind := IniRead(sf, "Settings", "ModifierKind", "none")
    modifierScRaw := IniRead(sf, "Settings", "ModifierSc", "0")
    modifierSc := IsXDigit(modifierScRaw) ? Integer("0x" modifierScRaw) : 0
    modifierRawPageRaw := IniRead(sf, "Settings", "ModifierRawPage", "0")
    modifierRawPage := IsXDigit(modifierRawPageRaw) ? Integer("0x" modifierRawPageRaw) : 0
    modifierRawBytesHex := IniRead(sf, "Settings", "ModifierRawBytesHex", "")
    modifierRawUpBytesHex := IniRead(sf, "Settings", "ModifierRawUpBytesHex", "")
    modifierMode := IniRead(sf, "Settings", "ModifierMode", "toggle")
    anyNewModifierSectionPresent := false
    for tag in DEVICE_TAGS {
        if IniRead(sf, "Modifier_" tag, "Kind", "") != ""
            anyNewModifierSectionPresent := true
    }
    if !anyNewModifierSectionPresent {
        for tag in DEVICE_TAGS
            deviceModifiers[tag] := {kind: modifierKind, sc: modifierSc, rawPage: modifierRawPage, rawBytesHex: modifierRawBytesHex, rawUpBytesHex: modifierRawUpBytesHex, mode: modifierMode, lpOn: false, lpMs: 500, ptOn: false}
    } else {
        for tag in DEVICE_TAGS {
            dmSection := "Modifier_" tag
            dmKind := IniRead(sf, dmSection, "Kind", "none")
            dmScRaw := IniRead(sf, dmSection, "Sc", "0")
            dmSc := IsXDigit(dmScRaw) ? Integer("0x" dmScRaw) : 0
            dmRawPageRaw := IniRead(sf, dmSection, "RawPage", "0")
            dmRawPage := IsXDigit(dmRawPageRaw) ? Integer("0x" dmRawPageRaw) : 0
            dmRawBytesHex := IniRead(sf, dmSection, "RawBytesHex", "")
            dmRawUpBytesHex := IniRead(sf, dmSection, "RawUpBytesHex", "")
            dmMode := IniRead(sf, dmSection, "Mode", "toggle")
            dmLpOn := IniRead(sf, dmSection, "LongPress", "0") = "1"
            dmLpMsRaw := IniRead(sf, dmSection, "LongPressMs", "500")
            dmLpMs := (IsInteger(dmLpMsRaw) && Integer(dmLpMsRaw) >= 1) ? Integer(dmLpMsRaw) : 500
            dmPtOn := IniRead(sf, dmSection, "Passthrough", "0") = "1"
            deviceModifiers[tag] := {kind: dmKind, sc: dmSc, rawPage: dmRawPage, rawBytesHex: dmRawBytesHex, rawUpBytesHex: dmRawUpBytesHex, mode: dmMode, lpOn: dmLpOn, lpMs: dmLpMs, ptOn: dmPtOn}
        }
    }
    for tag in DEVICE_TAGS {
        dm2Section := "Modifier2_" tag
        dm2Kind := IniRead(sf, dm2Section, "Kind", "none")
        dm2ScRaw := IniRead(sf, dm2Section, "Sc", "0")
        dm2Sc := IsXDigit(dm2ScRaw) ? Integer("0x" dm2ScRaw) : 0
        dm2RawPageRaw := IniRead(sf, dm2Section, "RawPage", "0")
        dm2RawPage := IsXDigit(dm2RawPageRaw) ? Integer("0x" dm2RawPageRaw) : 0
        dm2RawBytesHex := IniRead(sf, dm2Section, "RawBytesHex", "")
        dm2RawUpBytesHex := IniRead(sf, dm2Section, "RawUpBytesHex", "")
        dm2Mode := IniRead(sf, dm2Section, "Mode", "")
        if dm2Mode != "hold" && dm2Mode != "toggle"
            dm2Mode := ""
        dm2LpOn := IniRead(sf, dm2Section, "LongPress", "0") = "1"
        dm2LpMsRaw := IniRead(sf, dm2Section, "LongPressMs", "500")
        dm2LpMs := (IsInteger(dm2LpMsRaw) && Integer(dm2LpMsRaw) >= 1) ? Integer(dm2LpMsRaw) : 500
        dm2PtOn := IniRead(sf, dm2Section, "Passthrough", "0") = "1"
        deviceModifiers2[tag] := {kind: dm2Kind, sc: dm2Sc, rawPage: dm2RawPage, rawBytesHex: dm2RawBytesHex, rawUpBytesHex: dm2RawUpBytesHex, mode: dm2Mode, lpOn: dm2LpOn, lpMs: dm2LpMs, ptOn: dm2PtOn}
    }
    for tag in DEVICE_TAGS {
        mod1HeldByTag[tag] := false
        mod2HeldByTag[tag] := false
        heldOwnerByTag[tag] := ""
    }
    lvColW1Raw := IniRead(sf, "Settings", "LvColW1", lvColW1)
    lvColW1 := IsInteger(lvColW1Raw) ? Integer(lvColW1Raw) : lvColW1
    lvColW2Raw := IniRead(sf, "Settings", "LvColW2", lvColW2)
    lvColW2 := IsInteger(lvColW2Raw) ? Integer(lvColW2Raw) : lvColW2
    lvColW3Raw := IniRead(sf, "Settings", "LvColW3", lvColW3)
    lvColW3 := IsInteger(lvColW3Raw) ? Integer(lvColW3Raw) : lvColW3
    lvColW4Raw := IniRead(sf, "Settings", "LvColW4", lvColW4)
    lvColW4 := IsInteger(lvColW4Raw) ? Integer(lvColW4Raw) : lvColW4
    macroLvColW1Raw := IniRead(sf, "Settings", "MacroLvColW1", macroLvColW1)
    macroLvColW1 := IsInteger(macroLvColW1Raw) ? Integer(macroLvColW1Raw) : macroLvColW1
    macroLvColW2Raw := IniRead(sf, "Settings", "MacroLvColW2", macroLvColW2)
    macroLvColW2 := IsInteger(macroLvColW2Raw) ? Integer(macroLvColW2Raw) : macroLvColW2
    macroLvColW3Raw := IniRead(sf, "Settings", "MacroLvColW3", macroLvColW3)
    macroLvColW3 := IsInteger(macroLvColW3Raw) ? Integer(macroLvColW3Raw) : macroLvColW3
    macroLvColW4Raw := IniRead(sf, "Settings", "MacroLvColW4", macroLvColW4)
    macroLvColW4 := IsInteger(macroLvColW4Raw) ? Integer(macroLvColW4Raw) : macroLvColW4
    editingDevTabRaw := IniRead(sf, "Settings", "EditingDevTab", "Remote")
    editingDevTab := HasVal(["Mouse", "Keyboard", "Remote"], editingDevTabRaw) ? editingDevTabRaw : "Remote"
}

LoadMacros() {
    global savedMacros, savedMacroOrder

    savedMacros := Map()
    savedMacroOrder := []
    mf := MacrosFile()
    if FileExist(mf) {
        for mname in StrSplit(IniRead(mf, "Macros", "Names", ""), ",") {
            mname := Trim(mname)
            if mname = ""
                continue
            savedMacroOrder.Push(mname)
            savedMacros[mname] := MacroStepsDecode(IniRead(mf, "Macro::" mname, "Steps", ""))
        }
    }
}

LoadPsScripts() {
    global savedPsScripts, savedPsScriptOrder, savedPsScriptHide

    savedPsScripts := Map()
    savedPsScriptHide := Map()
    savedPsScriptOrder := []
    pf := PsScriptsFile()
    if FileExist(pf) {
        for sname in StrSplit(IniRead(pf, "Scripts", "Names", ""), ",") {
            sname := Trim(sname)
            if sname = ""
                continue
            savedPsScriptOrder.Push(sname)
            savedPsScripts[sname] := MacroStepsUnescapeField(IniRead(pf, "Script::" sname, "Body", ""))
            savedPsScriptHide[sname] := IniRead(pf, "Script::" sname, "Hide", "0") = "1"
        }
    }
}

LoadCmdScripts() {
    global savedCmdScripts, savedCmdScriptOrder, savedCmdScriptHide

    savedCmdScripts := Map()
    savedCmdScriptHide := Map()
    savedCmdScriptOrder := []
    cf := CmdScriptsFile()
    if FileExist(cf) {
        for sname in StrSplit(IniRead(cf, "Scripts", "Names", ""), ",") {
            sname := Trim(sname)
            if sname = ""
                continue
            savedCmdScriptOrder.Push(sname)
            savedCmdScripts[sname] := MacroStepsUnescapeField(IniRead(cf, "Script::" sname, "Body", ""))
            savedCmdScriptHide[sname] := IniRead(cf, "Script::" sname, "Hide", "0") = "1"
        }
    }
}

MigrateFlatProfileFiles(fileByKey, foundOrder, migratedToTabFolder) {
    rootFiles := []
    Loop Files, ProfilesDir() "\*.ini"
        rootFiles.Push({path: A_LoopFilePath, name: A_LoopFileName})
    for rf in rootFiles {
        pname := Trim(IniRead(rf.path, "Profile", "Name", ""))
        if pname = ""
            pname := RegExReplace(rf.name, "i)\.ini$", "")
        if pname = "" || InStr(pname, "::")
            continue
        if pname = "Default" {
            if !fileByKey.Has("Default") {
                fileByKey["Default"] := rf.path
                foundOrder.Push("Default")
            }
            continue
        }
        dtRaw := Trim(IniRead(rf.path, "Profile", "DevTab", ""))
        dt := HasVal(DEVICE_TAGS, dtRaw) ? dtRaw : "Remote"
        dest := ProfileTabDir(dt) "\" rf.name
        if FileExist(dest) {
            fbase := RegExReplace(rf.name, "i)\.ini$", "")
            n := 2
            while FileExist(ProfileTabDir(dt) "\" fbase "_" n ".ini")
                n += 1
            dest := ProfileTabDir(dt) "\" fbase "_" n ".ini"
        }
        try {
            FileMove(rf.path, dest)
            migratedToTabFolder.Push(pname " -> " dt)
        } catch as e {
            LogWarn("load", rf.path ": could not migrate to " dt " folder: " e.Message)
        }
    }
}

ScanProfileFiles(sf, fileByKey, foundOrder) {
    global profileFiles, profileOrder, DEVICE_TAGS

    for tag in DEVICE_TAGS {
        Loop Files, ProfileTabDir(tag) "\*.ini" {
            pname := Trim(IniRead(A_LoopFilePath, "Profile", "Name", ""))
            if pname = ""
                pname := RegExReplace(A_LoopFileName, "i)\.ini$", "")
            if pname = "" || InStr(pname, "::") || pname = "Default"
                continue
            pkey := ProfileKey(tag, pname)
            if fileByKey.Has(pkey)
                continue
            fileByKey[pkey] := A_LoopFilePath
            foundOrder.Push(pkey)
        }
    }
    profileFiles := fileByKey.Clone()

    ordered := []
    taken := Map()
    for pkey in StrSplit(IniRead(sf, "Settings", "ProfileOrder", ""), ",") {
        pkey := Trim(pkey)
        if pkey = "" || taken.Has(pkey) || !fileByKey.Has(pkey)
            continue
        taken[pkey] := true
        ordered.Push(pkey)
    }
    for pkey in foundOrder {
        if taken.Has(pkey)
            continue
        taken[pkey] := true
        ordered.Push(pkey)
    }
    profileOrder := ordered.Clone()

    return ordered
}

LoadProfileRecords(sf, ordered, fileByKey, migratedDevTabProfiles, failedProfiles) {
    global profiles, failedLoadProfiles

    profiles := Map("Default", {processNames: []})
    profileContexts := []

    for pkey in ordered {
        pf := fileByKey[pkey]
        pname := ProfileKeyName(pkey)
        pTab := ProfileKeyTab(pkey)
        try {
        procList := []
        for p in StrSplit(IniRead(pf, "Profile", "ProcessNames", ""), ",") {
            p := Trim(p)
            if p != ""
                procList.Push(p)
        }
        modKind := IniRead(pf, "Profile", "ModKind", "none")
        modScRaw := IniRead(pf, "Profile", "ModSc", "0")
        modSc := IsXDigit(modScRaw) ? Integer("0x" modScRaw) : 0
        modRawPageRaw := IniRead(pf, "Profile", "ModRawPage", "0")
        modRawPage := IsXDigit(modRawPageRaw) ? Integer("0x" modRawPageRaw) : 0
        modRawBytesHex := IniRead(pf, "Profile", "ModRawBytesHex", "")
        modRawUpBytesHex := IniRead(pf, "Profile", "ModRawUpBytesHex", "")
        modMode := IniRead(pf, "Profile", "ModMode", "toggle")
        modLpOn := IniRead(pf, "Profile", "ModLongPress", "0") = "1"
        modLpMsRaw := IniRead(pf, "Profile", "ModLongPressMs", "500")
        modLpMs := (IsInteger(modLpMsRaw) && Integer(modLpMsRaw) >= 1) ? Integer(modLpMsRaw) : 500
        mod2Kind := IniRead(pf, "Profile", "Mod2Kind", "none")
        mod2ScRaw := IniRead(pf, "Profile", "Mod2Sc", "0")
        mod2Sc := IsXDigit(mod2ScRaw) ? Integer("0x" mod2ScRaw) : 0
        mod2RawPageRaw := IniRead(pf, "Profile", "Mod2RawPage", "0")
        mod2RawPage := IsXDigit(mod2RawPageRaw) ? Integer("0x" mod2RawPageRaw) : 0
        mod2RawBytesHex := IniRead(pf, "Profile", "Mod2RawBytesHex", "")
        mod2RawUpBytesHex := IniRead(pf, "Profile", "Mod2RawUpBytesHex", "")
        mod2Mode := IniRead(pf, "Profile", "Mod2Mode", "")
        if mod2Mode != "hold" && mod2Mode != "toggle"
            mod2Mode := ""
        mod2LpOn := IniRead(pf, "Profile", "Mod2LongPress", "0") = "1"
        mod2LpMsRaw := IniRead(pf, "Profile", "Mod2LongPressMs", "500")
        mod2LpMs := (IsInteger(mod2LpMsRaw) && Integer(mod2LpMsRaw) >= 1) ? Integer(mod2LpMsRaw) : 500
        pt1Raw := IniRead(pf, "Profile", "PassthroughMod1", "")
        pt2Raw := IniRead(pf, "Profile", "PassthroughMod2", "")
        if pt1Raw = "" && pt2Raw = "" {
            legacyPtRaw := IniRead(pf, "Profile", "PassthroughFactoryMapped", "")
            profilePt1 := (legacyPtRaw = "1")
            profilePt2 := (legacyPtRaw = "1")
        } else {
            profilePt1 := (pt1Raw = "1")
            profilePt2 := (pt2Raw = "1")
        }
        profileEnabled := IniRead(pf, "Profile", "Enabled", "1") = "1"
        devTabRaw := IniRead(pf, "Profile", "DevTab", "")
        if HasVal(["Mouse", "Keyboard", "Remote"], devTabRaw) {
            devTab := devTabRaw
        } else {
            devTab := "Remote"
            if pname != "Default"
                migratedDevTabProfiles.Push(pname)
        }
        if pTab != ""
            devTab := pTab
        profiles[pkey] := {processNames: procList, modKind: modKind, modSc: modSc, modRawPage: modRawPage, modRawBytesHex: modRawBytesHex, modRawUpBytesHex: modRawUpBytesHex, modMode: modMode, mod2Kind: mod2Kind, mod2Sc: mod2Sc, mod2RawPage: mod2RawPage, mod2RawBytesHex: mod2RawBytesHex, mod2RawUpBytesHex: mod2RawUpBytesHex, modLpOn: modLpOn, modLpMs: modLpMs, mod2Mode: mod2Mode, mod2LpOn: mod2LpOn, mod2LpMs: mod2LpMs, passthroughMod1: profilePt1, passthroughMod2: profilePt2, devTab: devTab, enabled: profileEnabled
            , ledChoice: "Inherit", scrollFlashOn: false, scrollFlashMs: 500, capsFlashOn: false, capsFlashMs: 500, numFlashOn: false, numFlashMs: 500
            , ledChoice2: "Inherit", scrollFlashOn2: false, scrollFlashMs2: 500, capsFlashOn2: false, capsFlashMs2: 500, numFlashOn2: false, numFlashMs2: 500
            , notifyToggle: "Inherit"}
        if pkey != "Default"
            ApplyProfileLedFields(profiles[pkey], ProfileLedReadIni(pf, "Profile"))

        allSections := []
        allSectionSet := Map()
        for section in StrSplit(IniRead(pf), "`n", "`r") {
            if section = "" || section = "Profile"
                continue
            allSections.Push(section)
            allSectionSet[section] := true
        }
        sectionOrder := []
        seenSection := Map()
        for s in StrSplit(IniRead(pf, "Profile", "Order", ""), ",") {
            s := Trim(s)
            if s = "" || seenSection.Has(s) || !allSectionSet.Has(s)
                continue
            seenSection[s] := true
            sectionOrder.Push(s)
        }
        for section in allSections {
            if !seenSection.Has(section) {
                seenSection[section] := true
                sectionOrder.Push(section)
            }
        }

        profileContexts.Push({pkey: pkey, pf: pf, pname: pname, pTab: pTab, devTab: devTab, sectionOrder: sectionOrder})
        } catch as e {
            LogWarn("load", "LoadProfileRecords: " pname " (" pf "): " e.Message " (What=" e.What ", Line=" e.Line ")")
            failedProfiles.Push(pname)
            failedLoadProfiles[pkey] := true
            if profiles.Has(pkey)
                profiles.Delete(pkey)
            continue
        }
    }

    return profileContexts
}

LoadMappingSections(profileContexts, retaggedMappingProfiles, migratedRawMouseProfiles, migratedRawMouseCountBox) {
    global mappings, mapOrder, legacyLongPressMs

    for ctx in profileContexts {
        pkey := ctx.pkey
        pf := ctx.pf
        pname := ctx.pname
        pTab := ctx.pTab
        devTab := ctx.devTab
        sectionOrder := ctx.sectionOrder

        for section in sectionOrder {
            kind := IniRead(pf, section, "Kind", "sc")
            actionType := IniRead(pf, section, "ActionType", "key")
            desc := IniRead(pf, section, "Desc", section)
            target := IniRead(pf, section, "Target", "")
            if actionType = "ps" || actionType = "cmd"
                target := MacroStepsUnescapeField(target)
            appArgs := IniRead(pf, section, "AppArgs", "")
            enabled := IniRead(pf, section, "Enabled", "1") = "1"
            pressType := IniRead(pf, section, "PressType", "short")
            listVal := IniRead(pf, section, "List", "Main")
            devTabVal := IniRead(pf, section, "DevTab", DefaultDevTabForKind(kind))
            if pTab != "" && devTabVal != devTab {
                if !retaggedMappingProfiles.Has(pname)
                    retaggedMappingProfiles[pname] := {tab: devTab, count: 0}
                retaggedMappingProfiles[pname].count += 1
                devTabVal := devTab
            }
            runMode := IniRead(pf, section, "RunMode", "single")
            repeatMsRaw := IniRead(pf, section, "RepeatMs", "100")
            repeatMs := IsInteger(repeatMsRaw) ? Integer(repeatMsRaw) : 100
            delayEnabled := IniRead(pf, section, "DelayEnabled", "0") = "1"
            delayMsRaw := IniRead(pf, section, "DelayMs", "200")
            delayMs := IsInteger(delayMsRaw) ? Integer(delayMsRaw) : 200
            longPressMsRaw := IniRead(pf, section, "LongPressMs", String(legacyLongPressMs))
            longPressMs := IsInteger(longPressMsRaw) ? Integer(longPressMsRaw) : legacyLongPressMs
            macroSteps := actionType = "macro" ? MacroStepsDecode(IniRead(pf, section, "MacroSteps", "")) : []
            macroName := actionType = "macro" ? IniRead(pf, section, "MacroName", "") : ""
            if macroName = "" && actionType = "macro"
                macroName := FindSavedMacroNameForSteps(macroSteps)
            scriptName := actionType = "ps" || actionType = "cmd" ? IniRead(pf, section, "ScriptName", "") : ""
            hideWindow := (actionType = "ps" || actionType = "cmd") ? (IniRead(pf, section, "HideWindow", "0") = "1") : false
            if target = "" && actionType != "macro"
                continue
            id := UniqueMappingId(pname "::" section)
            if kind = "raw" {
                pageRaw := IniRead(pf, section, "Page", "0")
                page := IsInteger(pageRaw) ? Integer(pageRaw) : 0
                bytesHex := IniRead(pf, section, "BytesHex", "")
                upBytesHex := IniRead(pf, section, "UpBytesHex", "")
                if upBytesHex = "" {
                    pressType := "short"
                    runMode := "single"
                }
                stdMouseButton := StdMouseButtonFromRawReport(page, bytesHex)
                if stdMouseButton != "" {
                    mappings[id] := {profile: pname, kind: "mouse", actionType: actionType, button: stdMouseButton, desc: desc, target: target, appArgs: appArgs, macroSteps: macroSteps, macroName: macroName, scriptName: scriptName, hideWindow: hideWindow, enabled: enabled, pressType: pressType, runMode: runMode, repeatMs: repeatMs, delayEnabled: delayEnabled, delayMs: delayMs, longPressMs: longPressMs, list: listVal, devTab: devTabVal}
                    mapOrder.Push(id)
                    migratedRawMouseCountBox.count += 1
                    migratedRawMouseProfiles[pkey] := true
                } else {
                    mappings[id] := {profile: pname, kind: "raw", actionType: actionType, page: page, bytesHex: bytesHex, upBytesHex: upBytesHex, desc: desc, target: target, appArgs: appArgs, macroSteps: macroSteps, macroName: macroName, scriptName: scriptName, hideWindow: hideWindow, enabled: enabled, pressType: pressType, runMode: runMode, repeatMs: repeatMs, delayEnabled: delayEnabled, delayMs: delayMs, longPressMs: longPressMs, list: listVal, devTab: devTabVal}
                    mapOrder.Push(id)
                }
            } else if kind = "mouse" {
                buttonName := IniRead(pf, section, "Button", "")
                if buttonName = "" {
                    base := section
                    hashPos := InStr(base, "#")
                    if hashPos
                        base := SubStr(base, 1, hashPos - 1)
                    if IsMouseButtonKey(base)
                        buttonName := base
                }
                if buttonName = ""
                    continue
                mappings[id] := {profile: pname, kind: "mouse", actionType: actionType, button: buttonName, desc: desc, target: target, appArgs: appArgs, macroSteps: macroSteps, macroName: macroName, scriptName: scriptName, hideWindow: hideWindow, enabled: enabled, pressType: pressType, runMode: runMode, repeatMs: repeatMs, delayEnabled: delayEnabled, delayMs: delayMs, longPressMs: longPressMs, list: listVal, devTab: devTabVal}
                mapOrder.Push(id)
            } else {
                scHexStr := IniRead(pf, section, "ScHex", "")
                if scHexStr = "" {
                    base := section
                    hashPos := InStr(base, "#")
                    if hashPos
                        base := SubStr(base, 1, hashPos - 1)
                    scHexStr := SubStr(base, 3)
                }
                sc := IsXDigit(scHexStr) ? Integer("0x" scHexStr) : 0
                mappings[id] := {profile: pname, kind: "sc", actionType: actionType, sc: sc, desc: desc, target: target, appArgs: appArgs, macroSteps: macroSteps, macroName: macroName, scriptName: scriptName, hideWindow: hideWindow, enabled: enabled, pressType: pressType, runMode: runMode, repeatMs: repeatMs, delayEnabled: delayEnabled, delayMs: delayMs, longPressMs: longPressMs, list: listVal, devTab: devTabVal}
                mapOrder.Push(id)
                RegisterHotkeyForButton(Format("SC{:03X}", sc))
            }
        }
    }
}
