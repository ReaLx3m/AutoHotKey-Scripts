
ScriptEditorMap(kind) {
    global savedPsScripts, savedCmdScripts
    return kind = "ps" ? savedPsScripts : savedCmdScripts
}

ScriptEditorOrder(kind) {
    global savedPsScriptOrder, savedCmdScriptOrder
    return kind = "ps" ? savedPsScriptOrder : savedCmdScriptOrder
}

ScriptEditorHideMap(kind) {
    global savedPsScriptHide, savedCmdScriptHide
    return kind = "ps" ? savedPsScriptHide : savedCmdScriptHide
}

ScriptHideFlag(kind, name) {
    hideMap := ScriptEditorHideMap(kind)
    return hideMap.Has(name) && hideMap[name] ? true : false
}

ScriptKindLabel(kind) {
    return kind = "ps" ? "PS Script" : "CMD"
}

FindSavedScriptNameForBody(kind, body) {
    if body = ""
        return ""
    scripts := ScriptEditorMap(kind)
    for name in ScriptEditorOrder(kind) {
        if scripts.Has(name) && scripts[name] == body
            return name
    }
    return ""
}

FindSavedPsScriptNameForBody(body) {
    return FindSavedScriptNameForBody("ps", body)
}

FindSavedCmdScriptNameForBody(body) {
    return FindSavedScriptNameForBody("cmd", body)
}

FixEditLineEndings(ctrl, *) {
    static fixing := false
    if fixing
        return
    val := ctrl.Value
    if !RegExMatch(val, "(?<!\r)\n")
        return
    fixing := true
    ctrl.Value := val
    ControlSend("^{End}", ctrl)
    fixing := false
}

OpenScriptEditor(kind, initialBody, onSave) {
    global g, gScript, lbSavedScripts, edScriptBody, chkHideScript
    global scriptEditKind, scriptEditInitialBody, scriptEditOnSave, scriptEditSelectedName

    if IsObject(gScript) {
        if scriptEditKind = kind {
            gScript.Show()
        } else {
            MsgBox("Close the " ScriptKindLabel(scriptEditKind) " editor before opening the " ScriptKindLabel(kind) " editor.", "Editor already open", "Icon!")
        }
        return
    }

    scriptEditKind := kind
    scriptEditInitialBody := initialBody
    scriptEditOnSave := onSave
    scriptEditSelectedName := ""

    gScript := Gui("+Owner" g.Hwnd, "Edit " ScriptKindLabel(kind) "s")
    gScript.SetFont("s10", "Segoe UI")

    lblSavedScriptsHeader := gScript.Add("Text", "xm y10", "Saved " ScriptKindLabel(kind) "s")
    lblSavedScriptsHeader.GetPos(&sshX, &sshY, &sshW, &sshH)
    savedScriptBoxW := 165
    savedScriptGap := 10
    lbSavedScripts := gScript.Add("ListBox", "x" sshX " y+2 w" savedScriptBoxW " h600")
    lbSavedScripts.OnEvent("Change", (*) => OnSavedScriptSelectionChange())
    RefreshSavedScriptsList()

    lbSavedScripts.GetPos(&ssX, &ssY, &ssW, &ssH)

    savedScriptBtnGap := 3
    savedScriptBtnW := (ssW - 2 * savedScriptBtnGap) // 3
    btnSaveScript := gScript.Add("Button", "x" ssX " y" (ssY + ssH + 10) " w" savedScriptBtnW, "Save")
    btnSaveScript.OnEvent("Click", (*) => OpenSaveScriptNameDialog())
    btnUpdateSavedScript := gScript.Add("Button", "x+" savedScriptBtnGap " yp w" savedScriptBtnW, "Update")
    btnUpdateSavedScript.OnEvent("Click", (*) => UpdateSelectedSavedScript())
    btnDeleteSavedScript := gScript.Add("Button", "x+" savedScriptBtnGap " yp w" savedScriptBtnW, "Delete")
    btnDeleteSavedScript.OnEvent("Click", (*) => DeleteSelectedSavedScript())

    stepsX := ssX + ssW + savedScriptGap
    scriptBodyW := 560
    bodyPrompt := kind = "ps"
        ? "Write or paste a PowerShell script. It runs as-is via powershell.exe."
        : "Write or paste a CMD/batch script. It runs as-is via cmd.exe."
    lblBodyHeader := gScript.Add("Text", "x" stepsX " y" sshY " w" scriptBodyW, bodyPrompt)
    lblBodyHeader.GetPos(&lbhX, &lbhY, &lbhW, &lbhH)
    edScriptBody := gScript.Add("Edit", "x" stepsX " y+4 w" scriptBodyW " r36 +VScroll +WantTab +Multi", initialBody)
    edScriptBody.OnEvent("Change", FixEditLineEndings)

    chkHideScript := gScript.Add("Checkbox", "x" stepsX " y+8", "Hide window when run (saved with the script)")

    btnDoneScript := gScript.Add("Button", "x" stepsX " y+20 w100", "Done")
    btnDoneScript.OnEvent("Click", (*) => FinishScriptEditor())
    btnCancelScript := gScript.Add("Button", "x+10 w100", "Cancel")
    btnCancelScript.OnEvent("Click", (*) => CloseScriptEditor())

    gScript.OnEvent("Close", (*) => CloseScriptEditor())
    gScript.Show("w" (stepsX + scriptBodyW + 20))
}

FinishScriptEditor() {
    global scriptEditKind, scriptEditOnSave
    body := CurrentScriptBody()
    if Trim(body, " `t`r`n") = "" {
        result := MsgBox("This " ScriptKindLabel(scriptEditKind) " has no content yet. Use it anyway?", "Empty script", "YesNo Icon!")
        if result != "Yes"
            return
    }
    scriptEditOnSave(body)
    CloseScriptEditor()
}

CloseScriptEditor() {
    global gScript, lbSavedScripts, edScriptBody, chkHideScript
    global scriptEditKind, scriptEditSelectedName, scriptEditOnSave, scriptEditInitialBody
    closedKind := scriptEditKind
    if IsObject(gScript)
        gScript.Destroy()
    gScript := ""
    lbSavedScripts := ""
    edScriptBody := ""
    chkHideScript := ""
    scriptEditKind := ""
    scriptEditSelectedName := ""
    scriptEditOnSave := ""
    scriptEditInitialBody := ""
    if closedKind = "ps"
        UpdatePsScriptSelectDdl()
    else if closedKind = "cmd"
        UpdateCmdScriptSelectDdl()
}

RefreshSavedScriptsList(selectName := "") {
    global lbSavedScripts, scriptEditKind
    if !IsObject(lbSavedScripts)
        return
    order := ScriptEditorOrder(scriptEditKind)
    lbSavedScripts.Delete()
    if order.Length
        lbSavedScripts.Add(order)
    if selectName != "" {
        for i, name in order {
            if name = selectName {
                lbSavedScripts.Choose(i)
                break
            }
        }
    }
}

OnSavedScriptSelectionChange() {
    global lbSavedScripts, edScriptBody, chkHideScript, scriptEditKind, scriptEditSelectedName
    name := lbSavedScripts.Text
    if name = "" || !ScriptEditorMap(scriptEditKind).Has(name)
        return
    scriptEditSelectedName := name
    if IsObject(edScriptBody)
        edScriptBody.Value := ScriptEditorMap(scriptEditKind)[name]
    if IsObject(chkHideScript)
        chkHideScript.Value := ScriptHideFlag(scriptEditKind, name) ? 1 : 0
}

CurrentScriptBody() {
    global edScriptBody, scriptEditInitialBody
    if IsObject(edScriptBody)
        return edScriptBody.Value
    return scriptEditInitialBody
}

CurrentScriptHide() {
    global chkHideScript
    return IsObject(chkHideScript) && chkHideScript.Value = 1
}

PersistScriptList(kind) {
    if kind = "ps"
        SavePsScripts()
    else
        SaveCmdScripts()
}

ScriptNameIsValid(name) {
    return !InStr(name, ",") && !InStr(name, "[") && !InStr(name, "]")
}

OpenSaveScriptNameDialog() {
    global gScript, scriptEditKind
    if Trim(CurrentScriptBody(), " `t`r`n") = "" {
        MsgBox("Write a script before saving it.", "Nothing to save", "Icon!")
        return
    }
    gSaveScriptName := Gui("+Owner" gScript.Hwnd, "Save " ScriptKindLabel(scriptEditKind) " As")
    gSaveScriptName.SetFont("s10", "Segoe UI")
    gSaveScriptName.Add("Text", "xm y10", "Name:")
    edSaveScriptName := gSaveScriptName.Add("Edit", "x+10 yp-3 w200")
    btnOkSaveScript := gSaveScriptName.Add("Button", "xm y+15 w90 Default", "OK")
    btnCancelSaveScript := gSaveScriptName.Add("Button", "x+10 w90", "Cancel")
    btnOkSaveScript.OnEvent("Click", (*) => CommitSaveScriptAs(edSaveScriptName, gSaveScriptName))
    btnCancelSaveScript.OnEvent("Click", (*) => gSaveScriptName.Destroy())
    gSaveScriptName.OnEvent("Close", (*) => gSaveScriptName.Destroy())
    gSaveScriptName.Show("AutoSize")
    edSaveScriptName.Focus()
}

CommitSaveScriptAs(edSaveScriptName, gSaveScriptName) {
    global scriptEditKind
    name := Trim(edSaveScriptName.Value)
    if name = "" {
        MsgBox("Enter a name for the script.", "Name required", "Icon!")
        return
    }
    if !ScriptNameIsValid(name) {
        MsgBox("A name can't contain a comma or square brackets.", "Invalid name", "Icon!")
        return
    }
    scripts := ScriptEditorMap(scriptEditKind)
    if scripts.Has(name) {
        if MsgBox("A saved " ScriptKindLabel(scriptEditKind) " named '" name "' already exists. Overwrite it?", "Overwrite?", "YesNo Icon!") != "Yes"
            return
    } else
        ScriptEditorOrder(scriptEditKind).Push(name)
    scripts[name] := CurrentScriptBody()
    ScriptEditorHideMap(scriptEditKind)[name] := CurrentScriptHide()
    RefreshSavedScriptsList(name)
    PersistScriptList(scriptEditKind)
    gSaveScriptName.Destroy()
}

UpdateSelectedSavedScript() {
    global lbSavedScripts, scriptEditKind, mappings, mapOrder, editingId
    name := lbSavedScripts.Text
    if name = "" {
        MsgBox("Select a saved " ScriptKindLabel(scriptEditKind) " to update first.", "Nothing selected", "Icon!")
        return
    }
    if Trim(CurrentScriptBody(), " `t`r`n") = "" {
        MsgBox("Write a script before updating a saved one.", "Nothing to save", "Icon!")
        return
    }
    body := CurrentScriptBody()
    hide := CurrentScriptHide()
    ScriptEditorMap(scriptEditKind)[name] := body
    ScriptEditorHideMap(scriptEditKind)[name] := hide
    RefreshSavedScriptsList(name)
    PersistScriptList(scriptEditKind)
    linkedKeys := []
    for key in mapOrder {
        if !mappings.Has(key)
            continue
        m := mappings[key]
        if MapActionType(m) = scriptEditKind && MapScriptName(m) = name && (m.target !== body || MapHideWindow(m) != hide) {
            m.target := body
            m.hideWindow := hide
            linkedKeys.Push(key)
        }
    }
    for key in linkedKeys
        SaveProfileMapping(MapProfileKey(mappings[key]), key)
    if linkedKeys.Length > 0
        RefreshList()
    if editingId != "" && mappings.Has(editingId) && HasVal(linkedKeys, editingId)
        ApplyActionFieldsFromMapping(mappings[editingId])
}

DeleteSelectedSavedScript() {
    global lbSavedScripts, scriptEditKind, scriptEditSelectedName
    global mappings, mapOrder, editingId
    global currentPsScriptName, currentCmdScriptName
    name := lbSavedScripts.Text
    if name = "" {
        MsgBox("Select a saved " ScriptKindLabel(scriptEditKind) " to delete first.", "Nothing selected", "Icon!")
        return
    }
    linkedKeys := []
    for key in mapOrder {
        m := mappings[key]
        if MapActionType(m) = scriptEditKind && MapScriptName(m) = name
            linkedKeys.Push(key)
    }
    prompt := "Delete the saved " ScriptKindLabel(scriptEditKind) " '" name "'? This cannot be undone."
    if linkedKeys.Length > 0
        prompt := "The saved " ScriptKindLabel(scriptEditKind) " '" name "' is currently used by " linkedKeys.Length " button mapping" (linkedKeys.Length = 1 ? "" : "s") ".`n`nDeleting it will unlink those mappings, so they keep working exactly as they do now - they just won't follow any future edits to this " ScriptKindLabel(scriptEditKind) " anymore.`n`nDelete anyway?"
    if MsgBox(prompt, "Delete saved " ScriptKindLabel(scriptEditKind), "YesNo Icon!") != "Yes"
        return
    for key in linkedKeys
        mappings[key].scriptName := ""
    scripts := ScriptEditorMap(scriptEditKind)
    order := ScriptEditorOrder(scriptEditKind)
    scripts.Delete(name)
    hideMap := ScriptEditorHideMap(scriptEditKind)
    if hideMap.Has(name)
        hideMap.Delete(name)
    deletedIdx := 0
    for i, n in order {
        if n = name {
            deletedIdx := i
            order.RemoveAt(i)
            break
        }
    }
    replacementName := ""
    if order.Length > 0
        replacementName := order[Min(deletedIdx > 0 ? deletedIdx : 1, order.Length)]
    scriptEditSelectedName := replacementName
    RefreshSavedScriptsList(replacementName)
    if editingId != "" && mappings.Has(editingId) && HasVal(linkedKeys, editingId) {
        if scriptEditKind = "ps"
            currentPsScriptName := ""
        else
            currentCmdScriptName := ""
    }
    PersistScriptList(scriptEditKind)
    for key in linkedKeys {
        if mappings.Has(key)
            SaveProfileMapping(MapProfileKey(mappings[key]), key)
    }
}

SavePsScriptFromMainEditor(body) {
    global currentPsScriptBody
    currentPsScriptBody := body
    UpdatePsScriptSelectDdl()
}

SaveCmdScriptFromMainEditor(body) {
    global currentCmdScriptBody
    currentCmdScriptBody := body
    UpdateCmdScriptSelectDdl()
}

OnEditPsScriptClick(*) {
    global currentPsScriptBody
    OpenScriptEditor("ps", currentPsScriptBody, SavePsScriptFromMainEditor)
}

OnEditCmdScriptClick(*) {
    global currentCmdScriptBody
    OpenScriptEditor("cmd", currentCmdScriptBody, SaveCmdScriptFromMainEditor)
}

OnPsScriptSelectChange(*) {
    OnScriptSelectChange("ps")
}

OnCmdScriptSelectChange(*) {
    OnScriptSelectChange("cmd")
}

UpdatePsScriptSelectDdl() {
    UpdateScriptSelectDdl("ps")
}

UpdateCmdScriptSelectDdl() {
    UpdateScriptSelectDdl("cmd")
}

OnScriptSelectChange(kind) {
    global ddlPsScriptSelect, ddlCmdScriptSelect
    global currentPsScriptBody, currentPsScriptName, currentCmdScriptBody, currentCmdScriptName
    global currentPsScriptHide, currentCmdScriptHide
    ddl := kind = "ps" ? ddlPsScriptSelect : ddlCmdScriptSelect
    idx := ddl.Value
    if idx <= 1 {
        if kind = "ps"
            currentPsScriptName := ""
        else
            currentCmdScriptName := ""
        return
    }
    order := ScriptEditorOrder(kind)
    if idx - 1 > order.Length
        return
    name := order[idx - 1]
    scripts := ScriptEditorMap(kind)
    if !scripts.Has(name)
        return
    if kind = "ps" {
        currentPsScriptBody := scripts[name]
        currentPsScriptName := name
        currentPsScriptHide := ScriptHideFlag("ps", name)
    } else {
        currentCmdScriptBody := scripts[name]
        currentCmdScriptName := name
        currentCmdScriptHide := ScriptHideFlag("cmd", name)
    }
}

UpdateScriptSelectDdl(kind) {
    global ddlPsScriptSelect, ddlCmdScriptSelect
    global currentPsScriptBody, currentPsScriptName, currentCmdScriptBody, currentCmdScriptName
    ddl := kind = "ps" ? ddlPsScriptSelect : ddlCmdScriptSelect
    if !IsObject(ddl)
        return
    body := kind = "ps" ? currentPsScriptBody : currentCmdScriptBody
    curName := kind = "ps" ? currentPsScriptName : currentCmdScriptName
    scripts := ScriptEditorMap(kind)
    order := ScriptEditorOrder(kind)
    items := ["(Custom / unsaved)"]
    for name in order
        items.Push(name)
    ddl.Delete()
    ddl.Add(items)
    linkName := ""
    if curName != "" && body != "" && scripts.Has(curName) && scripts[curName] == body
        linkName := curName
    else
        linkName := FindSavedScriptNameForBody(kind, body)
    matchIdx := 1
    if linkName != "" {
        for i, name in order {
            if name = linkName {
                matchIdx := i + 1
                break
            }
        }
    }
    if matchIdx = 1
        linkName := ""
    if kind = "ps"
        currentPsScriptName := linkName
    else
        currentCmdScriptName := linkName
    ddl.Choose(matchIdx)
}
