
LogUnhandledError(exc, mode) {
    LogWarn("unhandled", Format("{}: {} | What: {} | File: {} | Line: {}",
        Type(exc), exc.Message,
        exc.HasOwnProp("What") ? exc.What : "",
        exc.HasOwnProp("File") ? exc.File : "",
        exc.HasOwnProp("Line") ? exc.Line : ""))
    return false
}

AcquireHighResTimer() {
    global g_hiResTimerRefCount
    g_hiResTimerRefCount += 1
    if g_hiResTimerRefCount = 1
        DllCall("winmm\timeBeginPeriod", "UInt", 1)
}

ReleaseHighResTimer() {
    global g_hiResTimerRefCount
    if g_hiResTimerRefCount <= 0
        return
    g_hiResTimerRefCount -= 1
    if g_hiResTimerRefCount = 0
        DllCall("winmm\timeEndPeriod", "UInt", 1)
}

MainOnExitBackstop(exitReason, exitCode) {
    global g_hiResTimerRefCount
    SaveKeymapColumnWidths()
    ReleaseAllHolds()
    if g_hiResTimerRefCount > 0
        DllCall("winmm\timeEndPeriod", "UInt", 1)
    return 0
}

DataDir() => A_ScriptDir "\data"
SettingsFile() => DataDir() "\settings.ini"
MacrosFile() => DataDir() "\macros.ini"
PsScriptsFile() => DataDir() "\ps_scripts.ini"
CmdScriptsFile() => DataDir() "\cmd_scripts.ini"
ProfilesDir() => DataDir() "\Profiles"

ProfileTabDir(devTab) => ProfilesDir() "\" devTab

EnsureDataDirs() {
    global DEVICE_TAGS
    try DirCreate(DataDir())
    try DirCreate(ProfilesDir())
    for tag in DEVICE_TAGS
        try DirCreate(ProfilesDir() "\" tag)
}

LogWarn(area, message) {
    try {
        logPath := DataDir() "\mapper.log"
        clean := StrReplace(StrReplace(StrReplace(message, "`r", " "), "`n", " "), "`t", " ")
        line := FormatTime(, "yyyy-MM-dd HH:mm:ss") "`t" area "`t" clean "`n"
        if FileExist(logPath) && FileGetSize(logPath) > 1048576 {
            try FileDelete(logPath ".1")
            try FileMove(logPath, logPath ".1")
        }
        FileAppend(line, logPath, "UTF-8-RAW")
    }
}

SanitizeProfileFileName(name) {
    out := ""
    loop parse name {
        ch := A_LoopField
        code := Ord(ch)
        if code < 32 || InStr('\/:*?"<>|', ch)
            out .= "_"
        else
            out .= ch
    }
    while (out != "" && (SubStr(out, -1) = "." || SubStr(out, -1) = " "))
        out := SubStr(out, 1, StrLen(out) - 1)
    if out = ""
        out := "_"
    reserved := "CON PRN AUX NUL COM1 COM2 COM3 COM4 COM5 COM6 COM7 COM8 COM9 LPT1 LPT2 LPT3 LPT4 LPT5 LPT6 LPT7 LPT8 LPT9"
    for r in StrSplit(reserved, " ") {
        if (out = r) {
            out := "_" out
            break
        }
    }
    return out
}

PersistenceAllowed(notify := true) {
    global loadCompleted, saveBlockedNotified
    if loadCompleted
        return true
    if notify && !saveBlockedNotified {
        saveBlockedNotified := true
        LogWarn("save", "saving disabled for this session (partial load, loadCompleted=false)")
        MsgBox("Your configuration could not be fully loaded earlier in this session, "
            . "so only part of it is in memory.`n`n"
            . "Saving has been disabled for this session so your existing files on disk "
            . "are not overwritten with that partial state. Any changes you make now will "
            . "be lost when you close the app.`n`n"
            . "Close the app, fix or remove the file named in the earlier load error, then "
            . "start it again."
            , "MF Button Mapper - saving disabled", "Icon!")
    }
    return false
}

AtomicSidecarPaths(path) {
    base := RegExReplace(path, "i)\.ini$", "")
    if base = path
        base := path "_"
    return {tmp: base ".tmp", bak: base ".bak"}
}

WriteFileAtomic(path, content, &errMsg) {
    errMsg := ""
    sc := AtomicSidecarPaths(path)
    try FileDelete(sc.tmp)
    try {
        f := FileOpen(sc.tmp, "w", "UTF-8-RAW")
        if !IsObject(f) {
            errMsg := "Could not create the temporary file '" sc.tmp "'."
            return false
        }
        f.Write(content)
        f.Close()
    } catch as e {
        errMsg := e.Message
        try FileDelete(sc.tmp)
        return false
    }
    expected := StrPut(content, "UTF-8") - 1
    try {
        actual := FileGetSize(sc.tmp)
        if actual != expected {
            errMsg := "Only " actual " of " expected " bytes could be written to '" sc.tmp "'."
            try FileDelete(sc.tmp)
            return false
        }
    } catch as e {
        errMsg := e.Message
        try FileDelete(sc.tmp)
        return false
    }
    movedAside := false
    if FileExist(path) {
        try FileDelete(sc.bak)
        try {
            FileMove(path, sc.bak, true)
            movedAside := true
        } catch as e {
            errMsg := "The existing file could not be moved aside: " e.Message
            try FileDelete(sc.tmp)
            return false
        }
    }
    try {
        FileMove(sc.tmp, path, true)
    } catch as e {
        errMsg := e.Message
        if movedAside && !FileExist(path) {
            restored := false
            try {
                FileMove(sc.bak, path, true)
                restored := true
            }
            if !restored {
                errMsg .= " The original file could not be restored either; it survives only as '" sc.bak "'."
                LogWarn("save", path ": rename failed and rollback failed - original only at '" sc.bak "'. " e.Message)
            }
        }
        try FileDelete(sc.tmp)
        return false
    }
    return true
}

NotifySaveFailure(path, errMsg) {
    global saveFailureNotified
    if saveFailureNotified
        return
    saveFailureNotified := true
    MsgBox("Could not save to:`n" path "`n`n" errMsg "`n`n"
        . "Your previous file has been left as it was, so nothing has been lost - but "
        . "changes made in this session are not on disk. Common causes: the file is open "
        . "in another program, is read-only, or is being held by a sync client "
        . "(OneDrive/Dropbox) or antivirus.`n`n"
        . "This message is shown only once per session."
        , "MF Button Mapper - save failed", "Icon!")
}

MapKind(m)       => m.HasOwnProp("kind") ? m.kind : "sc"
MapProfile(m)    => m.HasOwnProp("profile") ? m.profile : "Default"
MapList(m)       => m.HasOwnProp("list") ? m.list : "Main"
MapActionType(m) => m.HasOwnProp("actionType") ? m.actionType : "key"
MapDevTab(m)     => m.HasOwnProp("devTab") ? m.devTab : DefaultDevTabForKind(MapKind(m))

MapRunMode(m)      => m.HasOwnProp("runMode") ? m.runMode : "single"
MapPressType(m)    => m.HasOwnProp("pressType") ? m.pressType : "short"
MapRepeatMs(m)     => m.HasOwnProp("repeatMs") ? m.repeatMs : 100
MapDelayEnabled(m) => m.HasOwnProp("delayEnabled") ? m.delayEnabled : false
MapDelayMs(m)      => m.HasOwnProp("delayMs") ? m.delayMs : 200
MapMacroName(m)    => m.HasOwnProp("macroName") ? m.macroName : ""
MapScriptName(m)   => m.HasOwnProp("scriptName") ? m.scriptName : ""
MapHideWindow(m)   => m.HasOwnProp("hideWindow") ? !!m.hideWindow : false
MapAppArgs(m)      => m.HasOwnProp("appArgs") ? m.appArgs : ""
MapUpBytesHex(m)   => m.HasOwnProp("upBytesHex") ? m.upBytesHex : ""
MapButton(m)       => m.button
MapLongPressMs(m) {
    global legacyLongPressMs
    return m.HasOwnProp("longPressMs") ? m.longPressMs : legacyLongPressMs
}

DdlIndexOf(items, needle) {
    for i, v in items
        if v = needle
            return i
    throw ValueError("DdlIndexOf: `"" needle "`" not found in dropdown item list")
}

SelectedActionType() {
    global ddlActionType, ACTION_APP, ACTION_MULTIMEDIA, ACTION_MOUSE, ACTION_MACRO, ACTION_PS, ACTION_CMD
    v := ddlActionType.Value
    return v = ACTION_APP ? "app" : (v = ACTION_MULTIMEDIA ? "multimedia" : (v = ACTION_MOUSE ? "mouse" : (v = ACTION_MACRO ? "macro" : (v = ACTION_PS ? "ps" : (v = ACTION_CMD ? "cmd" : "key")))))
}

DefaultDevTabForKind(kind) => kind = "sc" ? "Keyboard" : (kind = "mouse" ? "Mouse" : "Remote")
IsMouseButtonKey(k) => InStr("|LButton|RButton|MButton|XButton1|XButton2|WheelUp|WheelDown|WheelLeft|WheelRight|", "|" k "|") > 0
IsMouseWheelKey(k) => SubStr(k, 1, 5) = "Wheel"
MouseButtonRemapBlockedInProfile(buttonKey, profile, list) => profile = "Default" && list = "Main" && (buttonKey = "LButton" || buttonKey = "RButton")
MouseButtonDisplayName(k) {
    switch k {
        case "LButton": return "Mouse Left"
        case "RButton": return "Mouse Right"
        case "MButton": return "Mouse Middle"
        case "XButton1": return "Mouse X1 (Back)"
        case "XButton2": return "Mouse X2 (Forward)"
        case "WheelUp": return "Mouse Wheel Up"
        case "WheelDown": return "Mouse Wheel Down"
        case "WheelLeft": return "Mouse Wheel Left"
        case "WheelRight": return "Mouse Wheel Right"
    }
    return k
}

StdMouseButtonFromRawReport(page, bytesHex) {
    if page != 1
        return ""
    switch bytesHex {
        case "0001": return "LButton"
        case "0004": return "RButton"
        case "0010": return "MButton"
        case "0040": return "XButton1"
        case "0100": return "XButton2"
        case "0401": return "WheelUp"
        case "0402": return "WheelDown"
        case "0801": return "WheelRight"
        case "0802": return "WheelLeft"
    }
    return ""
}

StdMouseRawReportFromButton(k) {
    switch k {
        case "LButton": return {page: 1, bytesHex: "0001", upBytesHex: "0002"}
        case "RButton": return {page: 1, bytesHex: "0004", upBytesHex: "0008"}
        case "MButton": return {page: 1, bytesHex: "0010", upBytesHex: "0020"}
        case "XButton1": return {page: 1, bytesHex: "0040", upBytesHex: "0080"}
        case "XButton2": return {page: 1, bytesHex: "0100", upBytesHex: "0200"}
        case "WheelUp": return {page: 1, bytesHex: "0401", upBytesHex: ""}
        case "WheelDown": return {page: 1, bytesHex: "0402", upBytesHex: ""}
        case "WheelRight": return {page: 1, bytesHex: "0801", upBytesHex: ""}
        case "WheelLeft": return {page: 1, bytesHex: "0802", upBytesHex: ""}
    }
    return ""
}

MakeRawButtonKey(page, bytesHex) => "RAW_" Format("{:X}", page) "_" bytesHex
KeyNameFor(VK, SC) => GetKeyName(Format("vk{:X}sc{:X}", VK, SC))

KeyNameDisplay(VK, SC) {
    name := KeyNameFor(VK, SC)
    return StrLen(name) = 1 ? StrUpper(name) : name
}

WheelBytesForDelta(axis, delta) {
    if delta = 0
        return ""
    if axis = "H"
        return delta > 0 ? "0801" : "0802"
    return delta > 0 ? "0401" : "0402"
}

ProfileKey(devTab, name) => name = "Default" ? "Default" : (devTab "|" name)

ProfileKeyName(pkey) {
    pos := InStr(pkey, "|")
    return pos ? SubStr(pkey, pos + 1) : pkey
}

ProfileKeyTab(pkey) {
    pos := InStr(pkey, "|")
    return pos ? SubStr(pkey, 1, pos - 1) : ""
}

ProfileIsEnabled(pkey) {
    global profiles
    if pkey = "Default"
        return true
    if !profiles.Has(pkey)
        return true
    pdata := profiles[pkey]
    return pdata.HasOwnProp("enabled") ? pdata.enabled : true
}

ProfileHasOwnModifierButtons(pkey) {
    global profiles
    if !profiles.Has(pkey)
        return false
    pdata := profiles[pkey]
    modKind := ProfModKind(pdata)
    mod2Kind := ProfMod2Kind(pdata)
    return modKind != "none" || mod2Kind != "none"
}

MapProfileKey(m) => ProfileKey(MapDevTab(m), MapProfile(m))
