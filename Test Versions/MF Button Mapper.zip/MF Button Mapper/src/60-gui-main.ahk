
RegisterHoldDdl(ctrl, items, greyIdx0Based, checkFn) {
    ctrl.HoldItems := items
    ctrl.HoldRules := [{greyIdx: greyIdx0Based, checkFn: checkFn}]
}

AddHoldDdlRule(ctrl, greyIdx0Based, checkFn) {
    ctrl.HoldRules.Push({greyIdx: greyIdx0Based, checkFn: checkFn})
}

IsDdlItemGreyed(ctrl, itemId) {
    for rule in ctrl.HoldRules
        if rule.checkFn.Call() && HasVal(rule.greyIdx, itemId)
            return true
    return false
}

RefreshHoldDdl(ctrl) {
    DllCall("InvalidateRect", "ptr", ctrl.Hwnd, "ptr", 0, "int", true)
}

EnforceHoldDdlSelection(ctrl, fallbackIdx1Based, afterFn := "") {
    if IsDdlItemGreyed(ctrl, ctrl.Value - 1) {
        ctrl.Choose(fallbackIdx1Based)
        if IsObject(afterFn)
            afterFn.Call()
    }
    RefreshHoldDdl(ctrl)
}

HasVal(arr, val) {
    for v in arr
        if v = val
            return true
    return false
}

ComboItemHeightForCtrl(hwndCtrl) {
    hDC := DllCall("GetDC", "ptr", hwndCtrl, "ptr")
    hFont := SendMessage(0x0031, 0, 0, , "ahk_id " hwndCtrl)
    hOldFont := hFont ? DllCall("SelectObject", "ptr", hDC, "ptr", hFont, "ptr") : 0
    tm := Buffer(64, 0)
    DllCall("GetTextMetricsW", "ptr", hDC, "ptr", tm)
    tmHeight := NumGet(tm, 0, "Int")
    if hOldFont
        DllCall("SelectObject", "ptr", hDC, "ptr", hOldFont)
    DllCall("ReleaseDC", "ptr", hwndCtrl, "ptr", hDC)
    return tmHeight + 6
}

OnDdlMeasureItem(wParam, lParam, msg, hwnd) {
    ctrlHwnd := DllCall("GetDlgItem", "ptr", hwnd, "int", wParam, "ptr")
    ctrl := ctrlHwnd ? GuiCtrlFromHwnd(ctrlHwnd) : ""
    if !ctrl || !ctrl.HasOwnProp("HoldItems")
        return
    NumPut("UInt", ComboItemHeightForCtrl(ctrlHwnd), lParam, 16)
    return 1
}

OnDdlDrawItem(wParam, lParam, msg, hwnd) {
    global DrawItemHwndOff, DrawItemHdcOff, DrawItemRectOff
    ctrl := GuiCtrlFromHwnd(NumGet(lParam, DrawItemHwndOff, "Ptr"))
    if !ctrl || !ctrl.HasOwnProp("HoldItems")
        return
    itemId := NumGet(lParam, 8, "UInt")
    itemState := NumGet(lParam, 16, "UInt")
    hDC := NumGet(lParam, DrawItemHdcOff, "Ptr")
    left := NumGet(lParam, DrawItemRectOff, "Int")
    top := NumGet(lParam, DrawItemRectOff + 4, "Int")
    right := NumGet(lParam, DrawItemRectOff + 8, "Int")
    bottom := NumGet(lParam, DrawItemRectOff + 12, "Int")

    items := ctrl.HoldItems
    text := (itemId != 0xFFFFFFFF && itemId + 1 <= items.Length) ? items[itemId + 1] : ""
    isSelected := (itemState & 0x0001) != 0
    isGreyed := IsDdlItemGreyed(ctrl, itemId)

    bgColor := (isSelected && !isGreyed)
        ? DllCall("GetSysColor", "int", 13, "uint")
        : DllCall("GetSysColor", "int", 5, "uint")
    textColor := isGreyed
        ? DllCall("GetSysColor", "int", 17, "uint")
        : (isSelected ? DllCall("GetSysColor", "int", 14, "uint") : DllCall("GetSysColor", "int", 8, "uint"))

    hBrush := DllCall("CreateSolidBrush", "uint", bgColor, "ptr")
    rc := Buffer(16, 0)
    NumPut("Int", left, "Int", top, "Int", right, "Int", bottom, rc, 0)
    DllCall("FillRect", "ptr", hDC, "ptr", rc, "ptr", hBrush)
    DllCall("DeleteObject", "ptr", hBrush)

    DllCall("SetBkMode", "ptr", hDC, "int", 1)
    DllCall("SetTextColor", "ptr", hDC, "uint", textColor)
    NumPut("Int", left + 3, rc, 0)
    DllCall("DrawTextW", "ptr", hDC, "str", text, "int", -1, "ptr", rc, "uint", 0x0024)

    if (itemState & 0x0010) && !isGreyed
        DllCall("DrawFocusRect", "ptr", hDC, "ptr", rc)
    return 1
}

UpdateLongPressFieldVisibility() {
    global ddlPressType, lblLongPress, edLongPressMs, lblLongPressUnit
    show := ddlPressType.Visible && ddlPressType.Value = DdlIndexFromPressType("long")
    lblLongPress.Visible := show
    edLongPressMs.Visible := show
    lblLongPressUnit.Visible := show
    ResizeLearnButtonBox()
}

IsMainCaptureSingleShot() {
    global lastCaptureKind, capturedRawUpBytesHex, capturedMouseButton
    if lastCaptureKind = "mouse"
        return IsMouseWheelKey(capturedMouseButton)
    return lastCaptureKind = "raw" && capturedRawUpBytesHex = ""
}

IsHoldUnsupportedAction() {
    global ddlActionType, ACTION_MULTIMEDIA, ACTION_MACRO
    return ddlActionType.Value = ACTION_MULTIMEDIA || ddlActionType.Value = ACTION_MACRO
}

IsTypematicUnsupportedAction() {
    global ddlActionType, ACTION_MOUSE, ACTION_MACRO
    return ddlActionType.Value = ACTION_MOUSE || ddlActionType.Value = ACTION_MACRO
}

ReconcileMainHoldDdls() {
    global ddlPressType, ddlRunMode
    if IsMainCaptureSingleShot() {
        if HasVal(HoldOnlyRunModeIdx, ddlRunMode.Value - 1) {
            ddlRunMode.Choose(2)
            OnRunModeChange()
        }
        if HasVal(HoldOnlyTriggerIdx, ddlPressType.Value - 1)
            ddlPressType.Choose(DdlIndexFromPressType("short"))
    }
    RefreshHoldDdl(ddlPressType)
    RefreshHoldDdl(ddlRunMode)
    UpdateLongPressFieldVisibility()
}

DevTabFitToLastTab(ctrl, probe := true) {
    spec := "ahk_id " ctrl.Hwnd
    rc0 := Buffer(16, 0), rcLast := Buffer(16, 0)
    n := SendMessage(0x1304, 0, 0, , spec)
    if n < 1
        return 0
    if !SendMessage(0x130A, 0, rc0, , spec) || !SendMessage(0x130A, n - 1, rcLast, , spec)
        return 0
    firstLeft := NumGet(rc0, 0, "Int")
    firstTop := NumGet(rc0, 4, "Int")
    ctrl.GetPos(, , &ctrlW, &ctrlH)
    if NumGet(rcLast, 4, "Int") != firstTop
        return 0

    if probe {
        origW := ctrlW
        lo := NumGet(rcLast, 8, "Int"), hi := origW
        while lo < hi {
            mid := (lo + hi) // 2
            ctrl.Move(, , mid)
            SendMessage(0x130A, n - 1, rcLast, , spec)
            if NumGet(rcLast, 4, "Int") = firstTop
                hi := mid
            else
                lo := mid + 1
        }
        ctrl.Move(, , hi)
        SendMessage(0x130A, n - 1, rcLast, , spec)
        if NumGet(rcLast, 4, "Int") != firstTop {
            ctrl.Move(, , origW)
            SendMessage(0x130A, n - 1, rcLast, , spec)
        }
        ctrl.GetPos(, , &ctrlW)
    }

    visibleW := NumGet(rcLast, 8, "Int") + firstLeft
    if visibleW < 1
        return 0
    if visibleW >= ctrlW
        return visibleW
    hRgn := DllCall("gdi32\CreateRectRgn", "Int", 0, "Int", 0, "Int", visibleW, "Int", ctrlH, "Ptr")
    if !hRgn
        return visibleW
    if !DllCall("user32\SetWindowRgn", "Ptr", ctrl.Hwnd, "Ptr", hRgn, "Int", true, "Int") {
        DllCall("gdi32\DeleteObject", "Ptr", hRgn)
        return visibleW
    }
    ctrl.GetPos(&ctrlX, &ctrlY)
    rcCut := Buffer(16, 0)
    NumPut("Int", ctrlX + visibleW, "Int", ctrlY, "Int", ctrlX + ctrlW, "Int", ctrlY + ctrlH, rcCut, 0)
    DllCall("user32\RedrawWindow", "Ptr", ctrl.Gui.Hwnd, "Ptr", rcCut, "Ptr", 0, "UInt", 0x1 | 0x4)
    return visibleW
}

OnDevTabDrawItem(wParam, lParam, msg, hwnd) {
    global tabDevFilter, tabDevCaptions, tabDevBoldFont
    global DrawItemHwndOff, DrawItemHdcOff, DrawItemRectOff
    if !IsSet(tabDevFilter)
        return
    hwndTab := NumGet(lParam, DrawItemHwndOff, "Ptr")
    if hwndTab != tabDevFilter.Hwnd
        return
    if NumGet(lParam, 0, "UInt") != 101
        return
    itemId := NumGet(lParam, 8, "UInt")
    itemState := NumGet(lParam, 16, "UInt")
    hDC := NumGet(lParam, DrawItemHdcOff, "Ptr")
    left := NumGet(lParam, DrawItemRectOff, "Int")
    top := NumGet(lParam, DrawItemRectOff + 4, "Int")
    right := NumGet(lParam, DrawItemRectOff + 8, "Int")
    bottom := NumGet(lParam, DrawItemRectOff + 12, "Int")

    isSelected := ((itemState & 0x1) != 0) || (itemId + 1 = tabDevFilter.Value)
    text := (itemId + 1 <= tabDevCaptions.Length) ? tabDevCaptions[itemId + 1] : ""

    if isSelected {
        left -= 2
        top -= 2
        right += 2
        bottom += 1
    }
    rc := Buffer(16, 0)
    NumPut("Int", left, "Int", top, "Int", right, "Int", bottom, rc, 0)

    hTheme := DllCall("uxtheme\OpenThemeData", "Ptr", hwndTab, "WStr", "TAB", "Ptr")
    if hTheme {
        DllCall("uxtheme\DrawThemeBackground", "Ptr", hTheme, "Ptr", hDC
            , "Int", 1, "Int", isSelected ? 3 : 1, "Ptr", rc, "Ptr", 0)
        DllCall("uxtheme\CloseThemeData", "Ptr", hTheme)
    } else {
        DllCall("user32\FillRect", "Ptr", hDC, "Ptr", rc
            , "Ptr", DllCall("user32\GetSysColorBrush", "Int", 15, "Ptr"))
    }

    hFont := DllCall("user32\SendMessageW", "Ptr", hwndTab, "UInt", 0x31, "Ptr", 0, "Ptr", 0, "Ptr")
    useFont := hFont
    if isSelected {
        if !tabDevBoldFont && hFont {
            lf := Buffer(92, 0)
            if DllCall("gdi32\GetObjectW", "Ptr", hFont, "Int", 92, "Ptr", lf) {
                NumPut("Int", 700, lf, 16)
                tabDevBoldFont := DllCall("gdi32\CreateFontIndirectW", "Ptr", lf, "Ptr")
            }
        }
        if tabDevBoldFont
            useFont := tabDevBoldFont
    }
    hOldFont := useFont ? DllCall("gdi32\SelectObject", "Ptr", hDC, "Ptr", useFont, "Ptr") : 0
    oldBk := DllCall("gdi32\SetBkMode", "Ptr", hDC, "Int", 1, "Int")
    oldClr := DllCall("gdi32\SetTextColor", "Ptr", hDC
        , "UInt", DllCall("user32\GetSysColor", "Int", 18, "UInt"), "UInt")

    DllCall("user32\DrawTextW", "Ptr", hDC, "Str", text, "Int", -1, "Ptr", rc
        , "UInt", 0x1 | 0x4 | 0x20 | 0x800)

    if ((itemState & 0x10) != 0) && ((itemState & 0x200) = 0) {
        NumPut("Int", left + 4, "Int", top + 3, "Int", right - 4, "Int", bottom - 3, rc, 0)
        DllCall("user32\DrawFocusRect", "Ptr", hDC, "Ptr", rc)
    }

    DllCall("gdi32\SetTextColor", "Ptr", hDC, "UInt", oldClr)
    DllCall("gdi32\SetBkMode", "Ptr", hDC, "Int", oldBk)
    if hOldFont
        DllCall("gdi32\SelectObject", "Ptr", hDC, "Ptr", hOldFont)
    return 1
}

PositionMacroScriptButtons(rightEdgeX) {
    global btnMacros, btnPsScripts, btnCmdScripts
    gap := 4
    btnMacros.GetPos(, , &mW)
    btnPsScripts.GetPos(, , &pW)
    btnCmdScripts.GetPos(, , &cW)
    cmdX := rightEdgeX - cW
    psX := cmdX - gap - pW
    macXNew := psX - gap - mW
    btnCmdScripts.Move(cmdX)
    btnPsScripts.Move(psX)
    btnMacros.Move(macXNew)
}

ResizeLearnButtonBox() {
    global grpLearnButton, btnClearForm
    btnClearForm.GetPos(&bcx, &bcy, &bcw, &bch)
    grpLearnButton.GetPos(&gbx, &gby, &gbw, &gbh)
    newBottom := bcy + bch + 15
    maxRight := 0
    for ctrl in [btnRawSniffer, btnCaptureRaw, txtCaptureHelp, txtCaptureStatus, ddlActionType,
        txtTarget, btnBrowseApp, btnAppArgs, btnEditMacro, btnEditPsScript, btnEditCmdScript, ddlMultimedia, ddlMouse,
        ddlPressType, lblDelayMsUnit, lblRepeatMsUnit, btnClearForm] {
        ctrl.GetPos(&crx, , &crw)
        right := crx + crw
        if right > maxRight
            maxRight := right
    }
    if lblLongPressUnit.Visible {
        lblLongPressUnit.GetPos(&elpX, , &elpW)
        right := elpX + elpW
        if right > maxRight
            maxRight := right
    }
    newWidth := maxRight - gbx + 15
    grpLearnButton.Move(, , newWidth, newBottom - gby)
}

ResizeModifierGroupBox() {
    global grpModifier, lblNumLockFlashMsUnit, mapsX, keymapsBoxW, chkModPt, chkMod2Pt
    lblNumLockFlashMsUnit.GetPos(&lrX, &lrY, &lrW, &lrH)
    grpModifier.GetPos(&gmX, &gmY, &gmW, &gmH)
    newBottom := lrY + lrH + 15
    maxRight := mapsX + keymapsBoxW
    for ctrl in [lblScrollLockFlashMsUnit, lblCapsLockFlashMsUnit, lblNumLockFlashMsUnit, ddlCapsLockLedDevice, btnClearModifier2, txtModLpHint, lblMod2LpMsUnit, chkModPt, chkMod2Pt] {
        ctrl.GetPos(&crx, , &crw)
        right := crx + crw + 15
        if right > maxRight
            maxRight := right
    }
    newWidth := maxRight - gmX
    grpModifier.Move(, , newWidth, newBottom - gmY)
}

ReflowActionAreaForType(deltaY) {
    global controlsBelowActionRow, g
    if deltaY = 0
        return
    for ctrl in controlsBelowActionRow {
        ctrl.GetPos(&cx, &cy)
        ctrl.Move(, cy + deltaY)
    }
    ResizeLearnButtonBox()
    g.GetPos(&gx, &gy, &gw, &gh)
    g.Move(gx, gy, gw, gh + deltaY)
    DllCall("RedrawWindow", "ptr", g.Hwnd, "ptr", 0, "ptr", 0, "uint", 0x0001 | 0x0004 | 0x0080 | 0x0100)
}

OnActionTypeChange(*) {
    global actionAreaExpanded, appExtraRowShift, targetSendString
    isApp := ddlActionType.Value = ACTION_APP
    isMultimedia := ddlActionType.Value = ACTION_MULTIMEDIA
    isMouse := ddlActionType.Value = ACTION_MOUSE
    isMacro := ddlActionType.Value = ACTION_MACRO
    isPs := ddlActionType.Value = ACTION_PS
    isCmd := ddlActionType.Value = ACTION_CMD
    isKey := !isApp && !isMacro && !isMultimedia && !isMouse && !isPs && !isCmd
    lblSends.Visible := isKey
    txtTarget.Visible := isKey
    lblAppPath.Visible := isApp
    editAppPath.Visible := isApp
    btnBrowseApp.Visible := isApp
    btnAppArgs.Visible := isApp
    lblMacroSelect.Visible := isMacro
    ddlMacroSelect.Visible := isMacro
    btnEditMacro.Visible := isMacro
    lblPsScriptSelect.Visible := isPs
    ddlPsScriptSelect.Visible := isPs
    btnEditPsScript.Visible := isPs
    lblCmdScriptSelect.Visible := isCmd
    ddlCmdScriptSelect.Visible := isCmd
    btnEditCmdScript.Visible := isCmd
    lblMultimedia.Visible := isMultimedia
    ddlMultimedia.Visible := isMultimedia
    lblMouse.Visible := isMouse
    ddlMouse.Visible := isMouse
    UpdateMouseNotchesVisibility()
    if isKey && IsCursorSpeedTarget(targetSendString) {
        targetSendString := ""
        txtTarget.Value := ""
    }
    if isMultimedia
        OnMultimediaChange()
    if isMouse
        OnMouseChange()
    if isApp && !actionAreaExpanded {
        ReflowActionAreaForType(appExtraRowShift)
        actionAreaExpanded := true
    } else if !isApp && actionAreaExpanded {
        ReflowActionAreaForType(-appExtraRowShift)
        actionAreaExpanded := false
    }
    EnforceSingleRunOnlyActionTypes()
    EnforceHoldDdlSelection(ddlRunMode, RUNMODE_SINGLE, OnRunModeChange)
}

EnforceSingleRunOnlyActionTypes(*) {
    global ddlActionType, ddlRunMode, ACTION_APP, ACTION_PS, ACTION_CMD, RUNMODE_SINGLE
    isApp := ddlActionType.Value = ACTION_APP || ddlActionType.Value = ACTION_PS || ddlActionType.Value = ACTION_CMD
    if isApp {
        if (ddlRunMode.Value != RUNMODE_SINGLE) {
            ddlRunMode.Choose(RUNMODE_SINGLE)
            OnRunModeChange()
            ApplyRunModeDelayDefault()
        }
    }
    ddlRunMode.Enabled := !isApp
}

OnMultimediaChange(*) {
    global targetSendString
    targetSendString := MultimediaSendForIndex(ddlMultimedia.Value)
    txtCaptureStatus.Value := "Multimedia action: " ddlMultimedia.Text
}

OnMouseChange(*) {
    global targetSendString
    targetSendString := MouseTargetFromForm()
    UpdateMouseNotchesVisibility()
    txtCaptureStatus.Value := "Mouse action: " ddlMouse.Text
}

OnRunModeChange(*) {
    global RUNMODE_SINGLE, RUNMODE_TYPEMATIC, RUNMODE_REPEAT, RUNMODE_TOGGLE_REPEAT
    isSingle := ddlRunMode.Value = RUNMODE_SINGLE
    isTypematic := ddlRunMode.Value = RUNMODE_TYPEMATIC
    showRepeatMs := (ddlRunMode.Value = RUNMODE_TYPEMATIC || ddlRunMode.Value = RUNMODE_REPEAT || ddlRunMode.Value = RUNMODE_TOGGLE_REPEAT)
    swapRows := (ddlRunMode.Value = RUNMODE_REPEAT || ddlRunMode.Value = RUNMODE_TOGGLE_REPEAT)
    repeatRowY := swapRows ? delayTopRowY : repeatBottomRowY
    delayRowYNow := swapRows ? repeatBottomRowY : delayTopRowY
    lblRepeatMs.Move(, repeatRowY)
    edRepeatMs.Move(, repeatRowY)
    lblRepeatMsUnit.Move(, repeatRowY)
    chkDelay.Move(, delayRowYNow)
    lblDelayFixed.Move(, delayRowYNow)
    edDelayMs.Move(, delayRowYNow)
    lblDelayMsUnit.Move(, delayRowYNow)
    lblRepeatMs.Visible := showRepeatMs
    edRepeatMs.Visible := showRepeatMs
    lblRepeatMsUnit.Visible := showRepeatMs
    chkDelay.Visible := showRepeatMs && !isTypematic
    lblDelayFixed.Visible := showRepeatMs && isTypematic
    edDelayMs.Visible := showRepeatMs
    lblDelayMsUnit.Visible := showRepeatMs
    if isTypematic {
        chkDelay.Value := 1
        edDelayMs.Enabled := true
    } else {
        edDelayMs.Enabled := chkDelay.Value ? true : false
    }
    ddlPressType.Visible := isSingle
    if !isSingle
        ddlPressType.Choose(DdlIndexFromPressType("short"))
    UpdateLongPressFieldVisibility()
}

OnDelayCheckChange(*) {
    edDelayMs.Enabled := chkDelay.Value
}

ApplyRunModeDelayDefault(*) {
    global ddlRunMode, chkDelay, edDelayMs, RUNMODE_TYPEMATIC, RUNMODE_REPEAT, RUNMODE_TOGGLE_REPEAT
    if (ddlRunMode.Value = RUNMODE_TYPEMATIC) {
        chkDelay.Value := 1
        edDelayMs.Value := "500"
        OnDelayCheckChange()
    } else if (ddlRunMode.Value = RUNMODE_REPEAT || ddlRunMode.Value = RUNMODE_TOGGLE_REPEAT) {
        chkDelay.Value := 0
        edDelayMs.Value := "200"
        OnDelayCheckChange()
    }
}

PressTypeFromDdlIndex(idx) {
    global PRESSTYPE_IMMEDIATE, PRESSTYPE_LONG_PRESS, PRESSTYPE_ANY_DURATION
    return idx = PRESSTYPE_IMMEDIATE ? "press" : (idx = PRESSTYPE_LONG_PRESS ? "long" : (idx = PRESSTYPE_ANY_DURATION ? "release" : "short"))
}
DdlIndexFromPressType(pt) {
    global PRESSTYPE_IMMEDIATE, PRESSTYPE_LONG_PRESS, PRESSTYPE_ANY_DURATION, PRESSTYPE_SHORT_TAP
    return pt = "press" ? PRESSTYPE_IMMEDIATE : (pt = "long" ? PRESSTYPE_LONG_PRESS : (pt = "release" ? PRESSTYPE_ANY_DURATION : PRESSTYPE_SHORT_TAP))
}

OnEditMacroClick(*) {
    global currentMacroSteps
    OpenMacroEditor(currentMacroSteps, SaveMacroStepsFromMainEditor)
}

BrowseForAppInto(editCtrl) {
    file := FileSelect(, , "Select application or file", "Executables (*.exe)")
    if file != ""
        editCtrl.Value := file
}

EditArgsValue(argsHolder) {
    result := InputBox("Enter command-line arguments (optional):", "Arguments", "w300 h98", argsHolder.Value)
    if result.Result = "OK"
        argsHolder.Value := result.Value
}

ShowGui() {
    global grpModifier, btnKofi
    grpModifier.GetPos(&gmX, &gmY, &gmW, &gmH)
    btnKofi.GetPos(&bkX, &bkY, &bkW, &bkH)
    bottomY := Max(gmY + gmH, bkY + bkH) + 10
    g.Show("h" bottomY)
    RefreshModifierLiveIndicator()
    UpdateActiveProfileStatus()
}

SetCaptureRawMode(val) {
    global captureRawMode
    captureRawMode := !!val
}

OnCaptureKey(ihObj, VK, SC) {
    global capturedSC, lastCaptureKind, mainCaptureOpen, mouseCaptureArmed, capturedMouseButton
    BlockWinKeyStartMenu(VK)
    ihObj.Stop()
    if !mainCaptureOpen
        return
    mainCaptureOpen := false
    SetTimer(ArmMouseCapture, 0)
    SetMouseCaptureArmed(false)
    capturedMouseButton := ""
    capturedSC := SC
    lastCaptureKind := "sc"
    scName := Format("SC{:03X}", SC)
    vkHex := Format("0x{:X}", VK)
    txtCaptureStatus.Value := "Captured " scName " (VK:" vkHex ")"
    editDesc.Value := KeyNameDisplay(VK, SC)
    ResumeButtonHotkeysIfNeeded()
}

IncrementCaptureSuspend() {
    global captureSuspendDepth
    captureSuspendDepth += 1
    if (captureSuspendDepth = 1)
        Suspend(1)
    NativeHookRequestPublish()
}

DecrementCaptureSuspend() {
    global captureSuspendDepth
    if (captureSuspendDepth <= 0)
        return
    captureSuspendDepth -= 1
    if (captureSuspendDepth = 0)
        Suspend(0)
    NativeHookRequestPublish()
}

ResumeButtonHotkeysIfNeeded() {
    global captureSuspended
    if captureSuspended {
        DecrementCaptureSuspend()
        captureSuspended := false
    }
}

CancelPendingButtonCapture() {
    global captureHook, targetCaptureHook, mouseCaptureArmed, mainCaptureOpen
    SetTimer(ArmMouseCapture, 0)
    SetMouseCaptureArmed(false)
    mainCaptureOpen := false
    if IsObject(captureHook) {
        try captureHook.Stop()
        captureHook := ""
    }
    if IsObject(targetCaptureHook) {
        try targetCaptureHook.Stop()
        targetCaptureHook := ""
    }
    ResumeButtonHotkeysIfNeeded()
}

ResetPendingCaptureState() {
    global captureHook, rawCaptureArmed, rawCaptureAwaitingRelease, mouseCaptureArmed, mainCaptureOpen
    if IsObject(captureHook) {
        try captureHook.Stop()
        captureHook := ""
    }
    rawCaptureArmed := false
    rawCaptureAwaitingRelease := false
    SetTimer(ArmMouseCapture, 0)
    SetMouseCaptureArmed(false)
    mainCaptureOpen := false
    ResumeButtonHotkeysIfNeeded()
}

StartCapture(*) {
    global captureHook, captureSuspended, mainCaptureOpen
    ResetPendingCaptureState()
    SetCaptureRawMode(false)
    IncrementCaptureSuspend()
    captureSuspended := true
    mainCaptureOpen := true
    txtCaptureStatus.Value := "Waiting for a key, mouse button or wheel notch..."
    txtCaptureHelp.Value := "Press a key or click a mouse button/scroll wheel. Nothing detected? Try `"Capture raw HID`"."
    captureHook := NewCaptureInputHook(OnCaptureKey, (*) => {}, true)
    SetTimer(ArmMouseCapture, -300)
}

StartRawCapture(*) {
    global rawCaptureArmed
    ResetPendingCaptureState()
    SetCaptureRawMode(true)
    txtCaptureStatus.Value := "Get ready... (waiting for your click to finish)"
    txtCaptureHelp.Value := "Hold button for 100+ms for `"hold capability`" detection(enables Typematic, Repeat while holding and Hold modes)"
    SetTimer(ArmRawCapture, -300)
}

ArmRawCapture() {
    global rawCaptureArmed
    rawCaptureArmed := true
    txtCaptureStatus.Value := "Waiting for button press (raw HID)..."
}

ArmMouseCapture() {
    global mouseCaptureArmed, mainCaptureOpen
    if mainCaptureOpen
        SetMouseCaptureArmed(true)
}

OnMouseButtonCaptured(buttonKey) {
    global mouseCaptureArmed, capturedMouseButton, lastCaptureKind, capturedSC, mainCaptureOpen, captureHook, editingProfileName, editingListName
    SetMouseCaptureArmed(false)
    if !mainCaptureOpen
        return
    mainCaptureOpen := false
    if IsObject(captureHook) {
        if captureHook.InProgress {
            try captureHook.Stop()
            ResumeButtonHotkeysIfNeeded()
        }
        captureHook := ""
    }
    capturedMouseButton := buttonKey
    lastCaptureKind := "mouse"
    capturedSC := 0
    if IsObject(txtCaptureStatus)
        txtCaptureStatus.Value := "Captured mouse button: " buttonKey (IsMouseWheelKey(buttonKey) ? " - single-shot (wheel notches have no hold)" : "")
    if IsObject(txtCaptureStatus) && MouseButtonRemapBlockedInProfile(buttonKey, editingProfileName, editingListName)
        txtCaptureStatus.Value .= " - not allowed on M (Main) in Default profile"
    editDesc.Value := MouseButtonDisplayName(buttonKey)
    ReconcileMainHoldDdls()
}

FinalizeRawCapture(token) {
    global rawCaptureAwaitingRelease, rawCaptureReleaseWindowToken, capturedRawUpBytesHex, capturedRawPage, capturedRawBytesHex
    if !rawCaptureAwaitingRelease || token != rawCaptureReleaseWindowToken
        return
    rawCaptureAwaitingRelease := false
    capturedRawUpBytesHex := ""
    if IsObject(txtCaptureStatus) {
        txtCaptureStatus.Value := Format("Captured: Page:0x{:X} Bytes:{} - Single shot", capturedRawPage, capturedRawBytesHex)
        ReconcileMainHoldDdls()
    }
}

MultimediaOptions() {
    static opts := [
        {name: "Volume Up", send: "{Volume_Up}"},
        {name: "Volume Down", send: "{Volume_Down}"},
        {name: "Mute", send: "{Volume_Mute}"},
        {name: "Play / Pause", send: "{Media_Play_Pause}"},
        {name: "Stop", send: "{Media_Stop}"},
        {name: "Next Track", send: "{Media_Next}"},
        {name: "Previous Track", send: "{Media_Prev}"},
        {name: "Launch Media Player", send: "{Launch_Media}"},
        {name: "Launch Mail", send: "{Launch_Mail}"},
        {name: "Launch App 1", send: "{Launch_App1}"},
        {name: "Launch App 2", send: "{Launch_App2}"},
        {name: "Browser Back", send: "{Browser_Back}"},
        {name: "Browser Forward", send: "{Browser_Forward}"},
        {name: "Browser Refresh", send: "{Browser_Refresh}"},
        {name: "Browser Stop", send: "{Browser_Stop}"},
        {name: "Browser Search", send: "{Browser_Search}"},
        {name: "Browser Favorites", send: "{Browser_Favorites}"},
        {name: "Browser Home", send: "{Browser_Home}"}
    ]
    return opts
}

MultimediaNames() {
    names := []
    for o in MultimediaOptions()
        names.Push(o.name)
    return names
}

MultimediaSendForIndex(idx) {
    opts := MultimediaOptions()
    if idx >= 1 && idx <= opts.Length
        return opts[idx].send
    return ""
}

MultimediaIndexForSend(sendStr) {
    opts := MultimediaOptions()
    for idx, o in opts
        if o.send = sendStr
            return idx
    return 0
}

MouseOptions() {
    static opts := [
        {name: "Left Click", send: "{LButton}"},
        {name: "Right Click", send: "{RButton}"},
        {name: "Middle Click", send: "{MButton}"},
        {name: "Double Left Click", send: "{LButton 2}"},
        {name: "Mouse Button 4 (Back)", send: "{XButton1}"},
        {name: "Mouse Button 5 (Forward)", send: "{XButton2}"},
        {name: "Scroll Up", send: "{WheelUp}"},
        {name: "Scroll Down", send: "{WheelDown}"},
        {name: "Scroll Left", send: "{WheelLeft}"},
        {name: "Scroll Right", send: "{WheelRight}"}
    ]
    return opts
}

MouseNames(includeCursorSpeed := true) {
    names := []
    for o in MouseOptions()
        names.Push(o.name)
    if includeCursorSpeed {
        names.Push("Cursor speed")
        names.Push("Cursor speed Up")
        names.Push("Cursor speed Down")
    }
    return names
}

CursorSpeedEntryKind(idx) {
    base := MouseOptions().Length
    if idx = base + 1
        return "SET"
    if idx = base + 2
        return "UP"
    if idx = base + 3
        return "DOWN"
    return ""
}

IsCursorSpeedTarget(t) => SubStr(t, 1, 13) = "@CURSORSPEED:"

CursorSpeedParse(t) {
    parts := StrSplit(SubStr(t, 14), ":")
    kind := parts.Length >= 1 ? StrUpper(parts[1]) : ""
    n := (parts.Length >= 2 && IsInteger(parts[2])) ? Integer(parts[2]) : (kind = "SET" ? 10 : 1)
    return {kind: kind, n: Max(1, Min(kind = "SET" ? 20 : 19, n))}
}

CursorSpeedLabel(t) {
    p := CursorSpeedParse(t)
    if p.kind = "SET"
        return "Cursor speed = " p.n
    if p.kind = "UP"
        return "Cursor speed +" p.n
    if p.kind = "DOWN"
        return "Cursor speed -" p.n
    if p.kind = "DEFAULT"
        return "Cursor speed = 10"
    return "Cursor speed (unknown)"
}

TargetDisplayText(t) => IsCursorSpeedTarget(t) ? CursorSpeedLabel(t) : HumanizeSendKey(t)

MouseTargetFromForm() {
    idx := ddlMouse.Value
    kind := CursorSpeedEntryKind(idx)
    if kind = "SET" {
        v := IsInteger(edMouseSpeed.Value) ? Integer(edMouseSpeed.Value) : 10
        return "@CURSORSPEED:SET:" Max(1, Min(20, v))
    }
    if kind = "UP" || kind = "DOWN" {
        n := IsInteger(edMouseNotches.Value) ? Integer(edMouseNotches.Value) : 1
        n := Max(1, Min(19, n))
        return "@CURSORSPEED:" kind ":" n
    }
    return MouseSendForIndex(idx)
}

UpdateMouseNotchesVisibility() {
    kind := CursorSpeedEntryKind(ddlMouse.Value)
    isMouse := ddlActionType.Value = ACTION_MOUSE
    show := isMouse && (kind = "UP" || kind = "DOWN")
    lblMouseNotches.Visible := show
    edMouseNotches.Visible := show
    udMouseNotches.Visible := show
    showSet := isMouse && kind = "SET"
    lblMouseSpeed.Visible := showSet
    edMouseSpeed.Visible := showSet
    udMouseSpeed.Visible := showSet
}

RunCursorSpeedTarget(t) {
    static SPI_GETMOUSESPEED := 0x0070, SPI_SETMOUSESPEED := 0x0071
    p := CursorSpeedParse(t)
    if !(p.kind = "SET" || p.kind = "UP" || p.kind = "DOWN" || p.kind = "DEFAULT")
        return
    cur := 0
    if !DllCall("SystemParametersInfo", "UInt", SPI_GETMOUSESPEED, "UInt", 0, "UInt*", &cur, "UInt", 0)
        return
    if p.kind = "DEFAULT"
        newSpeed := 10
    else if p.kind = "SET"
        newSpeed := p.n
    else
        newSpeed := cur + (p.kind = "UP" ? p.n : -p.n)
    newSpeed := Max(1, Min(20, newSpeed))
    if newSpeed != cur
        DllCall("SystemParametersInfo", "UInt", SPI_SETMOUSESPEED, "UInt", 0, "Ptr", newSpeed, "UInt", 0)
    ToolTip("Cursor speed: " newSpeed " / 20")
    SetTimer(ToolTip, -900)
}

MouseSendForIndex(idx) {
    opts := MouseOptions()
    if idx >= 1 && idx <= opts.Length
        return opts[idx].send
    return ""
}

MouseIndexForSend(sendStr) {
    if IsCursorSpeedTarget(sendStr) {
        k := CursorSpeedParse(sendStr).kind
        base := MouseOptions().Length
        return k = "SET" ? base + 1 : (k = "UP" ? base + 2 : (k = "DOWN" ? base + 3 : (k = "DEFAULT" ? base + 1 : 0)))
    }
    opts := MouseOptions()
    for idx, o in opts
        if o.send = sendStr
            return idx
    return 0
}

FormatSendKey(keyName) {
    if StrLen(keyName) = 1 {
        if InStr("^!+#{}", keyName)
            return "{" keyName "}"
        return keyName
    }
    return "{" keyName "}"
}

FormatSendKeyRaw(VK, SC, keyName) {
    if StrLen(keyName) = 1
        return "{vk" Format("{:X}", VK) "sc" Format("{:X}", SC) "}"
    return FormatSendKey(keyName)
}

KeyDisplayName(keyName) {
    static names := Map(
        "LWin", "Win", "RWin", "Win",
        "LControl", "Ctrl", "RControl", "Ctrl", "Control", "Ctrl",
        "LShift", "Shift", "RShift", "Shift",
        "LAlt", "Alt", "RAlt", "Alt",
        "Volume_Up", "Volume Up", "Volume_Down", "Volume Down", "Volume_Mute", "Mute",
        "Media_Play_Pause", "Play/Pause", "Media_Stop", "Media Stop",
        "Media_Next", "Next Track", "Media_Prev", "Previous Track",
        "Launch_Media", "Launch Media Player", "Launch_Mail", "Launch Mail",
        "Launch_App1", "Launch App 1", "Launch_App2", "Launch App 2",
        "Browser_Back", "Browser Back", "Browser_Forward", "Browser Forward",
        "Browser_Refresh", "Browser Refresh", "Browser_Stop", "Browser Stop",
        "Browser_Search", "Browser Search", "Browser_Favorites", "Browser Favorites",
        "Browser_Home", "Browser Home",
        "LButton", "Left Click", "LButton 2", "Double Left Click", "RButton", "Right Click", "MButton", "Middle Click",
        "XButton1", "Mouse Button 4", "XButton2", "Mouse Button 5",
        "WheelUp", "Scroll Up", "WheelDown", "Scroll Down",
        "WheelLeft", "Scroll Left", "WheelRight", "Scroll Right")
    return names.Has(keyName) ? names[keyName] : keyName
}

HumanizeSendKey(sendStr) {
    if sendStr = ""
        return ""
    modNames := []
    i := 1
    len := StrLen(sendStr)
    while i <= len {
        c := SubStr(sendStr, i, 1)
        if c = "^"
            modNames.Push("Ctrl"), i++
        else if c = "!"
            modNames.Push("Alt"), i++
        else if c = "+"
            modNames.Push("Shift"), i++
        else if c = "#"
            modNames.Push("Win"), i++
        else
            break
    }
    rest := SubStr(sendStr, i)
    keyLabel := ""
    if SubStr(rest, 1, 1) = "{" && SubStr(rest, -1) = "}" {
        inner := SubStr(rest, 2, StrLen(rest) - 2)
        keyLabel := (RegExMatch(inner, "i)^vk[0-9a-f]+sc[0-9a-f]+$") && GetKeyName(inner) != "")
            ? StrUpper(GetKeyName(inner))
            : KeyDisplayName(inner)
    } else if rest != ""
        keyLabel := StrUpper(rest)
    parts := modNames
    if keyLabel != ""
        parts.Push(keyLabel)
    label := ""
    for idx, p in parts
        label .= (idx = 1 ? "" : "+") p
    return label
}

FinalizeTarget(modStr, keyName, VK := 0, SC := 0) {
    global targetSendString
    targetSendString := modStr FormatSendKeyRaw(VK, SC, keyName)
    txtTarget.Value := HumanizeSendKey(targetSendString)
    txtCaptureStatus.Value := "Captured target key: " HumanizeSendKey(targetSendString) " (still listening - press another key to change it, or click away to stop)"
}

OnTargetKeyDown(ihObj, VK, SC) {
    global targetHeldMods, targetComboFired
    if IsModifierVK(VK) {
        BlockWinKeyStartMenu(VK)
        targetHeldMods[VK] := true
        return
    }
    keyName := KeyNameFor(VK, SC)
    FinalizeTarget(BuildModStrFromHeld(targetHeldMods), keyName, VK, SC)
    targetComboFired := true
}

OnTargetKeyUp(ihObj, VK, SC) {
    global targetHeldMods, targetComboFired
    if !IsModifierVK(VK)
        return
    if targetHeldMods.Has(VK)
        targetHeldMods.Delete(VK)
    allModsUp := (targetHeldMods.Count = 0)
    if targetComboFired {
        if allModsUp
            targetComboFired := false
        return
    }
    if !allModsUp
        return
    keyName := KeyNameFor(VK, SC)
    FinalizeTarget("", keyName, VK, SC)
}

StartTargetCapture(*) {
    global targetCaptureHook, targetComboFired, targetHeldMods, captureSuspended
    if IsObject(targetCaptureHook) {
        try targetCaptureHook.Stop()
    }
    ResumeButtonHotkeysIfNeeded()
    IncrementCaptureSuspend()
    captureSuspended := true
    targetComboFired := false
    targetHeldMods := Map()
    txtTarget.Value := ""
    txtCaptureStatus.Value := "Waiting for target key/combo... (press it now, e.g. Space, Win, Ctrl+Alt+S)"
    targetCaptureHook := NewCaptureInputHook(OnTargetKeyDown, OnTargetKeyUp, true)
}

StopTargetCapture(*) {
    global targetCaptureHook, targetSendString
    if IsObject(targetCaptureHook) {
        try targetCaptureHook.Stop()
        targetCaptureHook := ""
    }
    ResumeButtonHotkeysIfNeeded()
    txtTarget.Value := HumanizeSendKey(targetSendString)
    if targetSendString != ""
        txtCaptureStatus.Value := "Captured target key: " HumanizeSendKey(targetSendString)
}

ResetCaptureUI() {
    global capturedSC, targetSendString, capturedRawPage, capturedRawBytesHex, capturedRawUpBytesHex, rawCaptureAwaitingRelease, rawCaptureReleaseWindowToken, lastCaptureKind, rawCaptureArmed, editingId, currentMacroSteps, legacyLongPressMs
    global mouseCaptureArmed, capturedMouseButton, mainCaptureOpen, captureHook
    global currentPsScriptBody, currentPsScriptName, currentCmdScriptBody, currentCmdScriptName
    global currentPsScriptHide, currentCmdScriptHide
    capturedSC := 0
    SetTimer(ArmMouseCapture, 0)
    SetMouseCaptureArmed(false)
    capturedMouseButton := ""
    mainCaptureOpen := false
    if IsObject(captureHook) {
        if captureHook.InProgress {
            try captureHook.Stop()
            ResumeButtonHotkeysIfNeeded()
        }
        captureHook := ""
    }
    capturedRawPage := 0
    capturedRawBytesHex := ""
    capturedRawUpBytesHex := ""
    rawCaptureAwaitingRelease := false
    rawCaptureReleaseWindowToken++
    lastCaptureKind := "sc"
    rawCaptureArmed := false
    editingId := ""
    targetSendString := ""
    currentMacroSteps := []
    currentPsScriptBody := ""
    currentPsScriptName := ""
    currentCmdScriptBody := ""
    currentCmdScriptName := ""
    currentPsScriptHide := false
    currentCmdScriptHide := false
    editDesc.Value := ""
    txtTarget.Value := ""
    editAppPath.Value := ""
    editAppArgs.Value := ""
    ddlActionType.Choose(1)
    ddlMultimedia.Choose(1)
    ddlMouse.Choose(1)
    udMouseNotches.Value := 1
    udMouseSpeed.Value := 10
    OnActionTypeChange()
    ddlRunMode.Choose(1)
    edRepeatMs.Value := "100"
    edLongPressMs.Value := String(legacyLongPressMs)
    OnRunModeChange()
    ApplyRunModeDelayDefault()
    ddlPressType.Choose(DdlIndexFromPressType("press"))
    UpdateMacroSelectDdl()
    UpdatePsScriptSelectDdl()
    UpdateCmdScriptSelectDdl()
    txtCaptureStatus.Value := "Not captured yet."
    ReconcileMainHoldDdls()
}

LV_GetTopIndex(ctrl) {
    return SendMessage(0x1027, 0, 0, , "ahk_id " ctrl.Hwnd)
}

LV_RestoreTopIndex(ctrl, topIndex) {
    count := ctrl.GetCount()
    if count = 0 || topIndex <= 0
        return
    if topIndex > count - 1
        topIndex := count - 1
    SendMessage(0x1013, count - 1, 0, , "ahk_id " ctrl.Hwnd)
    SendMessage(0x1013, topIndex, 0, , "ahk_id " ctrl.Hwnd)
}

LV_GetColumnWidth(ctrl, col) {
    return SendMessage(0x101D, col - 1, 0, , "ahk_id " ctrl.Hwnd)
}

LVKeymapCustomDraw(wParam, lParam, msg, hwnd) {
    global lv, lvKeys, mappings
    global NM_CUSTOMDRAW, CDDS_PREPAINT, CDDS_ITEMPREPAINT, CDDS_SUBITEM
    global CDRF_DODEFAULT, CDRF_NEWFONT, CDRF_NOTIFYITEMDRAW, CDRF_NOTIFYSUBITEMDRAW
    global DISABLED_BK, DISABLED_TX
    try {
        if !IsObject(lv)
            return
        if NumGet(lParam, 0, "Ptr") != lv.Hwnd
            return
        if NumGet(lParam, A_PtrSize * 2, "Int") != NM_CUSTOMDRAW
            return

        nmhdrSize := (A_PtrSize = 8) ? 24 : 12
        offDrawStage := nmhdrSize
        offHdc := (A_PtrSize = 8) ? 32 : 16
        offItemSpec := offHdc + A_PtrSize + 16
        nmcdSize := (A_PtrSize = 8) ? 80 : 48
        offClrText := nmcdSize
        offClrTextBk := nmcdSize + 4
        offSubItem := nmcdSize + 8

        stage := NumGet(lParam, offDrawStage, "UInt")
        if stage = CDDS_PREPAINT
            return CDRF_NOTIFYITEMDRAW
        if stage = CDDS_ITEMPREPAINT
            return CDRF_NOTIFYSUBITEMDRAW
        if stage != (CDDS_ITEMPREPAINT | CDDS_SUBITEM)
            return

        if NumGet(lParam, offSubItem, "Int") != 0
            return CDRF_DODEFAULT

        row := NumGet(lParam, offItemSpec, "UPtr") + 1
        if row < 1 || row > lvKeys.Length
            return CDRF_DODEFAULT
        key := lvKeys[row]
        if !mappings.Has(key)
            return CDRF_DODEFAULT
        if mappings[key].enabled
            return CDRF_DODEFAULT

        NumPut("UInt", DISABLED_TX, lParam, offClrText)
        NumPut("UInt", DISABLED_BK, lParam, offClrTextBk)
        return CDRF_NEWFONT
    }
}

RefreshList() {
    global lvKeys, editingProfileName, editingListName, editingDevTab
    topIndex := LV_GetTopIndex(lv)
    lv.Delete()
    lvKeys := []
    for key in mapOrder {
        m := mappings[key]
        if (MapProfile(m)) != editingProfileName
            continue
        if (MapList(m)) != editingListName
            continue
        if (MapDevTab(m)) != editingDevTab
            continue
        actionType := MapActionType(m)
        if actionType = "app" {
            args := MapAppArgs(m)
            sendsDisplay := "Launch: " m.target (args != "" ? " " args : "")
        } else if actionType = "macro" {
            steps := ResolveMacroSteps(m)
            savedName := MapMacroName(m)
            if savedName = ""
                savedName := FindSavedMacroNameForSteps(steps)
            if savedName != ""
                sendsDisplay := "Macro: " savedName
            else {
                n := steps.Length
                sendsDisplay := "Macro (" n " step" (n = 1 ? "" : "s") ")"
            }
        } else if actionType = "ps" || actionType = "cmd" {
            label := actionType = "ps" ? "PS" : "CMD"
            savedName := MapScriptName(m)
            if savedName = ""
                savedName := FindSavedScriptNameForBody(actionType, m.target)
            sendsDisplay := savedName != "" ? label ": " savedName : label " (custom script)"
            if MapHideWindow(m)
                sendsDisplay .= " (hidden)"
        } else {
            sendsDisplay := TargetDisplayText(m.target)
        }
        runMode := MapRunMode(m)
        if runMode = "repeat"
            pressDisplay := "Repeat"
        else if runMode = "toggle"
            pressDisplay := "TRepeat"
        else if runMode = "hold"
            pressDisplay := "Hold"
        else if runMode = "toggleHold"
            pressDisplay := "THold"
        else if runMode = "typematic"
            pressDisplay := "Typematic"
        else {
            mPressType := MapPressType(m)
            pressDisplay := mPressType = "press" ? "Press" : (mPressType = "long" ? "Long" : (mPressType = "release" ? "Release" : "Short"))
        }
        lv.Add(, m.enabled ? "Yes" : "No", m.desc, sendsDisplay, pressDisplay)
        lvKeys.Push(key)
    }
    LV_RestoreTopIndex(lv, topIndex)
    UpdateListRadioMarkers()
}

ProfileHasMapsInList(profileName, devTab, listName) {
    global mappings, mapOrder
    for key in mapOrder {
        m := mappings[key]
        if MapProfile(m) != profileName
            continue
        if MapDevTab(m) != devTab
            continue
        if MapList(m) = listName
            return true
    }
    return false
}

UpdateListRadioMarkers() {
    global editingProfileName, editingDevTab, listRadioLabels
    static shownBold := Map()
    if !IsSet(listRadioLabels) || listRadioLabels.Length < 3
        return
    for idx, listName in ["Main", "Mod", "Mod2"] {
        ctrl := listRadioLabels[idx]
        hasMaps := ProfileHasMapsInList(editingProfileName, editingDevTab, listName)
        if shownBold.Get(ctrl.Hwnd, false) = hasMaps
            continue
        ctrl.SetFont(hasMaps ? "bold" : "norm")
        shownBold[ctrl.Hwnd] := hasMaps
    }
}

LVSelect(lvObj, rowNum, selected) {
    global capturedSC, targetSendString, capturedRawPage, capturedRawBytesHex, capturedRawUpBytesHex, lastCaptureKind, editingId, lvKeys, currentMacroSteps
    global capturedMouseButton
    if !selected
        return
    if rowNum < 1 || rowNum > lvKeys.Length
        return
    key := lvKeys[rowNum]
    m := mappings[key]
    editingId := key
    currentMacroSteps := CloneMacroSteps(ResolveMacroSteps(m))
    ApplyActionFieldsFromMapping(m)
    ddlPressType.Choose(DdlIndexFromPressType(MapPressType(m)))
    runMode := MapRunMode(m)
    ddlRunMode.Choose(runMode = "repeat" ? 3 : (runMode = "toggle" ? 4 : (runMode = "hold" ? 5 : (runMode = "toggleHold" ? 6 : (runMode = "typematic" ? 1 : 2)))))
    edRepeatMs.Value := String(MapRepeatMs(m))
    chkDelay.Value := MapDelayEnabled(m) ? 1 : 0
    edDelayMs.Value := String(MapDelayMs(m))
    edLongPressMs.Value := String(MapLongPressMs(m))
    OnDelayCheckChange()
    OnRunModeChange()
    EnforceSingleRunOnlyActionTypes()
    if (MapKind(m)) = "raw" {
        capturedSC := 0
        capturedRawPage := m.page
        capturedRawBytesHex := m.bytesHex
        capturedRawUpBytesHex := MapUpBytesHex(m)
        lastCaptureKind := "raw"
        SetAddDevTabSelection(MapDevTab(m))
        editDesc.Value := m.desc
        if capturedRawUpBytesHex = "" {
            ddlRunMode.Choose(2)
            OnRunModeChange()
            txtCaptureStatus.Value := Format("Editing raw mapping (Page:0x{:X} Bytes:{}) - single-shot, no release signature learned - press Update Mapping to save changes, or Add to Main/Add to Mod 1 for a new one on this same button", m.page, m.bytesHex)
        } else {
            txtCaptureStatus.Value := Format("Editing raw mapping (Page:0x{:X} Bytes:{}, release: Bytes:{}) - press Update Mapping to save changes, or Add to Main/Add to Mod 1 for a new one on this same button", m.page, m.bytesHex, capturedRawUpBytesHex)
        }
        ReconcileMainHoldDdls()
        return
    }
    if (MapKind(m)) = "mouse" {
        capturedSC := 0
        capturedMouseButton := m.button
        lastCaptureKind := "mouse"
        SetAddDevTabSelection(MapDevTab(m))
        editDesc.Value := m.desc
        txtCaptureStatus.Value := "Editing mouse mapping (" m.button ") - press Update Mapping to save changes, or Add to Main/Add to Mod 1 for a new one on this same button"
        if IsMouseWheelKey(m.button) {
            ddlRunMode.Choose(2)
            OnRunModeChange()
        }
        ReconcileMainHoldDdls()
        return
    }
    lastCaptureKind := "sc"
    SetAddDevTabSelection(MapDevTab(m))
    capturedSC := m.sc
    editDesc.Value := m.desc
    txtCaptureStatus.Value := "Editing " key " (press Update Mapping to save changes, or Add to Main/Add to Mod 1 for a new one on this same button)"
    ReconcileMainHoldDdls()
}

LVContextMenu(GuiCtrlObj, Item, IsRightClick, X, Y) {
    global lvKeys, editingProfileName, editingDevTab, profiles, savedMacros, savedMacroOrder
    global savedPsScriptOrder, savedCmdScriptOrder
    if !Item || Item > lvKeys.Length
        return

    isPartOfSelection := false
    row := 0
    loop {
        row := lv.GetNext(row)
        if !row
            break
        if row = Item {
            isPartOfSelection := true
            break
        }
    }
    if !isPartOfSelection
        lv.Modify(Item, "Select Focus")
    else
        lv.Modify(Item, "Focus")

    keys := []
    row := 0
    loop {
        row := lv.GetNext(row)
        if !row
            break
        if mappings.Has(lvKeys[row])
            keys.Push(lvKeys[row])
    }
    if !keys.Length
        return

    ctxMenu := Menu()

    copyMenu := Menu()
    otherCount := 0
    editingKey := ProfileKey(editingDevTab, editingProfileName)
    for pkey in profiles {
        if pkey = editingKey
            continue
        pTab := ProfileKeyTab(pkey)
        if pTab != "" && pTab != editingDevTab
            continue
        otherCount++
        copyMenu.Add(ProfileKeyName(pkey), CopyMappingsToProfile.Bind(keys, pkey))
    }
    if !otherCount {
        copyMenu.Add("No other profiles", (*) => "")
        copyMenu.Disable("No other profiles")
    }
    ctxMenu.Add("Copy to", copyMenu)

    macroMenu := Menu()
    if savedMacroOrder.Length {
        for mname in savedMacroOrder
            macroMenu.Add(mname, AssignMacroToMappings.Bind(keys, mname))
    } else {
        macroMenu.Add("No saved macros", (*) => "")
        macroMenu.Disable("No saved macros")
    }
    ctxMenu.Add("Map macro", macroMenu)

    psMenu := Menu()
    if savedPsScriptOrder.Length {
        for psName in savedPsScriptOrder
            psMenu.Add(psName, AssignPsScriptToMappings.Bind(keys, psName))
    } else {
        psMenu.Add("No saved PS scripts", (*) => "")
        psMenu.Disable("No saved PS scripts")
    }
    ctxMenu.Add("Map PS Script", psMenu)

    cmdMenu := Menu()
    if savedCmdScriptOrder.Length {
        for cmdName in savedCmdScriptOrder
            cmdMenu.Add(cmdName, AssignCmdScriptToMappings.Bind(keys, cmdName))
    } else {
        cmdMenu.Add("No saved CMD scripts", (*) => "")
        cmdMenu.Disable("No saved CMD scripts")
    }
    ctxMenu.Add("Map CMD", cmdMenu)

    MouseGetPos(&mx, &my)
    ctxMenu.Show(mx, my)
}

AssignMacroToMappings(targetKeys, macroName, *) {
    global mappings, savedMacros, editingId, currentMacroSteps
    if !savedMacros.Has(macroName)
        return
    steps := savedMacros[macroName]
    appliedCount := 0
    lastDesc := ""
    appliedKeys := []
    for key in targetKeys {
        if !mappings.Has(key)
            continue
        m := mappings[key]
        m.actionType := "macro"
        m.macroSteps := CloneMacroSteps(steps)
        m.macroName := macroName
        m.target := ""
        m.appArgs := ""
        appliedCount++
        appliedKeys.Push(key)
        lastDesc := m.desc
    }
    if !appliedCount
        return
    for key in appliedKeys
        SaveProfileMapping(MapProfileKey(mappings[key]), key)
    RefreshList()
    if editingId != "" && HasVal(targetKeys, editingId) && mappings.Has(editingId) {
        currentMacroSteps := CloneMacroSteps(ResolveMacroSteps(mappings[editingId]))
        ApplyActionFieldsFromMapping(mappings[editingId])
    }
    txtStatus.Value := appliedCount = 1
        ? "Mapped macro '" macroName "' to '" lastDesc "'."
        : "Mapped macro '" macroName "' to " appliedCount " mappings."
}

AssignPsScriptToMappings(targetKeys, name, *) {
    global mappings, savedPsScripts, editingId
    if !savedPsScripts.Has(name)
        return
    body := savedPsScripts[name]
    appliedCount := 0
    lastDesc := ""
    appliedKeys := []
    for key in targetKeys {
        if !mappings.Has(key)
            continue
        m := mappings[key]
        m.actionType := "ps"
        m.macroSteps := []
        m.macroName := ""
        m.target := body
        m.scriptName := name
        m.hideWindow := ScriptHideFlag("ps", name)
        m.appArgs := ""
        m.runMode := "single"
        appliedCount++
        appliedKeys.Push(key)
        lastDesc := m.desc
    }
    if !appliedCount
        return
    for key in appliedKeys
        SaveProfileMapping(MapProfileKey(mappings[key]), key)
    RefreshList()
    if editingId != "" && HasVal(targetKeys, editingId) && mappings.Has(editingId) {
        ApplyActionFieldsFromMapping(mappings[editingId])
        ddlRunMode.Choose(RUNMODE_SINGLE)
        OnRunModeChange()
        EnforceSingleRunOnlyActionTypes()
    }
    txtStatus.Value := appliedCount = 1
        ? "Mapped PS script '" name "' to '" lastDesc "'."
        : "Mapped PS script '" name "' to " appliedCount " mappings."
}

AssignCmdScriptToMappings(targetKeys, name, *) {
    global mappings, savedCmdScripts, editingId
    if !savedCmdScripts.Has(name)
        return
    body := savedCmdScripts[name]
    appliedCount := 0
    lastDesc := ""
    appliedKeys := []
    for key in targetKeys {
        if !mappings.Has(key)
            continue
        m := mappings[key]
        m.actionType := "cmd"
        m.macroSteps := []
        m.macroName := ""
        m.target := body
        m.scriptName := name
        m.hideWindow := ScriptHideFlag("cmd", name)
        m.appArgs := ""
        m.runMode := "single"
        appliedCount++
        appliedKeys.Push(key)
        lastDesc := m.desc
    }
    if !appliedCount
        return
    for key in appliedKeys
        SaveProfileMapping(MapProfileKey(mappings[key]), key)
    RefreshList()
    if editingId != "" && HasVal(targetKeys, editingId) && mappings.Has(editingId) {
        ApplyActionFieldsFromMapping(mappings[editingId])
        ddlRunMode.Choose(RUNMODE_SINGLE)
        OnRunModeChange()
        EnforceSingleRunOnlyActionTypes()
    }
    txtStatus.Value := appliedCount = 1
        ? "Mapped CMD script '" name "' to '" lastDesc "'."
        : "Mapped CMD script '" name "' to " appliedCount " mappings."
}

ApplyActionFieldsFromMapping(m) {
    global targetSendString
    global currentPsScriptBody, currentPsScriptName, currentCmdScriptBody, currentCmdScriptName
    global currentPsScriptHide, currentCmdScriptHide
    actionType := MapActionType(m)
    currentPsScriptBody := ""
    currentPsScriptName := ""
    currentCmdScriptBody := ""
    currentCmdScriptName := ""
    currentPsScriptHide := false
    currentCmdScriptHide := false
    if actionType = "ps" || actionType = "cmd" {
        ddlActionType.Choose(actionType = "ps" ? ACTION_PS : ACTION_CMD)
        if actionType = "ps" {
            currentPsScriptBody := m.target
            currentPsScriptName := MapScriptName(m)
            currentPsScriptHide := MapHideWindow(m)
        } else {
            currentCmdScriptBody := m.target
            currentCmdScriptName := MapScriptName(m)
            currentCmdScriptHide := MapHideWindow(m)
        }
        targetSendString := ""
        txtTarget.Value := ""
        editAppPath.Value := ""
        editAppArgs.Value := ""
    } else if actionType = "app" {
        ddlActionType.Choose(2)
        editAppPath.Value := m.target
        editAppArgs.Value := MapAppArgs(m)
        targetSendString := ""
        txtTarget.Value := ""
    } else if actionType = "macro" {
        ddlActionType.Choose(5)
        targetSendString := ""
        txtTarget.Value := ""
        editAppPath.Value := ""
        editAppArgs.Value := ""
    } else {
        mmIdx := MultimediaIndexForSend(m.target)
        mouseIdx := MouseIndexForSend(m.target)
        if mmIdx {
            ddlActionType.Choose(3)
            ddlMultimedia.Choose(mmIdx)
        } else if mouseIdx {
            ddlActionType.Choose(4)
            ddlMouse.Choose(mouseIdx)
            if IsCursorSpeedTarget(m.target) {
                cs := CursorSpeedParse(m.target)
                if cs.kind = "SET"
                    udMouseSpeed.Value := cs.n
                else if cs.kind = "DEFAULT"
                    udMouseSpeed.Value := 10
                else
                    udMouseNotches.Value := cs.n
            }
        } else {
            ddlActionType.Choose(1)
        }
        targetSendString := m.target
        txtTarget.Value := IsCursorSpeedTarget(m.target) ? "" : HumanizeSendKey(m.target)
        editAppPath.Value := ""
        editAppArgs.Value := ""
    }
    OnActionTypeChange()
    UpdateMacroSelectDdl()
    UpdatePsScriptSelectDdl()
    UpdateCmdScriptSelectDdl()
}

MoveKeymapRow(dir) {
    global mapOrder, lvKeys, editingProfileName, editingDevTab
    selKeys := GetSelectedKeys()
    if selKeys.Length = 0 {
        MsgBox("Select a mapping first.", "Nothing selected", "Icon!")
        return
    }
    selectedSet := Map()
    for k in selKeys
        selectedSet[k] := true
    visible := lvKeys.Clone()
    n := visible.Length
    swaps := []
    if dir < 0 {
        loop n - 1 {
            i := A_Index + 1
            if selectedSet.Has(visible[i]) && !selectedSet.Has(visible[i - 1]) {
                swaps.Push([visible[i], visible[i - 1]])
                tmp := visible[i]
                visible[i] := visible[i - 1]
                visible[i - 1] := tmp
            }
        }
    } else {
        loop n - 1 {
            i := n - A_Index
            if selectedSet.Has(visible[i]) && !selectedSet.Has(visible[i + 1]) {
                swaps.Push([visible[i], visible[i + 1]])
                tmp := visible[i]
                visible[i] := visible[i + 1]
                visible[i + 1] := tmp
            }
        }
    }
    if swaps.Length = 0
        return
    for pair in swaps {
        idxA := 0
        idxB := 0
        for i, k in mapOrder {
            if k = pair[1]
                idxA := i
            else if k = pair[2]
                idxB := i
        }
        if idxA && idxB {
            tmp := mapOrder[idxA]
            mapOrder[idxA] := mapOrder[idxB]
            mapOrder[idxB] := tmp
        }
    }
    SaveProfileOrder(ProfileKey(editingDevTab, editingProfileName))
    RefreshList()
    ReselectKeys(selKeys)
}

GetSelectedKeys() {
    global lvKeys
    keys := []
    row := 0
    loop {
        row := lv.GetNext(row)
        if !row
            break
        if row <= lvKeys.Length
            keys.Push(lvKeys[row])
    }
    return keys
}

ReselectKeys(keys) {
    global lvKeys
    keySet := Map()
    for k in keys
        keySet[k] := true
    first := true
    for row, k in lvKeys {
        if keySet.Has(k) {
            lv.Modify(row, first ? "Select Focus" : "Select")
            first := false
        }
    }
}

ToggleMappingKeys(keys) {
    global mappings, editingProfileName, editingDevTab
    if keys.Length = 0
        return
    buttonKeysToRefresh := Map()
    for key in keys {
        m := mappings[key]
        m.enabled := !m.enabled
        if !m.enabled
            StopRepeat(key)
        if (MapKind(m)) = "sc"
            buttonKeysToRefresh[Format("SC{:03X}", m.sc)] := true
    }
    for bk in buttonKeysToRefresh
        RegisterHotkeyForButton(bk)
    pkey := ProfileKey(editingDevTab, editingProfileName)
    for key in keys
        SaveProfileMapping(pkey, key)
    InvalidateMouseBlockCache()
    RefreshList()
    ReselectKeys(keys)
}

OnKeymapDoubleClick(GuiCtrlObj, RowNumber) {
    global lvKeys
    if RowNumber < 1 || RowNumber > lvKeys.Length
        return
    ToggleMappingKeys([lvKeys[RowNumber]])
}

RemoveSelected(*) {
    global mappings, mapOrder, editingProfileName, editingDevTab, lvKeys
    keys := GetSelectedKeys()
    if keys.Length = 0 {
        MsgBox("Select a mapping first.", "Nothing selected", "Icon!")
        return
    }
    anchorRow := 0
    row := 0
    loop {
        row := lv.GetNext(row)
        if !row
            break
        if anchorRow = 0
            anchorRow := row
    }
    keySet := Map()
    buttonKeysToRefresh := Map()
    for key in keys {
        keySet[key] := true
        if mappings.Has(key) {
            m := mappings[key]
            if (MapKind(m)) = "sc"
                buttonKeysToRefresh[Format("SC{:03X}", m.sc)] := true
        }
    }
    for key in keys {
        StopRepeat(key)
        mappings.Delete(key)
    }
    newOrder := []
    for k in mapOrder {
        if !keySet.Has(k)
            newOrder.Push(k)
    }
    mapOrder := newOrder
    for bk in buttonKeysToRefresh
        RegisterHotkeyForButton(bk)
    pkey := ProfileKey(editingDevTab, editingProfileName)
    for key in keys
        DeleteProfileMappingSection(pkey, key)
    InvalidateMouseBlockCache()
    RefreshList()
    ResetCaptureUI()
    if lvKeys.Length > 0 {
        newRow := Min(anchorRow, lvKeys.Length)
        lv.Modify(newRow, "Select Focus Vis")
    }
}
