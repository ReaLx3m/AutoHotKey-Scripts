
SaveMacroStepsFromMainEditor(steps) {
    global currentMacroSteps
    currentMacroSteps := steps
    UpdateMacroSelectDdl()
}

OnMacroSelectChange(*) {
    global currentMacroSteps, savedMacros, savedMacroOrder, ddlMacroSelect
    idx := ddlMacroSelect.Value
    if idx <= 1
        return
    name := savedMacroOrder[idx - 1]
    if !savedMacros.Has(name)
        return
    currentMacroSteps := CloneMacroSteps(savedMacros[name])
}

UpdateMacroSelectDdl() {
    global currentMacroSteps, savedMacroOrder, ddlMacroSelect
    items := ["(Custom / unsaved)"]
    for name in savedMacroOrder
        items.Push(name)
    ddlMacroSelect.Delete()
    ddlMacroSelect.Add(items)
    matchIdx := 1
    matchName := FindSavedMacroNameForSteps(currentMacroSteps)
    if matchName != "" {
        for i, name in savedMacroOrder {
            if name = matchName {
                matchIdx := i + 1
                break
            }
        }
    }
    ddlMacroSelect.Choose(matchIdx)
}

OpenMacroEditor(initialSteps, onSave) {
    global gMacro, macroEditSteps, lvMacroSteps
    global macroRecording, recordHook, recordLastEventTick, recordHeldKeys
    global macroStepControls
    global macroLvColW1, macroLvColW2, macroLvColW3, macroLvColW4
    global savedMacros, savedMacroOrder, lbSavedMacros
    macroEditSteps := []
    macroRecording := false
    recordHook := ""
    recordLastEventTick := 0
    recordHeldKeys := Map()
    for s in initialSteps
        macroEditSteps.Push({type: s.type, target: s.HasOwnProp("target") ? s.target : "", args: s.HasOwnProp("args") ? s.args : "", delayAfterMs: s.HasOwnProp("delayAfterMs") ? s.delayAfterMs : 0})

    gMacro := Gui("+Owner" g.Hwnd, "Edit Macro")
    gMacro.SetFont("s10", "Segoe UI")

    lblSavedMacrosHeader := gMacro.Add("Text", "xm y10", "Saved Macros")
    lblSavedMacrosHeader.GetPos(&smhX, &smhY, &smhW, &smhH)
    savedMacroBoxW := 165
    savedMacroGap := 10
    lbSavedMacros := gMacro.Add("ListBox", "x" smhX " y+2 w" savedMacroBoxW " h600")
    lbSavedMacros.OnEvent("Change", (*) => OnSavedMacroSelectionChange())
    lbSavedMacros.GetPos(&smX, &smY, &smW, &smH)
    RefreshSavedMacrosList()

    savedMacroBtnGap := 3
    savedMacroBtnW := (smW - 2 * savedMacroBtnGap) // 3
    btnSaveMacro := gMacro.Add("Button", "x" smX " y" (smY + smH + 10) " w" savedMacroBtnW, "Save")
    btnSaveMacro.OnEvent("Click", (*) => OpenSaveMacroNameDialog())
    btnUpdateSavedMacro := gMacro.Add("Button", "x+" savedMacroBtnGap " yp w" savedMacroBtnW, "Update")
    btnUpdateSavedMacro.OnEvent("Click", (*) => UpdateSelectedSavedMacro())
    btnDeleteSavedMacro := gMacro.Add("Button", "x+" savedMacroBtnGap " yp w" savedMacroBtnW, "Delete")
    btnDeleteSavedMacro.OnEvent("Click", (*) => DeleteSelectedSavedMacro())

    btnDeleteSavedMacro.GetPos(&smBtnX, &smBtnY, &smBtnW, &smBtnH)
    radStepKey := gMacro.Add("Radio", "x" smX " y" (smBtnY + smBtnH + 15) " w" savedMacroBoxW " +0x8 Group Checked", "Send Key/Combo")
    radStepApp := gMacro.Add("Radio", "x" smX " y+8 w" savedMacroBoxW " +0x8", "Launch App")
    radStepMultimedia := gMacro.Add("Radio", "x" smX " y+8 w" savedMacroBoxW " +0x8", "Multimedia")

    stepsX := smX + smW + savedMacroGap
    gMacro.Add("Text", "x" stepsX " y" smhY " w560", "Steps run top to bottom, in order, each time this macro fires. Double-click a step's Delay after value to change it.")

    lvMacroSteps := gMacro.Add("ListView", "x" stepsX " y" smY " w560 h600", ["#", "Type", "Target", "Delay after (ms)"])
    lvMacroSteps.ModifyCol(1, macroLvColW1)
    lvMacroSteps.ModifyCol(2, macroLvColW2)
    lvMacroSteps.ModifyCol(3, macroLvColW3)
    lvMacroSteps.ModifyCol(4, macroLvColW4)
    lvMacroSteps.OnEvent("DoubleClick", OnMacroStepDoubleClick)
    RefreshMacroStepsList()

    btnRecordMacro := gMacro.Add("Button", "x" stepsX " y+12 w120", "Record Macro")
    btnInsertWait := gMacro.Add("Button", "x+10", "Insert Delay")
    edStepDelay := gMacro.Add("Edit", "x+10 w49", "0")
    lblStepMs := gMacro.Add("Text", "x+5", "ms")
    btnMoveUp := gMacro.Add("Button", "x+15 w30", "⌃")
    btnMoveDown := gMacro.Add("Button", "x+2 w30", "⌄")
    btnRemoveStep := gMacro.Add("Button", "x+2", "Remove")
    btnClearMacro := gMacro.Add("Button", "x+2", "Clear")
    btnInsertWait.OnEvent("Click", (*) => InsertWaitStep(edStepDelay))
    btnMoveUp.OnEvent("Click", (*) => MoveMacroStep(-1))
    btnMoveDown.OnEvent("Click", (*) => MoveMacroStep(1))
    btnClearMacro.OnEvent("Click", (*) => ClearMacroSteps())
    btnRemoveStep.OnEvent("Click", (*) => RemoveMacroStep())
    lblRecordStatus := gMacro.Add("Text", "x" stepsX " y+10 w400 cRed", "Recording... press keys now.")
    lblRecordStatus.Visible := false
    btnRecordMacro.OnEvent("Click", (*) => ToggleMacroRecording(btnRecordMacro, lblRecordStatus))

    GetStepTypeValue(*) {
        return radStepKey.Value ? 1 : (radStepApp.Value ? 2 : 3)
    }

    lblStepKey := gMacro.Add("Text", "x" stepsX " y+15", "Key/Combo:")
    edStepKey := gMacro.Add("Edit", "x+10 w214 ReadOnly Background0xFFFFFF")
    edStepKey.OnEvent("Focus", (*) => StartMacroStepKeyCapture(edStepKey))
    edStepKey.OnEvent("LoseFocus", (*) => StopMacroStepKeyCapture(edStepKey))
    stepRow1X := stepRow1Y := stepRow1H := 0
    lblStepKey.GetPos(&stepRow1X, &stepRow1Y, , &stepRow1H)

    lblStepApp := gMacro.Add("Text", "x" stepsX " y" stepRow1Y, "File path:")
    edStepApp := gMacro.Add("Edit", "x+10 w260")
    btnStepBrowse := gMacro.Add("Button", "x+8 w60", "Browse")
    btnStepBrowse.OnEvent("Click", (*) => BrowseForAppInto(edStepApp))
    edStepArgs := {Value: ""}
    btnStepArgs := gMacro.Add("Button", "x+5 w60", "Args...")
    btnStepArgs.OnEvent("Click", (*) => EditArgsValue(edStepArgs))

    lblStepMultimedia := gMacro.Add("Text", "x" stepsX " y" stepRow1Y, "Multimedia action:")
    edStepMultimedia := gMacro.Add("DropDownList", "x+10 w214 Choose1", MultimediaNames())

    btnAddStep := gMacro.Add("Button", "x" stepsX " y" (stepRow1Y + stepRow1H + 10), "Add Step")
    stepExtraRowShift := 0
    stepAreaExpanded := false
    btnAddStep.OnEvent("Click", (*) => AddMacroStep(GetStepTypeValue(), edStepKey, edStepApp, edStepArgs, edStepDelay, edStepMultimedia))

    ToggleStepTypeControls(*) {
        v := GetStepTypeValue()
        isKey := v = 1
        isApp := v = 2
        isMultimedia := v = 3
        lblStepKey.Visible := isKey
        edStepKey.Visible := isKey
        lblStepApp.Visible := isApp
        edStepApp.Visible := isApp
        btnStepBrowse.Visible := isApp
        btnStepArgs.Visible := isApp
        lblStepMultimedia.Visible := isMultimedia
        edStepMultimedia.Visible := isMultimedia
        if isApp && !stepAreaExpanded {
            ReflowStepAreaForType(stepExtraRowShift)
            stepAreaExpanded := true
        } else if !isApp && stepAreaExpanded {
            ReflowStepAreaForType(-stepExtraRowShift)
            stepAreaExpanded := false
        }
    }
    ReflowStepAreaForType(deltaY) {
        if deltaY = 0
            return
        for ctrl in [btnAddStep, btnDone, btnCancelM] {
            ctrl.GetPos(&cx, &cy)
            ctrl.Move(, cy + deltaY)
        }
        gMacro.GetPos(&gx, &gy, &gw, &gh)
        gMacro.Move(gx, gy, gw, gh + deltaY)
        DllCall("RedrawWindow", "ptr", gMacro.Hwnd, "ptr", 0, "ptr", 0, "uint", 0x0001 | 0x0004 | 0x0080 | 0x0100)
    }
    radStepKey.OnEvent("Click", ToggleStepTypeControls)
    radStepApp.OnEvent("Click", ToggleStepTypeControls)
    radStepMultimedia.OnEvent("Click", ToggleStepTypeControls)

    btnDone := gMacro.Add("Button", "x" stepsX " y+20 w100", "Done")
    btnDone.OnEvent("Click", (*) => FinishMacroEditor(onSave))
    btnCancelM := gMacro.Add("Button", "x+10 w100", "Cancel")
    btnCancelM.OnEvent("Click", (*) => (StopRecordingIfActive(), CloseMacroEditor()))
    gMacro.OnEvent("Close", (*) => (StopRecordingIfActive(), CloseMacroEditor()))
    macroStepControls := [btnAddStep, btnMoveUp, btnMoveDown, btnClearMacro, btnRemoveStep,
        radStepKey, radStepApp, radStepMultimedia, edStepKey, edStepApp, btnStepBrowse, btnStepArgs, edStepMultimedia,
        btnInsertWait, edStepDelay, btnDone, btnCancelM,
        lbSavedMacros, btnSaveMacro, btnUpdateSavedMacro, btnDeleteSavedMacro]
    ToggleStepTypeControls()
    gMacro.Show()
}

RefreshMacroStepsList() {
    global macroEditSteps, lvMacroSteps
    topIndex := LV_GetTopIndex(lvMacroSteps)
    lvMacroSteps.Delete()
    for i, s in macroEditSteps {
        typeLabel := s.type = "key" ? "Key" : (s.type = "keydown" ? "Key Down" : (s.type = "keyup" ? "Key Up" : (s.type = "app" ? "App" : "Delay")))
        if s.type = "key" || s.type = "keydown" || s.type = "keyup"
            targetLabel := HumanizeSendKey(s.target)
        else if s.type = "app"
            targetLabel := s.target (s.args != "" ? " " s.args : "")
        else
            targetLabel := "-"
        lvMacroSteps.Add(, i, typeLabel, targetLabel, s.delayAfterMs)
    }
    LV_RestoreTopIndex(lvMacroSteps, topIndex)
}

OnMacroStepDoubleClick(ctrl, row) {
    global macroEditSteps, macroRecording
    if macroRecording
        return
    if !row || row > macroEditSteps.Length
        return
    OpenEditDelayDialog(row)
}

OpenEditDelayDialog(row) {
    global macroEditSteps, lvMacroSteps, gMacro
    step := macroEditSteps[row]
    gDelay := Gui("+Owner" gMacro.Hwnd, "Edit Delay")
    gDelay.SetFont("s10", "Segoe UI")
    gDelay.Add("Text", "xm y10", "Delay after this step (ms):")
    edDelayVal := gDelay.Add("Edit", "x+10 yp-3 w100 Number", String(step.delayAfterMs))
    btnOk := gDelay.Add("Button", "xm y+15 w90 Default", "OK")
    btnCancel := gDelay.Add("Button", "x+10 w90", "Cancel")
    btnOk.OnEvent("Click", (*) => CommitDelayEdit(row, edDelayVal, gDelay))
    btnCancel.OnEvent("Click", (*) => gDelay.Destroy())
    gDelay.OnEvent("Close", (*) => gDelay.Destroy())
    gDelay.Show("AutoSize")
    edDelayVal.Focus()
}

CommitDelayEdit(row, edDelayVal, gDelay) {
    global macroEditSteps, lvMacroSteps
    if edDelayVal.Value = "" || !IsInteger(edDelayVal.Value) || Integer(edDelayVal.Value) < 0 {
        MsgBox("Enter a whole number of milliseconds (0 or more).", "Invalid delay", "Icon!")
        return
    }
    macroEditSteps[row].delayAfterMs := Integer(edDelayVal.Value)
    RefreshMacroStepsList()
    lvMacroSteps.Modify(row, "Select Focus Vis")
    gDelay.Destroy()
}

ToggleMacroRecording(btn, statusText) {
    global macroRecording
    if macroRecording
        StopMacroRecording(btn, statusText)
    else
        StartMacroRecordingFlow(btn, statusText)
}

StartMacroRecordingFlow(btn, statusText) {
    global macroRecording, recordLastEventTick, recordHeldKeys, recordHook, macroStepControls
    macroRecording := true
    recordLastEventTick := 0
    recordHeldKeys := Map()
    for ctrl in macroStepControls
        ctrl.Enabled := false
    btn.Text := "Stop Recording"
    statusText.Visible := true
    recordHook := NewCaptureInputHook(RecordMacroKeyDown, RecordMacroKeyUp, true)
}

StopMacroRecording(btn, statusText) {
    StopRecordingIfActive()
    btn.Text := "Record Macro"
    statusText.Visible := false
}

StopRecordingIfActive() {
    global macroRecording, recordHook, macroStepControls
    if !macroRecording
        return
    macroRecording := false
    if IsObject(recordHook) {
        try recordHook.Stop()
        recordHook := ""
    }
    for ctrl in macroStepControls
        ctrl.Enabled := true
}

CommitRecordedStep(stepType, target) {
    global macroEditSteps, recordLastEventTick, lvMacroSteps
    now := A_TickCount
    if recordLastEventTick != 0 && macroEditSteps.Length > 0
        macroEditSteps[macroEditSteps.Length].delayAfterMs := now - recordLastEventTick
    macroEditSteps.Push({type: stepType, target: target, args: "", delayAfterMs: 0})
    recordLastEventTick := now
    RefreshMacroStepsList()
    lvMacroSteps.Modify(macroEditSteps.Length, "Select Focus Vis")
}

RecordMacroKeyDown(ihObj, VK, SC) {
    global recordHeldKeys
    BlockWinKeyStartMenu(VK)
    keyName := KeyNameFor(VK, SC)
    if recordHeldKeys.Has(keyName)
        return
    recordHeldKeys[keyName] := true
    CommitRecordedStep("keydown", FormatSendKeyRaw(VK, SC, keyName))
}

RecordMacroKeyUp(ihObj, VK, SC) {
    global recordHeldKeys
    keyName := KeyNameFor(VK, SC)
    if recordHeldKeys.Has(keyName)
        recordHeldKeys.Delete(keyName)
    CommitRecordedStep("keyup", FormatSendKeyRaw(VK, SC, keyName))
}

AddMacroStep(v, edStepKey, edStepApp, edStepArgs, edStepDelay, edStepMultimedia) {
    global macroEditSteps, macroStepCapturedTarget, lvMacroSteps
    delayVal := IsInteger(edStepDelay.Value) ? Integer(edStepDelay.Value) : 0
    if delayVal < 0
        delayVal := 0
    if v = 1 {
        if edStepKey.Value = "" {
            MsgBox("Capture a key/combo for this step first.", "Missing target", "Icon!")
            return
        }
        newStep := {type: "key", target: macroStepCapturedTarget, args: "", delayAfterMs: delayVal}
    } else if v = 3 {
        newStep := {type: "key", target: MultimediaSendForIndex(edStepMultimedia.Value), args: "", delayAfterMs: delayVal}
    } else {
        if edStepApp.Value = "" {
            MsgBox("Enter an app/file path for this step first.", "Missing target", "Icon!")
            return
        }
        newStep := {type: "app", target: edStepApp.Value, args: edStepArgs.Value, delayAfterMs: delayVal}
    }
    row := lvMacroSteps.GetNext()
    if row {
        macroEditSteps.InsertAt(row + 1, newStep)
        insertedAt := row + 1
    } else {
        macroEditSteps.Push(newStep)
        insertedAt := macroEditSteps.Length
    }
    RefreshMacroStepsList()
    lvMacroSteps.Modify(insertedAt, "Select Focus Vis")
    macroStepCapturedTarget := ""
    edStepKey.Value := ""
    edStepApp.Value := ""
    edStepArgs.Value := ""
    edStepDelay.Value := "0"
}

InsertWaitStep(edStepDelay) {
    global macroEditSteps, lvMacroSteps
    delayVal := IsInteger(edStepDelay.Value) ? Integer(edStepDelay.Value) : 0
    if delayVal <= 0 {
        MsgBox("Enter a delay greater than 0ms first.", "Missing delay", "Icon!")
        return
    }
    newStep := {type: "wait", target: "", args: "", delayAfterMs: delayVal}
    row := lvMacroSteps.GetNext()
    if row {
        macroEditSteps.InsertAt(row + 1, newStep)
        insertedAt := row + 1
    } else {
        macroEditSteps.Push(newStep)
        insertedAt := macroEditSteps.Length
    }
    RefreshMacroStepsList()
    lvMacroSteps.Modify(insertedAt, "Select Focus Vis")
}

ClearMacroSteps() {
    global macroEditSteps, lvMacroSteps
    if macroEditSteps.Length = 0
        return
    result := MsgBox("Clear all " macroEditSteps.Length " step(s) from this macro?", "Clear macro", "YesNo Icon!")
    if result != "Yes"
        return
    macroEditSteps := []
    RefreshMacroStepsList()
}

RemoveMacroStep() {
    global macroEditSteps, lvMacroSteps
    rows := []
    row := 0
    loop {
        row := lvMacroSteps.GetNext(row)
        if !row
            break
        rows.Push(row)
    }
    if rows.Length = 0 {
        MsgBox("Select a step first.", "Nothing selected", "Icon!")
        return
    }
    anchorRow := rows[1]
    loop rows.Length
        macroEditSteps.RemoveAt(rows[rows.Length - A_Index + 1])
    RefreshMacroStepsList()
    if macroEditSteps.Length > 0 {
        newRow := Min(anchorRow, macroEditSteps.Length)
        lvMacroSteps.Modify(newRow, "Select Focus Vis")
    }
}

MoveMacroStep(dir) {
    global macroEditSteps, lvMacroSteps
    rows := []
    row := 0
    loop {
        row := lvMacroSteps.GetNext(row)
        if !row
            break
        rows.Push(row)
    }
    if rows.Length = 0 {
        MsgBox("Select a step first.", "Nothing selected", "Icon!")
        return
    }
    n := macroEditSteps.Length
    selArr := []
    loop n
        selArr.Push(false)
    for r in rows
        selArr[r] := true
    moved := false
    if dir < 0 {
        loop n - 1 {
            i := A_Index + 1
            if selArr[i] && !selArr[i - 1] {
                tmp := macroEditSteps[i]
                macroEditSteps[i] := macroEditSteps[i - 1]
                macroEditSteps[i - 1] := tmp
                tmpSel := selArr[i]
                selArr[i] := selArr[i - 1]
                selArr[i - 1] := tmpSel
                moved := true
            }
        }
    } else {
        loop n - 1 {
            i := n - A_Index
            if selArr[i] && !selArr[i + 1] {
                tmp := macroEditSteps[i]
                macroEditSteps[i] := macroEditSteps[i + 1]
                macroEditSteps[i + 1] := tmp
                tmpSel := selArr[i]
                selArr[i] := selArr[i + 1]
                selArr[i + 1] := tmpSel
                moved := true
            }
        }
    }
    if !moved
        return
    RefreshMacroStepsList()
    first := true
    for i, isSel in selArr {
        if isSel {
            lvMacroSteps.Modify(i, first ? "Select Focus" : "Select")
            first := false
        }
    }
}

FinishMacroEditor(onSave) {
    global macroEditSteps, gMacro
    if macroEditSteps.Length = 0 {
        result := MsgBox("This macro has no steps yet. Save an empty macro anyway?", "Empty macro", "YesNo Icon!")
        if result != "Yes"
            return
    }
    stepsCopy := []
    for s in macroEditSteps
        stepsCopy.Push({type: s.type, target: s.target, args: s.args, delayAfterMs: s.delayAfterMs})
    onSave(stepsCopy)
    CloseMacroEditor()
}

CloseMacroEditor() {
    global gMacro, lvMacroSteps, lbSavedMacros
    global macroLvColW1, macroLvColW2, macroLvColW3, macroLvColW4
    macroLvColW1 := LV_GetColumnWidth(lvMacroSteps, 1)
    macroLvColW2 := LV_GetColumnWidth(lvMacroSteps, 2)
    macroLvColW3 := LV_GetColumnWidth(lvMacroSteps, 3)
    macroLvColW4 := LV_GetColumnWidth(lvMacroSteps, 4)
    SaveMacroColumnWidths()
    gMacro.Destroy()
    gMacro := ""
    lvMacroSteps := ""
    lbSavedMacros := ""
    SaveMacros()
    UpdateMacroSelectDdl()
}

RefreshSavedMacrosList(selectName := "") {
    global savedMacroOrder, lbSavedMacros
    if !IsObject(lbSavedMacros)
        return
    lbSavedMacros.Delete()
    if savedMacroOrder.Length
        lbSavedMacros.Add(savedMacroOrder)
    if selectName != "" {
        for i, name in savedMacroOrder {
            if name = selectName {
                lbSavedMacros.Choose(i)
                break
            }
        }
    }
}

OnSavedMacroSelectionChange() {
    global lbSavedMacros, savedMacros, macroEditSteps
    name := lbSavedMacros.Text
    if name = "" || !savedMacros.Has(name)
        return
    macroEditSteps := CloneMacroSteps(savedMacros[name])
    RefreshMacroStepsList()
}

OpenSaveMacroNameDialog() {
    global macroEditSteps, gMacro
    if macroEditSteps.Length = 0 {
        MsgBox("Add at least one step before saving a macro.", "Nothing to save", "Icon!")
        return
    }
    gSaveMacroName := Gui("+Owner" gMacro.Hwnd, "Save Macro As")
    gSaveMacroName.SetFont("s10", "Segoe UI")
    gSaveMacroName.Add("Text", "xm y10", "Macro name:")
    edSaveMacroName := gSaveMacroName.Add("Edit", "x+10 yp-3 w200")
    btnOkSaveMacro := gSaveMacroName.Add("Button", "xm y+15 w90 Default", "OK")
    btnCancelSaveMacro := gSaveMacroName.Add("Button", "x+10 w90", "Cancel")
    btnOkSaveMacro.OnEvent("Click", (*) => CommitSaveMacroAs(edSaveMacroName, gSaveMacroName))
    btnCancelSaveMacro.OnEvent("Click", (*) => gSaveMacroName.Destroy())
    gSaveMacroName.OnEvent("Close", (*) => gSaveMacroName.Destroy())
    gSaveMacroName.Show("AutoSize")
    edSaveMacroName.Focus()
}

CommitSaveMacroAs(edSaveMacroName, gSaveMacroName) {
    global savedMacros, savedMacroOrder, macroEditSteps
    name := Trim(edSaveMacroName.Value)
    if name = "" {
        MsgBox("Enter a name for the macro.", "Name required", "Icon!")
        return
    }
    if savedMacros.Has(name) {
        if MsgBox("A saved macro named '" name "' already exists. Overwrite it?", "Overwrite?", "YesNo Icon!") != "Yes"
            return
    } else
        savedMacroOrder.Push(name)
    savedMacros[name] := CloneMacroSteps(macroEditSteps)
    RefreshSavedMacrosList(name)
    SaveMacros()
    gSaveMacroName.Destroy()
}

UpdateSelectedSavedMacro() {
    global lbSavedMacros, savedMacros, macroEditSteps
    name := lbSavedMacros.Text
    if name = "" {
        MsgBox("Select a saved macro to update first.", "Nothing selected", "Icon!")
        return
    }
    if macroEditSteps.Length = 0 {
        MsgBox("Add at least one step before updating a saved macro.", "Nothing to save", "Icon!")
        return
    }
    savedMacros[name] := CloneMacroSteps(macroEditSteps)
    RefreshSavedMacrosList(name)
    SaveMacros()
}

DeleteSelectedSavedMacro() {
    global lbSavedMacros, savedMacros, savedMacroOrder, mappings, mapOrder, currentMacroSteps, editingId
    name := lbSavedMacros.Text
    if name = "" {
        MsgBox("Select a saved macro to delete first.", "Nothing selected", "Icon!")
        return
    }
    linkedKeys := []
    for key in mapOrder {
        m := mappings[key]
        if MapActionType(m) = "macro" && MapMacroName(m) = name
            linkedKeys.Push(key)
    }
    prompt := "Delete the saved macro '" name "'? This cannot be undone."
    if linkedKeys.Length > 0
        prompt := "The saved macro '" name "' is currently used by " linkedKeys.Length " button mapping" (linkedKeys.Length = 1 ? "" : "s") ".`n`nDeleting it will unlink those mappings and freeze their CURRENT steps in place, so they keep working exactly as they do now - they just won't follow any future edits to this macro anymore.`n`nDelete anyway?"
    if MsgBox(prompt, "Delete saved macro", "YesNo Icon!") != "Yes"
        return
    for key in linkedKeys {
        m := mappings[key]
        m.macroSteps := CloneMacroSteps(ResolveMacroSteps(m))
        m.macroName := ""
    }
    savedMacros.Delete(name)
    deletedIdx := 0
    for i, n in savedMacroOrder {
        if n = name {
            deletedIdx := i
            savedMacroOrder.RemoveAt(i)
            break
        }
    }
    replacementName := ""
    if savedMacroOrder.Length > 0 {
        newIdx := Min(deletedIdx > 0 ? deletedIdx : 1, savedMacroOrder.Length)
        replacementName := savedMacroOrder[newIdx]
    }
    RefreshSavedMacrosList(replacementName)
    if editingId != "" && mappings.Has(editingId) && HasVal(linkedKeys, editingId)
        currentMacroSteps := CloneMacroSteps(mappings[editingId].macroSteps)
    SaveMacros()
    for key in linkedKeys {
        if mappings.Has(key)
            SaveProfileMapping(MapProfileKey(mappings[key]), key)
    }
}

StartMacroStepKeyCapture(edCtrl) {
    global macroStepCaptureHook, macroStepComboFired, macroStepHeldMods, macroStepCapturedTarget
    if IsObject(macroStepCaptureHook) {
        try macroStepCaptureHook.Stop()
    }
    macroStepComboFired := false
    macroStepHeldMods := Map()
    macroStepCapturedTarget := ""
    edCtrl.Value := ""
    macroStepCaptureHook := NewCaptureInputHook(
        (ihObj, VK, SC) => MacroStepKeyDown(ihObj, VK, SC, edCtrl),
        (ihObj, VK, SC) => MacroStepKeyUp(ihObj, VK, SC, edCtrl),
        true)
}

StopMacroStepKeyCapture(edCtrl) {
    global macroStepCaptureHook, macroStepCapturedTarget
    if IsObject(macroStepCaptureHook) {
        try macroStepCaptureHook.Stop()
        macroStepCaptureHook := ""
    }
    edCtrl.Value := HumanizeSendKey(macroStepCapturedTarget)
}

MacroStepKeyDown(ihObj, VK, SC, edCtrl) {
    global macroStepHeldMods, macroStepComboFired, macroStepCapturedTarget
    if IsModifierVK(VK) {
        BlockWinKeyStartMenu(VK)
        macroStepHeldMods[VK] := true
        return
    }
    keyName := KeyNameFor(VK, SC)
    macroStepCapturedTarget := BuildModStrFromHeld(macroStepHeldMods) FormatSendKeyRaw(VK, SC, keyName)
    edCtrl.Value := HumanizeSendKey(macroStepCapturedTarget)
    macroStepComboFired := true
}

MacroStepKeyUp(ihObj, VK, SC, edCtrl) {
    global macroStepHeldMods, macroStepComboFired, macroStepCapturedTarget
    if !IsModifierVK(VK)
        return
    if macroStepHeldMods.Has(VK)
        macroStepHeldMods.Delete(VK)
    allModsUp := (macroStepHeldMods.Count = 0)
    if macroStepComboFired {
        if allModsUp
            macroStepComboFired := false
        return
    }
    if !allModsUp
        return
    keyName := KeyNameFor(VK, SC)
    macroStepCapturedTarget := FormatSendKeyRaw(VK, SC, keyName)
    edCtrl.Value := HumanizeSendKey(macroStepCapturedTarget)
}

MacroStepsEscapeField(s) {
    s := StrReplace(s, "\", "\\")
    s := StrReplace(s, "|", "\|")
    s := StrReplace(s, "~", "\~")
    s := StrReplace(s, "`r", "\r")
    s := StrReplace(s, "`n", "\n")
    return s
}

MacroStepsUnescapeField(s) {
    out := ""
    i := 1
    len := StrLen(s)
    while i <= len {
        ch := SubStr(s, i, 1)
        if ch = "\" && i < len {
            nextCh := SubStr(s, i + 1, 1)
            if nextCh = "r" {
                out .= "`r"
                i += 2
                continue
            } else if nextCh = "n" {
                out .= "`n"
                i += 2
                continue
            } else if nextCh = "|" {
                out .= "|"
                i += 2
                continue
            } else if nextCh = "~" {
                out .= "~"
                i += 2
                continue
            } else if nextCh = "\" {
                out .= "\"
                i += 2
                continue
            }
        }
        out .= ch
        i += 1
    }
    return out
}

MacroStepsEncode(steps) {
    out := ""
    for i, s in steps {
        if i > 1
            out .= "~"
        out .= s.type "|" String(s.delayAfterMs) "|" MacroStepsEscapeField(s.target) "|" MacroStepsEscapeField(s.HasOwnProp("args") ? s.args : "")
    }
    return out
}

MacroStepsDecode(str) {
    steps := []
    if str = ""
        return steps
    if InStr(str, Chr(1)) || InStr(str, Chr(2)) {
        for chunk in StrSplit(str, Chr(2)) {
            parts := StrSplit(chunk, Chr(1))
            type := parts.Length >= 1 ? parts[1] : "wait"
            delayMs := (parts.Length >= 2 && IsInteger(parts[2])) ? Integer(parts[2]) : 0
            target := parts.Length >= 3 ? parts[3] : ""
            args := parts.Length >= 4 ? parts[4] : ""
            steps.Push({type: type, target: target, args: args, delayAfterMs: delayMs})
        }
        return steps
    }
    for chunk in StrSplit(str, "~") {
        parts := StrSplit(chunk, "|")
        type := parts.Length >= 1 ? parts[1] : "wait"
        delayMs := (parts.Length >= 2 && IsInteger(parts[2])) ? Integer(parts[2]) : 0
        target := parts.Length >= 3 ? MacroStepsUnescapeField(parts[3]) : ""
        args := parts.Length >= 4 ? MacroStepsUnescapeField(parts[4]) : ""
        steps.Push({type: type, target: target, args: args, delayAfterMs: delayMs})
    }
    return steps
}

FindSavedMacroNameForSteps(steps) {
    global savedMacros, savedMacroOrder
    if !steps.Length
        return ""
    encoded := MacroStepsEncode(steps)
    for name in savedMacroOrder {
        if savedMacros.Has(name) && MacroStepsEncode(savedMacros[name]) = encoded
            return name
    }
    return ""
}

CloneMacroSteps(steps) {
    out := []
    for s in steps
        out.Push({type: s.type, target: s.target, args: s.args, delayAfterMs: s.delayAfterMs})
    return out
}
