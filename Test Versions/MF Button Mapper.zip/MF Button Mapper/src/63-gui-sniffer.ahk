
CancelPendingRawMapCapture() {
    global rawMapCaptureArmed, rawMapCaptureAwaitingRelease, rawMapCaptureCallback, rawMapCaptureStatusCallback
    rawMapCaptureArmed := false
    rawMapCaptureAwaitingRelease := false
    rawMapCaptureCallback := ""
    rawMapCaptureStatusCallback := ""
}

FinalizeRawMapCapture(token) {
    global rawMapCaptureAwaitingRelease, rawMapCaptureReleaseWindowToken
    if !rawMapCaptureAwaitingRelease || token != rawMapCaptureReleaseWindowToken
        return
    rawMapCaptureAwaitingRelease := false
    CompleteRawMapCaptureConfig("")
}

CompleteRawMapCaptureConfig(upBytesHex) {
    global rawMapCaptureCallback, rawMapCaptureStatusCallback
    if IsObject(rawMapCaptureCallback)
        rawMapCaptureCallback.Call(upBytesHex)
    rawMapCaptureCallback := ""
    rawMapCaptureStatusCallback := ""
}

OpenRawSniffer(*) {
    global gRaw, lstRawLog, gRawStartBtn
    if IsObject(gRaw) {
        gRaw.Show()
        return
    }
    gRaw := Gui("", "Raw HID Sniffer")
    gRaw.OnEvent("Close", StopSniffingOnClose)
    gRaw.SetFont("s9", "Consolas")
    gRaw.Add("Text", "w600", "Click Start, then press the remote button. Raw reports from ALL connected HID collections (keyboard, consumer control, vendor-defined, etc.) are logged below.")
    btnStart := gRaw.Add("Button", "w130", "Start Sniffing")
    btnStart.OnEvent("Click", (*) => ToggleSniffing(btnStart))
    gRawStartBtn := btnStart
    btnClear := gRaw.Add("Button", "x+10 w100", "Clear Log")
    btnClear.OnEvent("Click", ClearRawLog)
    btnMapSelected := gRaw.Add("Button", "x+10 w170", "Map Selected to Key...")
    btnMapSelected.OnEvent("Click", MapSelectedRawLine)
    lstRawLog := gRaw.Add("ListBox", "x10 y+10 w600 h350")
    gRaw.Show()
}

StopSniffingOnClose(*) {
    global rawSniffing, gRaw, gRawStartBtn
    rawSniffing := false
    if IsObject(gRawStartBtn)
        gRawStartBtn.Text := "Start Sniffing"
    ClearRawLog()
    gRaw.Hide()
}

ClearRawLog(*) {
    global g_rawLogCount, g_rawLogData
    lstRawLog.Delete()
    g_rawLogCount := 0
    g_rawLogData := []
}

ToggleSniffing(btnStart) {
    global rawSniffing, g_rawLogCount, g_rawLogData
    if !rawSniffing {
        okCount := RegisterAllRawInputDevices()
        if !okCount {
            MsgBox("Could not register any raw input devices.`nDeviceCount: " g_lastDeviceCount " EntryCount: " g_lastEntryCount, "Error", "Icon!")
            return
        }
        if IsObject(lstRawLog) {
            for line in g_regLog {
                lstRawLog.Add([line])
                g_rawLogData.Push("")
                g_rawLogCount++
            }
        }
        rawSniffing := true
        btnStart.Text := "Stop Sniffing"
    } else {
        rawSniffing := false
        btnStart.Text := "Start Sniffing"
    }
}

GetRawDeviceInfo(hDevice) {
    size := 32
    buf := Buffer(size, 0)
    NumPut("UInt", size, buf, 0)
    pcb := size
    r := DllCall("GetRawInputDeviceInfo", "ptr", hDevice, "uint", 0x2000000B, "ptr", buf, "uint*", &pcb, "int")
    if r = -1
        return false
    dwType := NumGet(buf, 4, "UInt")
    if dwType = 0
        return {usagePage: 0x01, usage: 0x02}
    if dwType = 1
        return {usagePage: 0x01, usage: 0x06}
    return {usagePage: NumGet(buf, 20, "UShort"), usage: NumGet(buf, 22, "UShort")}
}

LogRawSniffEvent(line, rowData) {
    global rawSniffing, lstRawLog, g_rawLogCount, g_rawLogData
    if !(rawSniffing && IsObject(lstRawLog))
        return
    lstRawLog.Add([NowStamp() " " line])
    g_rawLogData.Push(rowData)
    g_rawLogCount++
    lstRawLog.Choose(g_rawLogCount)
}

MapSelectedRawLine(*) {
    idx := lstRawLog.Value
    if !idx || idx > g_rawLogData.Length {
        MsgBox("Select a raw [HID] line from the log first.", "Nothing selected", "Icon!")
        return
    }
    data := g_rawLogData[idx]
    if !IsObject(data) {
        MsgBox("That line isn't a mappable raw HID event. Select an [HID] line (not a status or keyboard line).", "Can't map this", "Icon!")
        return
    }
    if data.HasOwnProp("stdMouse") && data.stdMouse {
        MsgBox("That's a standard mouse button/wheel event. Map those with `"Capture`" in the main window's Learn section instead; the sniffer's Map option is for vendor HID buttons.", "Use Capture", "Icon!")
        return
    }
    OpenRawMapDialog(data.page, data.bytesHex)
}

OpenRawMapDialog(page, bytesHex) {
    global rawMapTargetString, rawMacroSteps, ActionTypeDdlItems
    rawMapTargetString := ""
    rawMacroSteps := []
    rawMapUpBytesHex := ""
    gm := Gui("+Owner" gRaw.Hwnd, "Map Raw HID Event")
    gm.SetFont("s10", "Segoe UI")
    gm.Add("Text", "w420", Format("Event: Page:0x{:X} Bytes:{}", page, bytesHex))
    gm.Add("Text", "xm y+15", "Description:")
    edDesc := gm.Add("Edit", "x+10 w180")
    gm.Add("Text", "x+15", "Action:")
    rawActionItems := []
    loop ACTION_MACRO
        rawActionItems.Push(ActionTypeDdlItems[A_Index])
    ddlRawAction := gm.Add("DropDownList", "x+10 w150 Choose1", rawActionItems)

    lblRawSends := gm.Add("Text", "xm y+15", "Sends:")
    edTarget := gm.Add("Edit", "x+10 w120 ReadOnly Background0xFFFFFF")
    lblRawSends.GetPos(&fieldsX, &fieldsY)

    rawTargetCaptureHook := ""
    rawTargetHeldMods := Map()
    rawTargetComboFired := false

    StartRawMapTargetCapture(*) {
        global captureSuspended
        if IsObject(rawTargetCaptureHook) {
            try rawTargetCaptureHook.Stop()
        }
        ResumeButtonHotkeysIfNeeded()
        IncrementCaptureSuspend()
        captureSuspended := true
        rawTargetComboFired := false
        rawTargetHeldMods := Map()
        edTarget.Value := ""
        rawTargetCaptureHook := NewCaptureInputHook(OnRawMapTargetKeyDown, OnRawMapTargetKeyUp, true)
    }

    StopRawMapTargetCapture(*) {
        if IsObject(rawTargetCaptureHook) {
            try rawTargetCaptureHook.Stop()
            rawTargetCaptureHook := ""
        }
        ResumeButtonHotkeysIfNeeded()
        edTarget.Value := HumanizeSendKey(rawMapTargetString)
    }

    FinalizeRawTarget(modStr, keyName, VK := 0, SC := 0) {
        global rawMapTargetString
        rawMapTargetString := modStr FormatSendKeyRaw(VK, SC, keyName)
        edTarget.Value := HumanizeSendKey(rawMapTargetString)
    }

    OnRawMapTargetKeyDown(ihObj, VK, SC) {
        if IsModifierVK(VK) {
            BlockWinKeyStartMenu(VK)
            rawTargetHeldMods[VK] := true
            return
        }
        keyName := KeyNameFor(VK, SC)
        FinalizeRawTarget(BuildModStrFromHeld(rawTargetHeldMods), keyName, VK, SC)
        rawTargetComboFired := true
    }

    OnRawMapTargetKeyUp(ihObj, VK, SC) {
        if !IsModifierVK(VK)
            return
        if rawTargetHeldMods.Has(VK)
            rawTargetHeldMods.Delete(VK)
        allModsUp := (rawTargetHeldMods.Count = 0)
        if rawTargetComboFired {
            if allModsUp
                rawTargetComboFired := false
            return
        }
        if !allModsUp
            return
        keyName := KeyNameFor(VK, SC)
        FinalizeRawTarget("", keyName, VK, SC)
    }

    edTarget.OnEvent("Focus", StartRawMapTargetCapture)
    edTarget.OnEvent("LoseFocus", StopRawMapTargetCapture)

    lblRawAppPath := gm.Add("Text", "xm y" fieldsY, "File path:")
    edRawAppPath := gm.Add("Edit", "x+10 w260")
    btnRawBrowse := gm.Add("Button", "x+8 w60", "Browse")
    btnRawBrowse.OnEvent("Click", (*) => BrowseForAppInto(edRawAppPath))
    edRawAppArgs := {Value: ""}
    btnRawArgs := gm.Add("Button", "x+5 w60", "Args...")
    btnRawArgs.OnEvent("Click", (*) => EditArgsValue(edRawAppArgs))
    edRawAppPath.GetPos(&argsX, &argsY, &argsW, &argsH)
    dynRegionBottom := argsY + argsH

    lblRawMacroSelect := gm.Add("Text", "xm y" fieldsY, "Macro:")
    ddlRawMacroSelect := gm.Add("DropDownList", "x+10 w180 Choose1", ["(Custom / unsaved)"])
    ddlRawMacroSelect.OnEvent("Change", OnRawMacroSelectChange)
    btnRawEditMacro := gm.Add("Button", "x+5 w90", "Macros")
    btnRawEditMacro.OnEvent("Click", (*) => OpenMacroEditor(rawMacroSteps, SaveRawMacroStepsFromDialog))

    lblRawMultimedia := gm.Add("Text", "xm y" fieldsY, "Multimedia action:")
    ddlRawMultimedia := gm.Add("DropDownList", "x+10 w180 Choose1", MultimediaNames())

    lblRawMouse := gm.Add("Text", "xm y" fieldsY, "Mouse action:")
    ddlRawMouse := gm.Add("DropDownList", "x+10 w180 Choose1", MouseNames(false))

    txtRawHoldStatus := gm.Add("Text", "xm y" (dynRegionBottom + 15) " w420", "Single-shot only (no hold detected) - Trigger/Run mode below are ignored until hold is detected.")
    btnRawDetectHold := gm.Add("Button", "xm y+6 w230", "Detect Hold (press button again)")

    lblRawRunMode := gm.Add("Text", "xm y+12", "Run mode:")
    ddlRawRunMode := gm.Add("DropDownList", "x+10 w150 Choose1 +0x10", RunModeDdlItems)
    chkRawDelay := gm.Add("Checkbox", "x+15", "Repeat delay")
    chkRawDelay.OnEvent("Click", (*) => (edRawDelayMs.Enabled := chkRawDelay.Value))
    chkRawDelay.GetPos(&rawRepeatRowX, &rawDelayRowY, &rawDelayRowW)
    lblRawDelayFixed := gm.Add("Text", "x" rawRepeatRowX " y" rawDelayRowY " Hidden", "Repeat delay")
    edRawDelayMs := gm.Add("Edit", "x" (rawRepeatRowX + rawDelayRowW + 5) " y" rawDelayRowY " w60 Disabled", "200")
    lblRawDelayMsUnit := gm.Add("Text", "x+3", "ms")
    lblRawDelayMsUnit.GetPos(&rdmuX, &rdmuY, &rdmuW, &rdmuH)
    rawDelayTopRowY := rawDelayRowY
    rawRepeatBottomRowY := rdmuY + rdmuH + 8
    lblRawRepeatMs := gm.Add("Text", "x" rawRepeatRowX " y" rawRepeatBottomRowY, "Repeat interval")
    edRawRepeatMs := gm.Add("Edit", "x+5 w60", "100")
    lblRawRepeatMsUnit := gm.Add("Text", "x+3", "ms")
    edRawRepeatMs.GetPos(&rawRepeatMsX)
    rawDelayNeededX := rawRepeatRowX + rawDelayRowW + 5
    rawAlignedInputX := Max(rawDelayNeededX, rawRepeatMsX)
    edRawDelayMs.Move(rawAlignedInputX)
    edRawDelayMs.GetPos(&edRawDelayMsX, &edRawDelayMsY, &edRawDelayMsW)
    lblRawDelayMsUnit.Move(edRawDelayMsX + edRawDelayMsW + 3)
    edRawRepeatMs.Move(rawAlignedInputX)
    edRawRepeatMs.GetPos(&edRawRepeatMsX, &edRawRepeatMsY, &edRawRepeatMsW)
    lblRawRepeatMsUnit.Move(edRawRepeatMsX + edRawRepeatMsW + 3)
    lblRawTrigger := gm.Add("Text", "xm y" (rdmuY + rdmuH + 18), "Trigger:")
    ddlRawTrigger := gm.Add("DropDownList", "x+10 w184 Choose1 +0x10", PressTypeDdlItems)

    RegisterHoldDdl(ddlRawTrigger, PressTypeDdlItems, HoldOnlyTriggerIdx, () => rawMapUpBytesHex = "")
    RegisterHoldDdl(ddlRawRunMode, RunModeDdlItems, HoldOnlyRunModeIdx, () => rawMapUpBytesHex = "")
    AddHoldDdlRule(ddlRawRunMode, HoldUnsupportedActionRunModeIdx, () => ddlRawAction.Value = ACTION_MULTIMEDIA || ddlRawAction.Value = ACTION_MACRO)
    AddHoldDdlRule(ddlRawRunMode, TypematicUnsupportedActionRunModeIdx, () => ddlRawAction.Value = ACTION_MOUSE || ddlRawAction.Value = ACTION_MACRO)
    ddlRawTrigger.OnEvent("Change", (*) => EnforceHoldDdlSelection(ddlRawTrigger, DdlIndexFromPressType("short")))

    ToggleRawRunModeControls(*) {
        isSingle := ddlRawRunMode.Value = RUNMODE_SINGLE
        isRawTypematic := ddlRawRunMode.Value = RUNMODE_TYPEMATIC
        showRepeatMs := (ddlRawRunMode.Value = RUNMODE_TYPEMATIC || ddlRawRunMode.Value = RUNMODE_REPEAT || ddlRawRunMode.Value = RUNMODE_TOGGLE_REPEAT)
        rawSwapRows := (ddlRawRunMode.Value = RUNMODE_REPEAT || ddlRawRunMode.Value = RUNMODE_TOGGLE_REPEAT)
        rawRepeatRowY := rawSwapRows ? rawDelayTopRowY : rawRepeatBottomRowY
        rawDelayRowYNow := rawSwapRows ? rawRepeatBottomRowY : rawDelayTopRowY
        lblRawRepeatMs.Move(, rawRepeatRowY)
        edRawRepeatMs.Move(, rawRepeatRowY)
        lblRawRepeatMsUnit.Move(, rawRepeatRowY)
        chkRawDelay.Move(, rawDelayRowYNow)
        lblRawDelayFixed.Move(, rawDelayRowYNow)
        edRawDelayMs.Move(, rawDelayRowYNow)
        lblRawDelayMsUnit.Move(, rawDelayRowYNow)
        lblRawRepeatMs.Visible := showRepeatMs
        edRawRepeatMs.Visible := showRepeatMs
        lblRawRepeatMsUnit.Visible := showRepeatMs
        chkRawDelay.Visible := showRepeatMs && !isRawTypematic
        lblRawDelayFixed.Visible := showRepeatMs && isRawTypematic
        edRawDelayMs.Visible := showRepeatMs
        lblRawDelayMsUnit.Visible := showRepeatMs
        if isRawTypematic {
            chkRawDelay.Value := 1
            edRawDelayMs.Enabled := true
        } else {
            edRawDelayMs.Enabled := chkRawDelay.Value ? true : false
        }
        ddlRawTrigger.Visible := isSingle
        if !isSingle
            ddlRawTrigger.Choose(DdlIndexFromPressType("short"))
    }
    ApplyRawRunModeDelayDefault(*) {
        if (ddlRawRunMode.Value = RUNMODE_TYPEMATIC) {
            chkRawDelay.Value := 1
            edRawDelayMs.Value := "500"
            edRawDelayMs.Enabled := true
        } else if (ddlRawRunMode.Value = RUNMODE_REPEAT || ddlRawRunMode.Value = RUNMODE_TOGGLE_REPEAT) {
            chkRawDelay.Value := 0
            edRawDelayMs.Value := "200"
            edRawDelayMs.Enabled := false
        }
    }
    ddlRawRunMode.OnEvent("Change", ToggleRawRunModeControls)
    ddlRawRunMode.OnEvent("Change", (*) => ApplyRawRunModeDelayDefault())
    ddlRawRunMode.OnEvent("Change", (*) => EnforceHoldDdlSelection(ddlRawRunMode, RUNMODE_SINGLE, ToggleRawRunModeControls))
    ToggleRawRunModeControls()
    ApplyRawRunModeDelayDefault()

    ReconcileRawMapHoldDdls() {
        if rawMapUpBytesHex = "" {
            if HasVal(HoldOnlyRunModeIdx, ddlRawRunMode.Value - 1) {
                ddlRawRunMode.Choose(RUNMODE_SINGLE)
                ToggleRawRunModeControls()
            }
            if HasVal(HoldOnlyTriggerIdx, ddlRawTrigger.Value - 1)
                ddlRawTrigger.Choose(DdlIndexFromPressType("short"))
        }
        RefreshHoldDdl(ddlRawTrigger)
        RefreshHoldDdl(ddlRawRunMode)
    }

    RefreshRawMapHoldStatus() {
        txtRawHoldStatus.Value := rawMapUpBytesHex != ""
            ? Format("Hold-capable (release: Bytes:{}) - Trigger/Run mode below now apply.", rawMapUpBytesHex)
            : "Single-shot only (no hold detected) - Trigger/Run mode below are ignored until hold is detected."
        ReconcileRawMapHoldDdls()
    }

    StartRawMapCapture(*) {
        global rawMapCaptureExpectedPage, rawMapCaptureExpectedBytesHex, rawMapCaptureCallback, rawMapCaptureStatusCallback
        CancelPendingRawMapCapture()
        rawMapCaptureExpectedPage := page
        rawMapCaptureExpectedBytesHex := bytesHex
        rawMapCaptureCallback := (upBytesHex) => (
            rawMapUpBytesHex := upBytesHex,
            RefreshRawMapHoldStatus())
        rawMapCaptureStatusCallback := (text) => txtRawHoldStatus.Value := text
        txtRawHoldStatus.Value := "Get ready... (waiting for your click to finish)"
        SetTimer(ArmRawMapCapture, -300)
    }
    ArmRawMapCapture() {
        global rawMapCaptureArmed
        rawMapCaptureArmed := true
        txtRawHoldStatus.Value := Format("Waiting for you to press the SAME button again (Page:0x{:X} Bytes:{})...", page, bytesHex)
    }
    btnRawDetectHold.OnEvent("Click", StartRawMapCapture)

    ToggleRawActionControls(*) {
        v := ddlRawAction.Value
        isApp := v = ACTION_APP
        isMultimedia := v = ACTION_MULTIMEDIA
        isMouse := v = ACTION_MOUSE
        isMacro := v = ACTION_MACRO
        isKey := !isApp && !isMacro && !isMultimedia && !isMouse
        lblRawSends.Visible := isKey
        edTarget.Visible := isKey
        lblRawAppPath.Visible := isApp
        edRawAppPath.Visible := isApp
        btnRawBrowse.Visible := isApp
        btnRawArgs.Visible := isApp
        lblRawMacroSelect.Visible := isMacro
        ddlRawMacroSelect.Visible := isMacro
        btnRawEditMacro.Visible := isMacro
        lblRawMultimedia.Visible := isMultimedia
        ddlRawMultimedia.Visible := isMultimedia
        lblRawMouse.Visible := isMouse
        ddlRawMouse.Visible := isMouse
        if isApp {
            if (ddlRawRunMode.Value != RUNMODE_SINGLE) {
                ddlRawRunMode.Choose(RUNMODE_SINGLE)
                ToggleRawRunModeControls()
                ApplyRawRunModeDelayDefault()
            }
        }
        ddlRawRunMode.Enabled := !isApp
        EnforceHoldDdlSelection(ddlRawRunMode, RUNMODE_SINGLE, ToggleRawRunModeControls)
    }
    ddlRawAction.OnEvent("Change", ToggleRawActionControls)
    ToggleRawActionControls()

    btnSave := gm.Add("Button", "xm y+20 w100", "Save")
    btnSave.OnEvent("Click", (*) => SaveRawMapping(page, bytesHex, edDesc.Value, ddlRawAction.Value, edRawAppPath.Value, edRawAppArgs.Value, ddlRawMultimedia.Value, ddlRawMouse.Value, rawMapUpBytesHex, ddlRawTrigger.Value, ddlRawRunMode.Value, edRawRepeatMs.Value, chkRawDelay.Value, edRawDelayMs.Value, gm))
    btnCancel := gm.Add("Button", "x+10 w100", "Cancel")
    btnCancel.OnEvent("Click", (*) => (CancelPendingRawMapCapture(), gm.Destroy()))
    gm.OnEvent("Close", (*) => (CancelPendingRawMapCapture(), gm.Destroy()))

    OnRawMacroSelectChange(*) {
        global rawMacroSteps, savedMacros, savedMacroOrder
        idx := ddlRawMacroSelect.Value
        if idx <= 1
            return
        name := savedMacroOrder[idx - 1]
        if !savedMacros.Has(name)
            return
        rawMacroSteps := CloneMacroSteps(savedMacros[name])
    }

    RefreshRawMacroSelectDdl() {
        global rawMacroSteps, savedMacroOrder
        items := ["(Custom / unsaved)"]
        for name in savedMacroOrder
            items.Push(name)
        ddlRawMacroSelect.Delete()
        ddlRawMacroSelect.Add(items)
        matchIdx := 1
        matchName := FindSavedMacroNameForSteps(rawMacroSteps)
        if matchName != "" {
            for i, name in savedMacroOrder {
                if name = matchName {
                    matchIdx := i + 1
                    break
                }
            }
        }
        ddlRawMacroSelect.Choose(matchIdx)
    }
    RefreshRawMacroSelectDdl()

    SaveRawMacroStepsFromDialog(steps) {
        global rawMacroSteps
        rawMacroSteps := steps
        RefreshRawMacroSelectDdl()
    }

    gm.Show()
}

SaveRawMapping(page, bytesHex, desc, actionVal, appPath, appArgs, multimediaIdx, mouseIdx, upBytesHex, triggerIdx, runModeIdx, repeatMsStr, delayEnabled, delayMsStr, gm) {
    global mappings, mapOrder, rawMapTargetString, editingProfileName, editingDevTab, rawMacroSteps, legacyLongPressMs
    global ACTION_APP, ACTION_MULTIMEDIA, ACTION_MOUSE, ACTION_MACRO
    global RUNMODE_TYPEMATIC, RUNMODE_REPEAT, RUNMODE_TOGGLE_REPEAT, RUNMODE_HOLD, RUNMODE_TOGGLE_HOLD
    isApp := actionVal = ACTION_APP
    isMultimedia := actionVal = ACTION_MULTIMEDIA
    isMouse := actionVal = ACTION_MOUSE
    isMacro := actionVal = ACTION_MACRO
    if isApp {
        if appPath = "" {
            MsgBox("Enter a path first (or use Browse).", "Missing target", "Icon!")
            return
        }
    } else if isMacro {
        if rawMacroSteps.Length = 0 {
            MsgBox("Add at least one step with Edit Macro... first.", "Empty macro", "Icon!")
            return
        }
    } else {
        if isMultimedia
            rawMapTargetString := MultimediaSendForIndex(multimediaIdx)
        else if isMouse
            rawMapTargetString := MouseSendForIndex(mouseIdx)
        if rawMapTargetString = "" {
            MsgBox(isMultimedia ? "Choose a multimedia action first." : (isMouse ? "Choose a mouse action first." : "Capture a key/combo to send first."), "Missing target", "Icon!")
            return
        }
    }
    buttonKey := MakeRawButtonKey(page, bytesHex)
    key := GenerateId(editingProfileName, buttonKey)
    mapOrder.Push(key)
    dispId := SubStr(key, StrLen(editingProfileName) + 3)
    finalDesc := desc != "" ? desc : Format("Raw 0x{:X} {} ({})", page, bytesHex, dispId)

    rawHoldCapable := upBytesHex != ""
    runMode := runModeIdx = RUNMODE_TYPEMATIC ? "typematic" : (runModeIdx = RUNMODE_REPEAT ? "repeat" : (runModeIdx = RUNMODE_TOGGLE_REPEAT ? "toggle" : (runModeIdx = RUNMODE_HOLD ? "hold" : (runModeIdx = RUNMODE_TOGGLE_HOLD ? "toggleHold" : "single"))))
    rawRunMode := rawHoldCapable ? runMode : "single"
    rawPressType := rawRunMode = "single" ? PressTypeFromDdlIndex(triggerIdx) : "short"
    repeatMs := IsInteger(repeatMsStr) ? Integer(repeatMsStr) : 100
    if repeatMs < 10
        repeatMs := 10
    delayMs := IsInteger(delayMsStr) ? Integer(delayMsStr) : 200
    if delayMs < 0
        delayMs := 0
    delayOn := delayEnabled ? true : false

    if isApp
        mappings[key] := {profile: editingProfileName, kind: "raw", actionType: "app", page: page, bytesHex: bytesHex, upBytesHex: upBytesHex, desc: finalDesc, target: appPath, appArgs: appArgs, macroSteps: [], enabled: true, pressType: rawPressType, runMode: rawRunMode, repeatMs: repeatMs, delayEnabled: delayOn, delayMs: delayMs, longPressMs: legacyLongPressMs, list: "Main", devTab: SelectedAddDevTab()}
    else if isMacro {
        stepsCopy := []
        for s in rawMacroSteps
            stepsCopy.Push({type: s.type, target: s.target, args: s.args, delayAfterMs: s.delayAfterMs})
        linkedMacroName := FindSavedMacroNameForSteps(stepsCopy)
        mappings[key] := {profile: editingProfileName, kind: "raw", actionType: "macro", page: page, bytesHex: bytesHex, upBytesHex: upBytesHex, desc: finalDesc, target: "", appArgs: "", macroSteps: stepsCopy, macroName: linkedMacroName, enabled: true, pressType: rawPressType, runMode: rawRunMode, repeatMs: repeatMs, delayEnabled: delayOn, delayMs: delayMs, longPressMs: legacyLongPressMs, list: "Main", devTab: SelectedAddDevTab()}
    } else
        mappings[key] := {profile: editingProfileName, kind: "raw", actionType: "key", page: page, bytesHex: bytesHex, upBytesHex: upBytesHex, desc: finalDesc, target: rawMapTargetString, appArgs: "", macroSteps: [], enabled: true, pressType: rawPressType, runMode: rawRunMode, repeatMs: repeatMs, delayEnabled: delayOn, delayMs: delayMs, longPressMs: legacyLongPressMs, list: "Main", devTab: SelectedAddDevTab()}
    SaveProfileMapping(ProfileKey(editingDevTab, editingProfileName), key)
    RefreshList()
    CancelPendingRawMapCapture()
    gm.Destroy()
    txtStatus.Value := "Saved raw mapping for " dispId "."
}
