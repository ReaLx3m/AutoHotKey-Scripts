
RegisterHotkeyForButton(buttonKey, scIndex := "") {
    global activeProfileNameByTab, deviceModifiers, deviceModifiers2, profiles, DEVICE_TAGS, mapOrder, mappings
    global kbdListGateOn
    hasFiring := false
    for tag in DEVICE_TAGS {
        effProfile := EffectiveProfileForButton(buttonKey, "sc", tag)
        if IsObject(scIndex) {
            candidateIds := scIndex.Has(buttonKey) ? scIndex[buttonKey] : []
            for id in candidateIds {
                if !mappings.Has(id)
                    continue
                m := mappings[id]
                if !MappingOwnsButtonStatic(m, buttonKey, "sc", effProfile, tag)
                    continue
                hasFiring := true
                break
            }
        } else {
            for id in mapOrder {
                m := mappings[id]
                if !MappingOwnsButtonStatic(m, buttonKey, "sc", effProfile, tag)
                    continue
                hasFiring := true
                break
            }
        }
        if hasFiring
            break
    }
    isModifierButton := IsScModifierButton(buttonKey)
    state := (masterEnabled && (hasFiring || isModifierButton)) ? "On" : "Off"
    try {
        if kbdListGateOn
            HotIf(KbdGateCriteria)
        Hotkey("*" buttonKey, (*) => OnButtonDown(buttonKey), state)
        Hotkey("*" buttonKey " Up", (*) => OnButtonUp(buttonKey), state)
    } catch as e {
        LogWarn("hotkey", buttonKey ": Hotkey() registration failed: " e.Message)
        MsgBox("Could not register hotkey for " buttonKey ":`n" e.Message, "Error", "Icon!")
    } finally {
        if kbdListGateOn
            HotIf()
    }
}

StillPressedForThisPress(buttonKey, token) {
    global buttonPressState
    return buttonPressState.Has(buttonKey)
        && buttonPressState[buttonKey].pressed
        && buttonPressState[buttonKey].token = token
}

OnButtonDown(buttonKey, kind := "sc") {
    global buttonPressState, mappings, activeProfileNameByTab
    global activeListByTag
    global deviceModifiers2, mod1HeldByTag, mod2HeldByTag
    global mod1ArmedScByTag, mod2ArmedScByTag
    global mod1ComboUsedByTag, mod2ComboUsedByTag
    st := buttonPressState.Has(buttonKey) ? buttonPressState[buttonKey] : ""
    if st && st.pressed
        return
    MarkHeldModifiersComboUsed()
    devTab := DevTabForButtonKey(buttonKey, kind)
    effMod := EffectiveModifier(activeProfileNameByTab[devTab], devTab)
    effMod2 := EffectiveModifier2(activeProfileNameByTab[devTab], devTab)
    token := (st ? st.token : 0) + 1
    pairLong := TapLongPairOf(effMod, effMod2)
    isPairBtn := pairLong != "" && effMod.kind = "sc" && Format("SC{:03X}", effMod.sc) = buttonKey
    pressEntry := {pressed: true, token: token, longFired: false, pairLong: (isPairBtn ? pairLong : ""), pairFired: false, pairTag: devTab}
    buttonPressState[buttonKey] := pressEntry
    if !isPairBtn && effMod.kind = "sc" && Format("SC{:03X}", effMod.sc) = buttonKey {
        if effMod.lpOn {
            SetTimer(CheckModLongPressSc.Bind(buttonKey, devTab, "Mod", effMod.mode, token), -Max(1, effMod.lpMs))
        } else if effMod.mode = "toggle" {
            ToggleLatched(devTab, "Mod")
            NotifyModifierToggled(devTab)
        } else {
            mod1HeldByTag[devTab] := true
            mod1ComboUsedByTag[devTab] := false
            mod1ArmedScByTag[devTab] := buttonKey
            RecomputeHeldActiveList(devTab)
        }
    }
    if !isPairBtn && effMod2.kind = "sc" && Format("SC{:03X}", effMod2.sc) = buttonKey {
        resolvedMode2 := ResolvedMod2ModeOf(effMod, effMod2)
        if effMod2.lpOn {
            SetTimer(CheckModLongPressSc.Bind(buttonKey, devTab, "Mod2", resolvedMode2, token), -Max(1, effMod2.lpMs))
        } else if resolvedMode2 = "hold" {
            mod2HeldByTag[devTab] := true
            mod2ComboUsedByTag[devTab] := false
            mod2ArmedScByTag[devTab] := buttonKey
            RecomputeHeldActiveList(devTab)
        } else {
            ToggleLatched(devTab, "Mod2")
            NotifyModifierToggled(devTab)
        }
    }
    if isPairBtn {
        pairMs := (pairLong = "Mod") ? effMod.lpMs : effMod2.lpMs
        SetTimer(CheckPairLongSc.Bind(buttonKey, devTab, pairLong, token), -Max(1, pairMs))
    }
    RefreshModifierLiveIndicator()
    matchIds := MatchingMappingIds(buttonKey, kind)
    heldIds := []
    for id in matchIds {
        m := mappings[id]
        runMode := MapRunMode(m)
        if (runMode = "repeat" || runMode = "typematic" || runMode = "hold") {
            if !StillPressedForThisPress(buttonKey, token)
                continue
        }
        if runMode = "repeat" {
            StartRepeat(id)
            heldIds.Push(id)
        } else if runMode = "typematic" {
            StartRepeat(id)
            heldIds.Push(id)
        } else if runMode = "hold" {
            FireHoldDown(id, m)
            heldIds.Push(id)
        }
    }
    pressEntry.heldIds := heldIds
    FireButtonMappings(buttonKey, "press", kind, matchIds)
    for id in FindLongPressMappingIds(buttonKey, kind, matchIds) {
        m := mappings[id]
        mLongPressMs := MapLongPressMs(m)
        SetTimer(CheckLongPress.Bind(buttonKey, token, id), -Max(1, mLongPressMs))
    }
}

OnButtonUp(buttonKey, kind := "sc") {
    global buttonPressState, mappings, activeProfileNameByTab
    global activeListByTag
    global deviceModifiers2, mod1HeldByTag, mod2HeldByTag
    global mod1ArmedScByTag, mod2ArmedScByTag
    global mod1ComboUsedByTag, mod2ComboUsedByTag
    devTab := DevTabForButtonKey(buttonKey, kind)
    wasComboUsedMod1 := false
    wasComboUsedMod2 := false
    mod1ReleasedByArmed := false
    mod2ReleasedByArmed := false
    if mod1HeldByTag[devTab] && mod1ArmedScByTag[devTab] != "" && mod1ArmedScByTag[devTab] = buttonKey {
        wasComboUsedMod1 := mod1ComboUsedByTag[devTab]
        mod1ComboUsedByTag[devTab] := false
        mod1HeldByTag[devTab] := false
        mod1ArmedScByTag[devTab] := ""
        RecomputeHeldActiveList(devTab)
        mod1ReleasedByArmed := true
    }
    if mod2HeldByTag[devTab] && mod2ArmedScByTag[devTab] != "" && mod2ArmedScByTag[devTab] = buttonKey {
        wasComboUsedMod2 := mod2ComboUsedByTag[devTab]
        mod2ComboUsedByTag[devTab] := false
        mod2HeldByTag[devTab] := false
        mod2ArmedScByTag[devTab] := ""
        RecomputeHeldActiveList(devTab)
        mod2ReleasedByArmed := true
    }
    if mod1ReleasedByArmed || mod2ReleasedByArmed
        RefreshModifierLiveIndicator()
    if !buttonPressState.Has(buttonKey)
        return
    st := buttonPressState[buttonKey]
    if !st.pressed
        return
    st.pressed := false
    effMod := EffectiveModifier(activeProfileNameByTab[devTab], devTab)
    effMod2 := EffectiveModifier2(activeProfileNameByTab[devTab], devTab)
    if st.pairLong != "" && !st.pairFired
        PairShortAction(devTab, st.pairLong)
    if !mod1ReleasedByArmed && effMod.kind = "sc" && Format("SC{:03X}", effMod.sc) = buttonKey {
        if effMod.mode != "toggle" {
            wasComboUsedMod1 := mod1ComboUsedByTag[devTab]
            mod1ComboUsedByTag[devTab] := false
            mod1HeldByTag[devTab] := false
            RecomputeHeldActiveList(devTab)
        }
    }
    if !mod2ReleasedByArmed && effMod2.kind = "sc" && Format("SC{:03X}", effMod2.sc) = buttonKey && ResolvedMod2ModeOf(effMod, effMod2) = "hold" {
        wasComboUsedMod2 := mod2ComboUsedByTag[devTab]
        mod2ComboUsedByTag[devTab] := false
        mod2HeldByTag[devTab] := false
        RecomputeHeldActiveList(devTab)
    }
    RefreshModifierLiveIndicator()
    matchIds := MatchingMappingIds(buttonKey, kind)
    heldIds := st.HasOwnProp("heldIds") ? st.heldIds : []
    for id in heldIds {
        if !mappings.Has(id)
            continue
        m := mappings[id]
        runMode := MapRunMode(m)
        if runMode = "repeat" || runMode = "typematic"
            StopRepeat(id)
        else if runMode = "hold"
            FireHoldUp(id, m)
    }
    for id in matchIds {
        m := mappings[id]
        runMode := MapRunMode(m)
        if runMode = "toggle"
            ToggleRepeat(id)
        else if runMode = "toggleHold"
            ToggleHold(id, m)
    }
    pkey := ProfileKey(devTab, activeProfileNameByTab[devTab])
    suppressed := (wasComboUsedMod1 && !EffectivePassthroughSetting(pkey, "Mod", devTab))
        || (wasComboUsedMod2 && !EffectivePassthroughSetting(pkey, "Mod2", devTab))
    if !suppressed {
        FireButtonMappings(buttonKey, "release", kind, matchIds)
        if !st.longFired
            FireButtonMappings(buttonKey, "short", kind, matchIds)
    }
}

KbdGateDecide(bk) {
    if IsScModifierButton(bk)
        return true
    return MatchingMappingIds(bk, "sc").Length > 0
}

KbdGateCriteria(hkName) {
    global kbdGateLatch, KBD_GATE_STALE_MS
    try {
        if !RegExMatch(hkName, "i)^\*?(SC[0-9A-F]{3})(\s+Up)?$", &mm)
            return true
        bk := StrUpper(mm[1])
        isUp := (mm[2] != "")
        now := A_TickCount
        if isUp {
            if !kbdGateLatch.Has(bk)
                return false
            lt := kbdGateLatch[bk]
            lt.upSeen := true
            return lt.swallow
        }
        if kbdGateLatch.Has(bk) {
            lt := kbdGateLatch[bk]
            if !lt.upSeen && (now - lt.tick) <= KBD_GATE_STALE_MS {
                lt.tick := now
                return lt.swallow
            }
        }
        sw := KbdGateDecide(bk)
        kbdGateLatch[bk] := {swallow: sw, upSeen: false, tick: now}
        return sw
    } catch {
        return true
    }
}

RefreshAllScHotkeyStates() {
    global deviceModifiers, profiles
    scIdx := BuildScButtonIndex()
    seenButtons := Map()
    for id in mapOrder {
        m := mappings[id]
        if (MapKind(m)) != "sc"
            continue
        bk := Format("SC{:03X}", m.sc)
        if seenButtons.Has(bk)
            continue
        seenButtons[bk] := true
        RegisterHotkeyForButton(bk, scIdx)
    }
    for tag, dm in deviceModifiers {
        if dm.kind != "sc"
            continue
        bk := Format("SC{:03X}", dm.sc)
        if !seenButtons.Has(bk) {
            seenButtons[bk] := true
            RegisterHotkeyForButton(bk, scIdx)
        }
    }
    for pkey, pdata in profiles {
        if ProfModKind(pdata) != "sc"
            continue
        bk := Format("SC{:03X}", pdata.modSc)
        if !seenButtons.Has(bk) {
            seenButtons[bk] := true
            RegisterHotkeyForButton(bk, scIdx)
        }
    }
    for pkey, pdata in profiles {
        if ProfMod2Kind(pdata) != "sc"
            continue
        bk := Format("SC{:03X}", pdata.mod2Sc)
        if !seenButtons.Has(bk) {
            seenButtons[bk] := true
            RegisterHotkeyForButton(bk, scIdx)
        }
    }
}
