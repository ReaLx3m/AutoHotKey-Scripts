
EffectiveLedChoice(profileName, devTab, isMod2) {
    global profiles, ledIndicatorChoiceByTag, ledIndicatorChoiceByTag2
    pk := ProfileKey(devTab, profileName)
    if profiles.Has(pk) {
        p := profiles[pk]
        pTag := ProfDevTabForMatch(p)
        if pTag = devTab {
            field := isMod2 ? "ledChoice2" : "ledChoice"
            v := p.HasOwnProp(field) ? p.%field% : "Inherit"
            if v != "Inherit" && v != ""
                return v
        }
    }
    return isMod2 ? ledIndicatorChoiceByTag2[devTab] : ledIndicatorChoiceByTag[devTab]
}

EffectiveLedFlash(profileName, devTab, isMod2, choice) {
    global profiles
    global lockFlashEnabledByTagSlot, lockFlashIntervalMsByTagSlot
    ledField := isMod2 ? "ledChoice2" : "ledChoice"
    suffix := isMod2 ? "2" : ""
    profileOwnsChoice := false
    pk := ProfileKey(devTab, profileName)
    if profiles.Has(pk) {
        p := profiles[pk]
        pTag := ProfDevTabForMatch(p)
        if pTag = devTab {
            v := p.HasOwnProp(ledField) ? p.%ledField% : "Inherit"
            if v != "Inherit" && v != ""
                profileOwnsChoice := true
        }
    }
    enField := (choice = "ScrollLock") ? "scrollFlashOn" . suffix
        : (choice = "CapsLock") ? "capsFlashOn" . suffix
        : "numFlashOn" . suffix
    msField := (choice = "ScrollLock") ? "scrollFlashMs" . suffix
        : (choice = "CapsLock") ? "capsFlashMs" . suffix
        : "numFlashMs" . suffix
    if profileOwnsChoice {
        p := profiles[pk]
        return {enabled: p.HasOwnProp(enField) ? p.%enField% : false, ms: p.HasOwnProp(msField) ? p.%msField% : 500}
    }
    slot := isMod2 ? 2 : 1
    return {enabled: lockFlashEnabledByTagSlot[choice][devTab][slot], ms: lockFlashIntervalMsByTagSlot[choice][devTab][slot]}
}

EffectiveNotifyModifierToggle(profileName, devTab) {
    global profiles, notifyModifierToggleByTag
    pk := ProfileKey(devTab, profileName)
    if profiles.Has(pk) {
        p := profiles[pk]
        pTag := ProfDevTabForMatch(p)
        if pTag = devTab {
            v := p.HasOwnProp("notifyToggle") ? p.notifyToggle : "Inherit"
            if v = "On"
                return true
            if v = "Off"
                return false
        }
    }
    return notifyModifierToggleByTag[devTab]
}

ProfileLedFieldNames() {
    names := []
    for suffix in ["", "2"] {
        names.Push("ledChoice" suffix)
        for kind in ["scroll", "caps", "num"] {
            names.Push(kind "FlashOn" suffix)
            names.Push(kind "FlashMs" suffix)
        }
    }
    names.Push("notifyToggle")
    return names
}

ProfileLedFieldsFrom(src) {
    out := {}
    for suffix in ["", "2"] {
        choiceFld := "ledChoice" suffix
        v := (IsObject(src) && src.HasOwnProp(choiceFld)) ? src.%choiceFld% : "Inherit"
        if v != "Inherit" && v != "Off" && v != "ScrollLock" && v != "CapsLock" && v != "NumLock"
            v := "Inherit"
        out.%choiceFld% := v
        for kind in ["scroll", "caps", "num"] {
            enFld := kind "FlashOn" suffix
            msFld := kind "FlashMs" suffix
            out.%enFld% := LpOnOf(src, enFld)
            out.%msFld% := SanitizeFlashIntervalMs((IsObject(src) && src.HasOwnProp(msFld)) ? src.%msFld% : 500)
        }
    }
    nv := (IsObject(src) && src.HasOwnProp("notifyToggle")) ? src.notifyToggle : "Inherit"
    out.notifyToggle := (nv = "On" || nv = "Off") ? nv : "Inherit"
    return out
}

ApplyProfileLedFields(target, src) {
    for fld in ProfileLedFieldNames()
        target.%fld% := src.%fld%
}

ProfileLedSig(p) {
    f := ProfileLedFieldsFrom(p)
    sig := ""
    for fld in ProfileLedFieldNames()
        sig .= f.%fld% . "|"
    return sig
}

ProfileLedIniKey(fld) => StrUpper(SubStr(fld, 1, 1)) . SubStr(fld, 2)

ProfileLedIniLines(pdata) {
    f := ProfileLedFieldsFrom(pdata)
    out := ""
    for fld in ProfileLedFieldNames() {
        v := f.%fld%
        if InStr(fld, "FlashOn")
            v := v ? "1" : "0"
        out .= ProfileLedIniKey(fld) "=" v "`r`n"
    }
    return out
}

ProfileLedReadIni(file, section) {
    raw := {}
    for fld in ProfileLedFieldNames() {
        v := IniRead(file, section, ProfileLedIniKey(fld), "")
        if v != ""
            raw.%fld% := v
    }
    return ProfileLedFieldsFrom(raw)
}

ReleaseLedsForProfile(tag, profileName) {
    StopLedFlashForTag(tag)
    for c in [EffectiveLedChoice(profileName, tag, false), EffectiveLedChoice(profileName, tag, true)] {
        if c = "ScrollLock" || c = "CapsLock" || c = "NumLock"
            SetLockLED(c, false)
    }
}

LedSettingsDifferBetweenProfiles(tag, a, b) {
    for isMod2 in [false, true] {
        ca := EffectiveLedChoice(a, tag, isMod2)
        cb := EffectiveLedChoice(b, tag, isMod2)
        if ca != cb
            return true
        if ca != "Off" {
            fa := EffectiveLedFlash(a, tag, isMod2, ca)
            fb := EffectiveLedFlash(b, tag, isMod2, cb)
            if (fa.enabled ? 1 : 0) != (fb.enabled ? 1 : 0)
                return true
            if fa.enabled && fa.ms != fb.ms
                return true
        }
    }
    return false
}

OpenLogFolder() {
    try Run('explorer.exe "' DataDir() '"')
}

OnTrayMsg(wParam, lParam, msg, hwnd) {
    if (lParam = 0x203)
        ShowGui()
}

LaunchApp(path, args) {
    if path = ""
        return
    try {
        cmd := '"' path '"'
        if args != ""
            cmd .= " " args
        Run(cmd)
    } catch as e {
        LogWarn("launch", path ": Run() failed: " e.Message)
        MsgBox("Could not launch:`n" path (args != "" ? " " args : "") "`n`n" e.Message, "Launch Error", "Icon!")
    }
}

FileExistCleanup(f) {
    try FileDelete(f)
}

RunPsScript(body, hide := false) {
    if body = ""
        return
    try {
        f := A_Temp "\MFBM_ps_" A_TickCount ".ps1"
        FileAppend(body, f, "UTF-8")
        psCmd := 'powershell.exe -NoProfile' (hide ? ' -WindowStyle Hidden' : '') ' -ExecutionPolicy Bypass -File "' f '"'
        Run(psCmd, , hide ? "Hide" : "")
        SetTimer(() => FileExistCleanup(f), -30000)
    } catch as e {
        LogWarn("runps", "RunPsScript: Run() failed: " e.Message)
        MsgBox("Could not run PowerShell script:`n`n" e.Message, "Run Error", "Icon!")
    }
}

RunCmdScript(body, hide := false) {
    if body = ""
        return
    try {
        f := A_Temp "\MFBM_cmd_" A_TickCount ".bat"
        FileAppend(body, f, "CP1252")
        Run('cmd.exe /c "' f '"', , hide ? "Hide" : "")
        SetTimer(() => FileExistCleanup(f), -30000)
    } catch as e {
        LogWarn("runcmd", "RunCmdScript: Run() failed: " e.Message)
        MsgBox("Could not run CMD script:`n`n" e.Message, "Run Error", "Icon!")
    }
}

SetNotifyModifierToggle(val) {
    global notifyModifierToggleByTag, editingDevTab
    notifyModifierToggleByTag[editingDevTab] := !!val
    chkNotifyModifierToggle.Value := notifyModifierToggleByTag[editingDevTab]
    SaveNotifyModifierToggleForTag(editingDevTab)
}

SetLedIndicatorChoice(choice) {
    global ledIndicatorChoiceByTag, ledIndicatorChoiceByTag2, editingDevTab, tabModifierSection, activeListByTag
    isMod2 := tabModifierSection.Value = 2
    choiceMap := isMod2 ? ledIndicatorChoiceByTag2 : ledIndicatorChoiceByTag
    oldChoice := choiceMap[editingDevTab]
    if oldChoice = choice {
        UpdateLedIndicatorOptionForTag()
        return
    }
    isCurrentlyActiveMod := activeListByTag.Has(editingDevTab) && activeListByTag[editingDevTab] = (isMod2 ? "Mod2" : "Mod")
    if isCurrentlyActiveMod {
        StopLedFlashForTag(editingDevTab)
        if oldChoice = "ScrollLock" || oldChoice = "CapsLock" || oldChoice = "NumLock"
            SetLockLED(oldChoice, false)
    }
    choiceMap[editingDevTab] := choice
    UpdateLedIndicatorOptionForTag()
    ApplyLedIndicatorForTag(editingDevTab)
    SaveLedSettingsForTag(editingDevTab, isMod2 ? 2 : 1)
}

SetLockFlashEnabled(lock, val) {
    global lockFlashEnabledByTagSlot
    global editingDevTab, tabModifierSection
    isMod2 := (tabModifierSection.Value = 2)
    slot := isMod2 ? 2 : 1
    lockKey := (lock = "Scroll") ? "ScrollLock" : (lock = "Caps") ? "CapsLock" : "NumLock"
    lockFlashEnabledByTagSlot[lockKey][editingDevTab][slot] := !!val
    UpdateLedIndicatorOptionForTag()
    ApplyLedIndicatorForTag(editingDevTab)
    SaveLedSettingsForTag(editingDevTab, slot)
}

SanitizeFlashIntervalMs(rawVal) {
    digitsOnly := RegExReplace(rawVal, "[^\d]", "")
    n := (digitsOnly = "") ? 500 : Integer(digitsOnly)
    if n < 30
        n := 30
    else if n > 60000
        n := 60000
    return n
}

SetLockFlashIntervalMs(lock, rawVal) {
    global lockFlashIntervalMsByTagSlot
    global edScrollLockFlashMs, edCapsLockFlashMs, edNumLockFlashMs
    global editingDevTab, tabModifierSection
    isMod2 := (tabModifierSection.Value = 2)
    slot := isMod2 ? 2 : 1
    lockKey := (lock = "Scroll") ? "ScrollLock" : (lock = "Caps") ? "CapsLock" : "NumLock"
    ed := (lock = "Scroll") ? edScrollLockFlashMs : (lock = "Caps") ? edCapsLockFlashMs : edNumLockFlashMs
    n := SanitizeFlashIntervalMs(rawVal)
    lockFlashIntervalMsByTagSlot[lockKey][editingDevTab][slot] := n
    ed.Value := n
    ApplyLedIndicatorForTag(editingDevTab)
    SaveLedSettingsForTag(editingDevTab, slot)
}

SetCapsLockLedDeviceChoice(ddlPosition) {
    global capsLockLedDeviceIndex, g_LedFlagsCache
    capsLockLedDeviceIndex := ddlPosition - 1
    g_LedFlagsCache := -1
    SaveCapsLockLedDeviceIndex()
}

SetKeyboardIndicatorLED(turnOn, ledBit, &lastErrorOut) {
    global capsLockLedDeviceIndex, g_LedFlagsCache
    static IOCTL_KEYBOARD_QUERY_INDICATORS := 0x000B0040
    static IOCTL_KEYBOARD_SET_INDICATORS   := 0x000B0008
    static FILE_READ_ATTRIBUTES  := 0x0080
    static FILE_WRITE_ATTRIBUTES := 0x0100
    static SYNCHRONIZE           := 0x00100000
    static DESIRED_ACCESS := FILE_READ_ATTRIBUTES | FILE_WRITE_ATTRIBUTES | SYNCHRONIZE
    static FILE_SHARE_RW := 0x3
    static OPEN_EXISTING := 3

    lastErrorOut := ""
    devPath := "\\.\GLOBALROOT\Device\KeyboardClass" capsLockLedDeviceIndex

    hKeybd := DllCall("CreateFile"
        , "Str", devPath
        , "UInt", DESIRED_ACCESS
        , "UInt", FILE_SHARE_RW
        , "Ptr", 0
        , "UInt", OPEN_EXISTING
        , "UInt", 0
        , "Ptr", 0, "Ptr")
    if (hKeybd = -1 || hKeybd = 0) {
        err := A_LastError
        lastErrorOut := devPath ": CreateFile failed (Win32 error " err
            . (err = 5 ? " - access denied, script likely isn't elevated" : "") ")"
        return false
    }

    if (g_LedFlagsCache = -1) {
        buf := Buffer(4, 0)
        ok := DllCall("DeviceIoControl"
            , "Ptr", hKeybd, "UInt", IOCTL_KEYBOARD_QUERY_INDICATORS
            , "Ptr", 0, "UInt", 0
            , "Ptr", buf, "UInt", 4
            , "UInt*", &bytesReturned := 0, "Ptr", 0)
        if !ok {
            lastErrorOut := devPath ": QUERY_INDICATORS failed (Win32 error " A_LastError ")"
            DllCall("CloseHandle", "Ptr", hKeybd)
            return false
        }
        g_LedFlagsCache := NumGet(buf, 2, "UShort")
    }

    buf := Buffer(4, 0)
    ledFlags := turnOn ? (g_LedFlagsCache | ledBit) : (g_LedFlagsCache & ~ledBit)
    NumPut("UShort", ledFlags, buf, 2)

    ok := DllCall("DeviceIoControl"
        , "Ptr", hKeybd, "UInt", IOCTL_KEYBOARD_SET_INDICATORS
        , "Ptr", buf, "UInt", 4
        , "Ptr", 0, "UInt", 0
        , "UInt*", &bytesReturned2 := 0, "Ptr", 0)
    if !ok {
        lastErrorOut := devPath ": SET_INDICATORS failed (Win32 error " A_LastError ")"
        DllCall("CloseHandle", "Ptr", hKeybd)
        return false
    }

    DllCall("CloseHandle", "Ptr", hKeybd)
    lastErrorOut := devPath ": succeeded"
    g_LedFlagsCache := ledFlags
    return true
}

SetLockLED(lock, turnOn) {
    global g_ScrollLockLedLastError, g_CapsLockLedLastError, g_NumLockLedLastError
    static SCROLL_BIT := 0x01
    static CAPS_BIT   := 0x04
    static NUM_BIT    := 0x02
    ledBit := (lock = "ScrollLock") ? SCROLL_BIT : (lock = "CapsLock") ? CAPS_BIT : NUM_BIT
    ok := SetKeyboardIndicatorLED(turnOn, ledBit, &err)
    if lock = "ScrollLock"
        g_ScrollLockLedLastError := err
    else if lock = "CapsLock"
        g_CapsLockLedLastError := err
    else
        g_NumLockLedLastError := err
    return ok
}

StopLedFlashForTag(tag) {
    global flashTimerFuncByTag
    if flashTimerFuncByTag.Has(tag) && flashTimerFuncByTag[tag] != "" {
        SetTimer(flashTimerFuncByTag[tag], 0)
        flashTimerFuncByTag[tag] := ""
    }
}

StartLedFlashForTag(tag, intervalMs) {
    global flashTimerFuncByTag, flashLedPhaseByTag, activeListByTag, activeProfileNameByTab
    StopLedFlashForTag(tag)
    isMod2 := activeListByTag.Has(tag) && activeListByTag[tag] = "Mod2"
    profile := activeProfileNameByTab.Has(tag) ? activeProfileNameByTab[tag] : "Default"
    choice := EffectiveLedChoice(profile, tag, isMod2)
    flashLedPhaseByTag[tag] := true
    if choice = "ScrollLock" || choice = "CapsLock" || choice = "NumLock"
        SetLockLED(choice, true)
    fn := FlashLedTick.Bind(tag)
    flashTimerFuncByTag[tag] := fn
    SetTimer(fn, intervalMs)
}

FlashLedTick(tag) {
    global activeListByTag, flashLedPhaseByTag, activeProfileNameByTab
    isMod2 := activeListByTag.Has(tag) && activeListByTag[tag] = "Mod2"
    profile := activeProfileNameByTab.Has(tag) ? activeProfileNameByTab[tag] : "Default"
    choice := EffectiveLedChoice(profile, tag, isMod2)
    if !activeListByTag.Has(tag) || activeListByTag[tag] = "Main" || choice = "Off" {
        StopLedFlashForTag(tag)
        if choice = "ScrollLock" || choice = "CapsLock" || choice = "NumLock"
            SetLockLED(choice, false)
        return
    }
    phase := !flashLedPhaseByTag[tag]
    flashLedPhaseByTag[tag] := phase
    if choice = "ScrollLock" || choice = "CapsLock" || choice = "NumLock"
        SetLockLED(choice, phase)
}

ApplyLedIndicatorForTag(tag) {
    global activeListByTag, activeProfileNameByTab

    profile := activeProfileNameByTab.Has(tag) ? activeProfileNameByTab[tag] : "Default"
    activeList := activeListByTag.Has(tag) ? activeListByTag[tag] : "Main"
    if activeList = "Main" {
        StopLedFlashForTag(tag)
        for c in [EffectiveLedChoice(profile, tag, false), EffectiveLedChoice(profile, tag, true)] {
            if c = "ScrollLock" || c = "CapsLock" || c = "NumLock"
                SetLockLED(c, false)
        }
        return
    }

    isMod2 := activeList = "Mod2"
    choice := EffectiveLedChoice(profile, tag, isMod2)
    StopLedFlashForTag(tag)
    otherChoice := EffectiveLedChoice(profile, tag, !isMod2)
    if otherChoice != choice {
        if otherChoice = "ScrollLock" || otherChoice = "CapsLock" || otherChoice = "NumLock"
            SetLockLED(otherChoice, false)
    }
    if choice = "Off"
        return
    flash := EffectiveLedFlash(profile, tag, isMod2, choice)
    if flash.enabled {
        StartLedFlashForTag(tag, flash.ms)
    } else {
        StopLedFlashForTag(tag)
        if choice = "ScrollLock" || choice = "CapsLock" || choice = "NumLock"
            SetLockLED(choice, true)
    }
}

NotifyModifierToggled(tag) {
    global activeListByTag, activeProfileNameByTab
    profile := activeProfileNameByTab.Has(tag) ? activeProfileNameByTab[tag] : "Default"
    if !EffectiveNotifyModifierToggle(profile, tag)
        return
    newList := activeListByTag[tag]
    stateLabel := (newList = "Main") ? "OFF" : (newList = "Mod2") ? "Mod 2 ON" : "Mod 1 ON"
    TrayTip("Modifier (" tag "): " stateLabel, "MF Button Mapper")
}

SetRunElevated(val) {
    global runElevated
    val := !!val
    if val && !A_IsAdmin {
        answer := MsgBox("Restart MF Button Mapper as Administrator now?`n`nThis fixes mappings getting stuck sending the button's factory function while Voice Access, Narrator, Magnifier, or the on-screen keyboard has focus.", "Restart elevated?", "YesNo Icon!")
        if answer != "Yes" {
            chkRunElevated.Value := false
            return
        }
        runElevated := true
        SaveRunElevated()
        RelaunchElevated()
        return
    }
    runElevated := val
    SaveRunElevated()
    if !val && A_IsAdmin
        MsgBox("This takes effect the next time the app is started normally - it's already running elevated for this session.", "Run elevated", "Icon!")
}

RelaunchElevated() {
    global suppressLaunchOnExit
    try {
        if A_IsCompiled
            Run("*RunAs `"" A_ScriptFullPath "`"")
        else
            Run("*RunAs `"" A_AhkPath "`" /restart `"" A_ScriptFullPath "`"")
    } catch as e {
        LogWarn("startup", "RelaunchElevated failed: " e.Message)
        MsgBox("Could not restart elevated (UAC prompt cancelled or blocked):`n" e.Message, "Elevation failed", "Icon!")
        return
    }
    suppressLaunchOnExit := true
    ExitApp()
}

StartupShortcutPath() {
    return A_Startup "\MF Button Mapper.lnk"
}

CreateStartupShortcut() {
    try {
        if A_IsCompiled
            FileCreateShortcut(A_ScriptFullPath, StartupShortcutPath(), A_ScriptDir, "", "MF Button Mapper", A_ScriptFullPath)
        else
            FileCreateShortcut(A_AhkPath, StartupShortcutPath(), A_ScriptDir, '"' A_ScriptFullPath '"', "MF Button Mapper", A_ScriptFullPath)
        return true
    } catch as e {
        LogWarn("startup", "CreateStartupShortcut failed: " e.Message)
        MsgBox("Could not create the startup shortcut:`n" e.Message, "Startup shortcut failed", "Icon!")
        return false
    }
}

RemoveStartupShortcut() {
    try {
        if FileExist(StartupShortcutPath())
            FileDelete(StartupShortcutPath())
    } catch as e {
        LogWarn("startup", "RemoveStartupShortcut failed: " e.Message)
        MsgBox("Could not remove the startup shortcut:`n" e.Message, "Startup shortcut failed", "Icon!")
    }
}

PSQuote(str) {
    return StrReplace(str, "'", "''")
}

RunPowerShellScript(psContent, elevated := false) {
    psFile  := A_Temp "\RBM_TaskSetup_" A_TickCount ".ps1"
    errFile := psFile ".err.txt"
    try FileDelete(psFile)
    try FileDelete(errFile)

    wrapped := "$ErrorActionPreference = 'Stop'`n"
    wrapped .= "try {`n" psContent "`n}`n"
    wrapped .= "catch {`n"
    wrapped .= "  $_.Exception.Message | Out-File -FilePath '" PSQuote(errFile) "' -Encoding UTF8`n"
    wrapped .= "  exit 1`n"
    wrapped .= "}`n"

    FileAppend(wrapped, psFile, "UTF-8")

    psArgs := '-NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "' psFile '"'
    psCmd  := (elevated ? '*RunAs ' : '') '"powershell" ' psArgs
    try {
        exitCode := RunWait(psCmd, , "Hide")
    } catch as e {
        try FileDelete(psFile)
        try FileDelete(errFile)
        return {code: -1, error: "The elevation (UAC) prompt was cancelled or blocked."}
    }

    errMsg := ""
    if FileExist(errFile)
        try errMsg := Trim(FileRead(errFile, "UTF-8"))

    try FileDelete(psFile)
    try FileDelete(errFile)
    return {code: exitCode, error: errMsg}
}

IsStartupTaskRegistered() {
    global RunAtStartupTaskName
    psContent := "if (Get-ScheduledTask -TaskName '" PSQuote(RunAtStartupTaskName) "' -ErrorAction SilentlyContinue) { exit 0 } else { exit 1 }"
    return RunPowerShellScript(psContent).code = 0
}

SetStartupTask(enable) {
    global RunAtStartupTaskName
    if enable {
        execPath := A_IsCompiled ? A_ScriptFullPath : A_AhkPath
        execArg  := A_IsCompiled ? "" : '"' A_ScriptFullPath '"'

        if execArg = ""
            psContent := "$action = New-ScheduledTaskAction -Execute '" PSQuote(execPath) "'`n"
        else
            psContent := "$action = New-ScheduledTaskAction -Execute '" PSQuote(execPath) "' -Argument '" PSQuote(execArg) "'`n"

        psContent .= "$trigger = New-ScheduledTaskTrigger -AtLogOn`n"
        psContent .= "$trigger.Delay = 'PT15S'`n"
        psContent .= "$principal = New-ScheduledTaskPrincipal -UserId $env:USERNAME -RunLevel Highest -LogonType Interactive`n"
        psContent .= "$settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)`n"
        psContent .= "Register-ScheduledTask -TaskName '" PSQuote(RunAtStartupTaskName) "' -Action $action -Trigger $trigger -Principal $principal -Settings $settings -Force | Out-Null"

        result := RunPowerShellScript(psContent)
        if result.code != 0 && !A_IsAdmin {
            result := RunPowerShellScript(psContent, true)
        }
        return {ok: result.code = 0, error: result.error}
    } else {
        psContent := "Unregister-ScheduledTask -TaskName '" PSQuote(RunAtStartupTaskName) "' -Confirm:$false -ErrorAction SilentlyContinue"
        RunPowerShellScript(psContent)
        return {ok: true, error: ""}
    }
}

SetRunAtStartup(val) {
    global runAtStartup, runAtStartupMode
    val := !!val
    mode := ddlRunStartupMode.Text = "As admin (Task Scheduler)" ? "admin" : "shortcut"
    if val {
        if mode = "admin" {
            result := SetStartupTask(true)
            if !result.ok {
                msg := "Couldn't create the startup task."
                if result.error != ""
                    msg .= "`n`nDetails:`n" result.error
                MsgBox(msg, "Startup", "Icon!")
                chkRunStartup.Value := false
                return
            }
        } else {
            if !CreateStartupShortcut() {
                chkRunStartup.Value := false
                return
            }
        }
        runAtStartupMode := mode
    } else {
        if runAtStartupMode = "admin"
            SetStartupTask(false)
        else
            RemoveStartupShortcut()
    }
    runAtStartup := val
    chkRunStartup.Value := runAtStartup
    SaveRunAtStartupSettings()
    txtStatus.Value := runAtStartup
        ? (runAtStartupMode = "admin"
            ? "Added to Windows startup (elevated, via Task Scheduler) - no UAC prompt at login."
            : "Added to Windows startup - the app will launch automatically at login.")
        : "Removed from Windows startup."
}

OnRunStartupModeChange() {
    global runAtStartupMode
    newMode := ddlRunStartupMode.Text = "As admin (Task Scheduler)" ? "admin" : "shortcut"
    if newMode = runAtStartupMode
        return
    if runAtStartup {
        if newMode = "admin" {
            result := SetStartupTask(true)
            if !result.ok {
                msg := "Couldn't create the startup task."
                if result.error != ""
                    msg .= "`n`nDetails:`n" result.error
                MsgBox(msg, "Startup", "Icon!")
                ddlRunStartupMode.Choose(1)
                return
            }
            RemoveStartupShortcut()
        } else {
            if !CreateStartupShortcut() {
                ddlRunStartupMode.Choose(2)
                return
            }
            SetStartupTask(false)
        }
    }
    runAtStartupMode := newMode
    SaveRunAtStartupSettings()
}

SetMasterEnabled(val) {
    global masterEnabled
    masterEnabled := !!val
    chkMaster.Value := masterEnabled
    if masterEnabled
        A_TrayMenu.Check("Remapping Enabled")
    else {
        A_TrayMenu.Uncheck("Remapping Enabled")
        StopAllRepeats()
    }
    RefreshAllScHotkeyStates()
    NativeHookRequestPublish()
    SaveMasterEnabled()
    txtStatus.Value := masterEnabled ? "Remapping enabled." : "Remapping paused."
}

ToggleMasterFromTray(*) {
    SetMasterEnabled(!masterEnabled)
}

SetStartHidden(val) {
    global startHidden
    startHidden := !!val
    chkStartHidden.Value := startHidden
    if startHidden
        A_TrayMenu.Check("Start Hidden")
    else
        A_TrayMenu.Uncheck("Start Hidden")
    SaveStartHidden()
}

ToggleStartHiddenFromTray(*) {
    SetStartHidden(!startHidden)
}

ShowTerminateAppsMenu() {
    global terminateMenuX, terminateMenuY
    rect := Buffer(16)
    DllCall("GetWindowRect", "ptr", btnTerminateApps.Hwnd, "ptr", rect)
    terminateMenuX := NumGet(rect, 0, "int")
    terminateMenuY := NumGet(rect, 12, "int")
    OpenTerminateAppsMenu()
}

OpenTerminateAppsMenu() {
    CoordMode("Menu", "Screen")
    terminateMenu.Show(terminateMenuX, terminateMenuY)
}

ToggleTerminateApp(key, *) {
    global terminateAppsSelected
    terminateAppsSelected[key] := !terminateAppsSelected[key]
    RefreshTerminateAppsUI()
    SaveTerminateOnStart()
    SetTimer(OpenTerminateAppsMenu, -10)
}

RefreshTerminateAppsUI() {
    count := 0
    lastName := ""
    for app in terminateApps {
        if terminateAppsSelected[app.key] {
            terminateMenu.Check(app.name)
            count++
            lastName := app.name
        } else
            terminateMenu.Uncheck(app.name)
    }
    btnTerminateApps.Text := (count = 0 ? "None" : count = 1 ? lastName : count " apps selected") " " Chr(0x25BE)
}

SaveTerminateOnStart() {
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    sf := SettingsFile()
    for app in terminateApps
        IniWrite(terminateAppsSelected[app.key] ? "1" : "0", sf, "Settings", "TerminateOnStart_" app.key)
}

TerminateSelectedAppsOnStart() {
    procNames := []
    for app in terminateApps {
        if !terminateAppsSelected[app.key]
            continue
        for procName in app.procs
            procNames.Push(procName)
    }
    if procNames.Length = 0
        return
    for procName in procNames
        CloseProcessWindowsGracefully(procName)
    if TerminateAppsForceAfterMs > 0
        SetTimer(ForceTerminateProcesses.Bind(procNames), -TerminateAppsForceAfterMs)
}

CloseProcessWindowsGracefully(exeName) {
    static WM_CLOSE := 0x0010
    prevDetectHidden := A_DetectHiddenWindows
    DetectHiddenWindows true
    try {
        for hwnd in WinGetList("ahk_exe " exeName)
            DllCall("PostMessage", "ptr", hwnd, "uint", WM_CLOSE, "ptr", 0, "ptr", 0)
    }
    DetectHiddenWindows prevDetectHidden
    hwnd := 0
    while (hwnd := DllCall("FindWindowEx", "ptr", -3, "ptr", hwnd, "ptr", 0, "ptr", 0, "ptr")) {
        wpid := 0
        DllCall("GetWindowThreadProcessId", "ptr", hwnd, "uint*", &wpid)
        try {
            if ProcessGetName(wpid) = exeName
                DllCall("PostMessage", "ptr", hwnd, "uint", WM_CLOSE, "ptr", 0, "ptr", 0)
        }
    }
}

ForceTerminateProcesses(procNames) {
    for procName in procNames {
        loop 20 {
            if !ProcessClose(procName)
                break
        }
    }
}

ShowLaunchOnExitMenu() {
    global launchMenuX, launchMenuY
    rect := Buffer(16)
    DllCall("GetWindowRect", "ptr", btnLaunchOnExit.Hwnd, "ptr", rect)
    launchMenuX := NumGet(rect, 0, "int")
    launchMenuY := NumGet(rect, 12, "int")
    OpenLaunchOnExitMenu()
}

OpenLaunchOnExitMenu() {
    CoordMode("Menu", "Screen")
    launchOnExitMenu.Show(launchMenuX, launchMenuY)
}

ToggleLaunchOnExitApp(key, *) {
    global launchOnExitSelected
    launchOnExitSelected[key] := !launchOnExitSelected[key]
    RefreshLaunchOnExitUI()
    SaveLaunchOnExit()
    SetTimer(OpenLaunchOnExitMenu, -10)
}

RefreshLaunchOnExitUI() {
    count := 0
    lastName := ""
    for app in launchOnExitApps {
        if launchOnExitSelected[app.key] {
            launchOnExitMenu.Check(app.name)
            count++
            lastName := app.name
        } else
            launchOnExitMenu.Uncheck(app.name)
    }
    btnLaunchOnExit.Text := (count = 0 ? "None" : count = 1 ? lastName : count " apps selected") " " Chr(0x25BE)
}

SaveLaunchOnExit() {
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    sf := SettingsFile()
    for app in launchOnExitApps
        IniWrite(launchOnExitSelected[app.key] ? "1" : "0", sf, "Settings", "LaunchOnExit_" app.key)
}

ParseLaunchCommand(text, &exe, &args) {
    text := Trim(text, " `t")
    exe := text
    args := ""
    if text = ""
        return
    if SubStr(text, 1, 1) = '"' {
        closePos := InStr(text, '"', , 2)
        if closePos {
            exe := SubStr(text, 2, closePos - 2)
            args := Trim(SubStr(text, closePos + 1), " `t")
        } else
            exe := SubStr(text, 2)
        return
    }
    attr := FileExist(text)
    if attr != "" && !InStr(attr, "D") && !RegExMatch(text, "[*?]")
        return
    pos := 0
    while (pos := InStr(text, " ", , pos + 1)) {
        candidate := RTrim(SubStr(text, 1, pos - 1), " `t")
        if candidate = "" || RegExMatch(candidate, "[*?]")
            continue
        attr := FileExist(candidate)
        if attr != "" && !InStr(attr, "D") {
            exe := candidate
            args := Trim(SubStr(text, pos + 1), " `t")
            return
        }
    }
    if RegExMatch(text, "i)^(.*?\.(?:exe|lnk|bat|cmd|com))(?:\s+(.*))?$", &m) {
        exe := m[1]
        args := Trim(m[2], " `t")
        return
    }
    sp := InStr(text, " ")
    if sp {
        exe := SubStr(text, 1, sp - 1)
        args := Trim(SubStr(text, sp + 1), " `t")
    }
}

LaunchAppOnExit(exitReason, exitCode) {
    global launchOnExitApps, launchOnExitSelected, suppressLaunchOnExit
    if suppressLaunchOnExit
        return
    if exitReason = "Reload" || exitReason = "Single" || exitReason = "Logoff" || exitReason = "Shutdown"
        return
    try
        SaveLaunchOnExit()
    catch as e
        LogWarn("exit", "SaveLaunchOnExit failed: " e.Message)
    for app in launchOnExitApps {
        if !launchOnExitSelected[app.key]
            continue
        path := Trim(app.path, " `t")
        if path = ""
            continue
        ParseLaunchCommand(path, &exePath, &exeArgs)
        if exePath = ""
            continue
        workDir := ""
        SplitPath(exePath, , &workDir)
        cmd := '"' exePath '"' (exeArgs != "" ? " " exeArgs : "")
        try {
            Run(cmd, DirExist(workDir) ? workDir : "")
        } catch as e {
            LogWarn("exit", cmd ": Run() failed: " e.Message)
            MsgBox("Could not launch:`n" cmd "`n`n" e.Message, "Launch on Exit", "Icon!")
        }
    }
}

SaveMasterEnabled() {
    global masterEnabled
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(masterEnabled ? "1" : "0", SettingsFile(), "Settings", "MasterEnabled")
    } catch as e {
        LogWarn("save", "SaveMasterEnabled: " e.Message)
    }
}

SaveStartHidden() {
    global startHidden
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(startHidden ? "1" : "0", SettingsFile(), "Settings", "StartHidden")
    } catch as e {
        LogWarn("save", "SaveStartHidden: " e.Message)
    }
}

SaveNativeMouseHookSetting() {
    global nativeMouseHookSetting
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(nativeMouseHookSetting, SettingsFile(), "Settings", "NativeMouseHook")
    } catch as e {
        LogWarn("save", "SaveNativeMouseHookSetting: " e.Message)
    }
}

SaveCapsLockLedDeviceIndex() {
    global capsLockLedDeviceIndex
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(capsLockLedDeviceIndex, SettingsFile(), "Settings", "CapsLockLedDeviceIndex")
    } catch as e {
        LogWarn("save", "SaveCapsLockLedDeviceIndex: " e.Message)
    }
}

SaveRunElevated() {
    global runElevated
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        IniWrite(runElevated ? "1" : "0", SettingsFile(), "Settings", "RunElevated")
    } catch as e {
        LogWarn("save", "SaveRunElevated: " e.Message)
    }
}

SaveRunAtStartupSettings() {
    global runAtStartup, runAtStartupMode
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        sf := SettingsFile()
        IniWrite(runAtStartup ? "1" : "0", sf, "Settings", "RunAtStartup")
        IniWrite(runAtStartupMode, sf, "Settings", "RunAtStartupMode")
    } catch as e {
        LogWarn("save", "SaveRunAtStartupSettings: " e.Message)
    }
}

SaveLedSettingsForTag(tag, whichMod) {
    global ledIndicatorChoiceByTag, ledIndicatorChoiceByTag2
    global lockFlashEnabledByTagSlot, lockFlashIntervalMsByTagSlot
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    sf := SettingsFile()
    suffix := whichMod = 2 ? "2" : ""
    slot := whichMod = 2 ? 2 : 1
    choiceMap := whichMod = 2 ? ledIndicatorChoiceByTag2 : ledIndicatorChoiceByTag
    try {
        IniWrite(choiceMap[tag], sf, "Settings", "LedIndicatorChoice" suffix "_" tag)
        IniWrite(lockFlashEnabledByTagSlot["ScrollLock"][tag][slot] ? "1" : "0", sf, "Settings", "ScrollLockFlashEnabled" suffix "_" tag)
        IniWrite(lockFlashIntervalMsByTagSlot["ScrollLock"][tag][slot], sf, "Settings", "ScrollLockFlashIntervalMs" suffix "_" tag)
        IniWrite(lockFlashEnabledByTagSlot["CapsLock"][tag][slot] ? "1" : "0", sf, "Settings", "CapsLockFlashEnabled" suffix "_" tag)
        IniWrite(lockFlashIntervalMsByTagSlot["CapsLock"][tag][slot], sf, "Settings", "CapsLockFlashIntervalMs" suffix "_" tag)
        IniWrite(lockFlashEnabledByTagSlot["NumLock"][tag][slot] ? "1" : "0", sf, "Settings", "NumLockFlashEnabled" suffix "_" tag)
        IniWrite(lockFlashIntervalMsByTagSlot["NumLock"][tag][slot], sf, "Settings", "NumLockFlashIntervalMs" suffix "_" tag)
    } catch as e {
        LogWarn("save", "SaveLedSettingsForTag(" tag ", " whichMod "): " e.Message)
    }
}
