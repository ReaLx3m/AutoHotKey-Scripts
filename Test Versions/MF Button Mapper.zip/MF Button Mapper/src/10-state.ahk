
global g_hiResTimerRefCount := 0

global ownWindowRects := Map()
