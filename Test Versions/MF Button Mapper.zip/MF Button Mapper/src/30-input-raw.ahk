
RegisterAllRawInputDevices() {
    global g_lastDeviceCount, g_lastEntryCount, g_regLog
    g_regLog := []
    hwnd := g.Hwnd
    count := 0
    DllCall("GetRawInputDeviceList", "ptr", 0, "uint*", &count, "uint", 16, "int")
    g_lastDeviceCount := count
    if count = 0
        return 0
    listBuf := Buffer(count * 16, 0)
    got := DllCall("GetRawInputDeviceList", "ptr", listBuf, "uint*", &count, "uint", 16, "int")
    if got = -1
        return 0

    seen := Map()
    entries := []
    loop count {
        off := (A_Index - 1) * 16
        hDevice := NumGet(listBuf, off, "Ptr")
        dwType := NumGet(listBuf, off + 8, "UInt")
        info := GetRawDeviceInfo(hDevice)
        if !info
            continue
        if info.usagePage = 0x01 && info.usage = 0x06 {
            continue
        }
        k := info.usagePage "_" info.usage
        if seen.Has(k)
            continue
        seen[k] := true
        entries.Push(info)
    }
    g_lastEntryCount := entries.Length
    if entries.Length = 0
        return 0

    okCount := 0
    for e in entries {
        rid := Buffer(16, 0)
        NumPut("UShort", e.usagePage, rid, 0)
        NumPut("UShort", e.usage, rid, 2)
        NumPut("UInt", RIDEV_INPUTSINK, rid, 4)
        NumPut("Ptr", hwnd, rid, 8)
        ok := DllCall("RegisterRawInputDevices", "ptr", rid, "uint", 1, "uint", 16, "int")
        tag := Format("Page:0x{:X} Usage:0x{:X}", e.usagePage, e.usage)
        if ok {
            okCount++
            g_regLog.Push(NowStamp() " [Registered] " tag)
        } else {
            g_regLog.Push(NowStamp() " [FAILED] " tag " LastError:" A_LastError)
        }
    }
    return okCount
}

HandleRawModifierDown(page, bytesNorm) {
    global activeProfileNameByTab, DEVICE_TAGS
    global mod1HeldByTag, mod2HeldByTag
    global mod1ArmedRawByTag, mod2ArmedRawByTag
    global mod1ComboUsedByTag, mod2ComboUsedByTag
    global modLpPhysDownByTag, modLpTokenByTag, modPairStateByTag, modLpPendingRawByTag
    MarkHeldModifiersComboUsed()
    matchedTag := ""
    for tag in DEVICE_TAGS {
        effMod := EffectiveModifier(activeProfileNameByTab[tag], tag)
        effMod2 := EffectiveModifier2(activeProfileNameByTab[tag], tag)
        pairLong := TapLongPairOf(effMod, effMod2)
        isPair := pairLong != "" && effMod.kind = "raw" && page = effMod.rawPage && bytesNorm = effMod.rawBytesHex
        if !isPair && effMod.kind = "raw" && page = effMod.rawPage && bytesNorm = effMod.rawBytesHex {
            if effMod.lpOn && effMod.rawUpBytesHex != "" {
                modLpPhysDownByTag[tag].Mod := true
                lpToken := ++modLpTokenByTag[tag].Mod
                modLpPendingRawByTag[tag].Mod := {page: effMod.rawPage, upBytesHex: effMod.rawUpBytesHex}
                SetTimer(CheckModLongPressRaw.Bind(tag, "Mod", effMod.mode, lpToken, effMod.rawPage, effMod.rawUpBytesHex), -Max(1, effMod.lpMs))
            } else if effMod.mode = "hold" && effMod.rawUpBytesHex != "" {
                mod1HeldByTag[tag] := true
                mod1ComboUsedByTag[tag] := false
                mod1ArmedRawByTag[tag] := {page: effMod.rawPage, upBytesHex: effMod.rawUpBytesHex}
                RecomputeHeldActiveList(tag)
            } else {
                ToggleLatched(tag, "Mod")
                NotifyModifierToggled(tag)
            }
            matchedTag := tag
        }
        if !isPair && effMod2.kind = "raw" && page = effMod2.rawPage && bytesNorm = effMod2.rawBytesHex {
            resolvedMode2 := ResolvedMod2ModeOf(effMod, effMod2)
            if effMod2.lpOn && effMod2.rawUpBytesHex != "" {
                modLpPhysDownByTag[tag].Mod2 := true
                lpToken2 := ++modLpTokenByTag[tag].Mod2
                modLpPendingRawByTag[tag].Mod2 := {page: effMod2.rawPage, upBytesHex: effMod2.rawUpBytesHex}
                SetTimer(CheckModLongPressRaw.Bind(tag, "Mod2", resolvedMode2, lpToken2, effMod2.rawPage, effMod2.rawUpBytesHex), -Max(1, effMod2.lpMs))
            } else if resolvedMode2 = "hold" && effMod2.rawUpBytesHex != "" {
                mod2HeldByTag[tag] := true
                mod2ComboUsedByTag[tag] := false
                mod2ArmedRawByTag[tag] := {page: effMod2.rawPage, upBytesHex: effMod2.rawUpBytesHex}
                RecomputeHeldActiveList(tag)
            } else {
                ToggleLatched(tag, "Mod2")
                NotifyModifierToggled(tag)
            }
            matchedTag := tag
        }
        if isPair {
            pairMs := (pairLong = "Mod") ? effMod.lpMs : effMod2.lpMs
            modLpPhysDownByTag[tag].%pairLong% := true
            modLpTokenByTag[tag].%pairLong% += 1
            pairToken := modLpTokenByTag[tag].%pairLong%
            modLpPendingRawByTag[tag].%pairLong% := {page: effMod.rawPage, upBytesHex: effMod.rawUpBytesHex}
            modPairStateByTag[tag].long := pairLong
            modPairStateByTag[tag].fired := false
            SetTimer(CheckPairLongRaw.Bind(tag, pairLong, pairToken), -Max(1, pairMs))
            matchedTag := tag
        }
    }
    return matchedTag
}

HandleRawModifierUp(page, bytesNorm) {
    global activeProfileNameByTab, DEVICE_TAGS
    global mod1HeldByTag, mod2HeldByTag
    global mod1ArmedRawByTag, mod2ArmedRawByTag
    global modLpPhysDownByTag, modPairStateByTag, modLpPendingRawByTag
    releasedTag := ""
    for tag in DEVICE_TAGS {
        for which in ["Mod", "Mod2"] {
            pend := modLpPendingRawByTag[tag].%which%
            if IsObject(pend) && modLpPhysDownByTag[tag].%which% && page = pend.page && bytesNorm = pend.upBytesHex {
                modLpPhysDownByTag[tag].%which% := false
                modLpPendingRawByTag[tag].%which% := ""
                releasedTag := tag
            }
        }
        effMod := EffectiveModifier(activeProfileNameByTab[tag], tag)
        effMod2 := EffectiveModifier2(activeProfileNameByTab[tag], tag)
        pst := modPairStateByTag[tag]
        if pst.long != "" && effMod.kind = "raw" && effMod.rawUpBytesHex != "" && page = effMod.rawPage && bytesNorm = effMod.rawUpBytesHex {
            pairWhich := pst.long
            pairWasFired := pst.fired
            pst.long := ""
            pst.fired := false
            modLpPhysDownByTag[tag].%pairWhich% := false
            if !pairWasFired
                PairShortAction(tag, pairWhich)
            releasedTag := tag
        }
        armed1 := mod1ArmedRawByTag[tag]
        if mod1HeldByTag[tag] && armed1.upBytesHex != "" && page = armed1.page && bytesNorm = armed1.upBytesHex {
            modLpPhysDownByTag[tag].Mod := false
            mod1HeldByTag[tag] := false
            mod1ArmedRawByTag[tag] := {page: 0, upBytesHex: ""}
            RecomputeHeldActiveList(tag)
            releasedTag := tag
        } else if effMod.kind = "raw" && effMod.mode = "hold" && effMod.rawUpBytesHex != "" && page = effMod.rawPage && bytesNorm = effMod.rawUpBytesHex {
            modLpPhysDownByTag[tag].Mod := false
            mod1HeldByTag[tag] := false
            mod1ArmedRawByTag[tag] := {page: 0, upBytesHex: ""}
            RecomputeHeldActiveList(tag)
            releasedTag := tag
        } else if effMod.kind = "raw" && effMod.mode = "toggle" && effMod.rawUpBytesHex != "" && page = effMod.rawPage && bytesNorm = effMod.rawUpBytesHex {
            modLpPhysDownByTag[tag].Mod := false
            releasedTag := tag
        }
        armed2 := mod2ArmedRawByTag[tag]
        if mod2HeldByTag[tag] && armed2.upBytesHex != "" && page = armed2.page && bytesNorm = armed2.upBytesHex {
            modLpPhysDownByTag[tag].Mod2 := false
            mod2HeldByTag[tag] := false
            mod2ArmedRawByTag[tag] := {page: 0, upBytesHex: ""}
            RecomputeHeldActiveList(tag)
            releasedTag := tag
        } else if effMod2.kind = "raw" && effMod2.rawUpBytesHex != "" && page = effMod2.rawPage && bytesNorm = effMod2.rawUpBytesHex {
            modLpPhysDownByTag[tag].Mod2 := false
            if ResolvedMod2ModeOf(effMod, effMod2) = "hold" {
                mod2HeldByTag[tag] := false
                mod2ArmedRawByTag[tag] := {page: 0, upBytesHex: ""}
                RecomputeHeldActiveList(tag)
            }
            releasedTag := tag
        }
    }
    return releasedTag
}

OnRawInput(wParam, lParam, msg, hwnd) {
    global mapOrder, mappings, masterEnabled
    global rawCaptureArmed, capturedRawPage, capturedRawBytesHex, lastCaptureKind, capturedSC
    global capturedRawUpBytesHex, rawCaptureAwaitingRelease, rawCaptureDownHDevice, rawCaptureDownTick, rawCaptureReleaseWindowToken, RawCaptureReleaseWindowMs, MinHoldReleaseGapMs
    global activeListByTag
    global modRawCaptureArmedBySlot, modRawCaptureAwaitingReleaseBySlot
    global modRawCaptureDownHDeviceBySlot, modRawCaptureDownTickBySlot, modRawCaptureReleaseWindowTokenBySlot
    global modCaptureTagBySlot, editingDevTab
    global deviceModifiersBySlot
    global profileModRawCaptureArmedBySlot, profileModCaptureCallbackBySlot, profileModCaptureStatusCallbackBySlot
    global profileModRawCaptureAwaitingReleaseBySlot, profileModRawCaptureDownHDeviceBySlot, profileModRawCaptureDownTickBySlot
    global profileModRawCaptureDownPageBySlot, profileModRawCaptureDownBytesHexBySlot, profileModRawCaptureReleaseWindowTokenBySlot
    global rawMapCaptureArmed, rawMapCaptureExpectedPage, rawMapCaptureExpectedBytesHex, rawMapCaptureCallback, rawMapCaptureStatusCallback
    global rawMapCaptureAwaitingRelease, rawMapCaptureDownHDevice, rawMapCaptureDownTick, rawMapCaptureReleaseWindowToken
    cbHeader := 8 + (A_PtrSize * 2)
    size := 0
    DllCall("GetRawInputData", "ptr", lParam, "uint", 0x10000003, "ptr", 0, "uint*", &size, "uint", cbHeader, "int")
    if size = 0
        return
    buf := Buffer(size, 0)
    got := DllCall("GetRawInputData", "ptr", lParam, "uint", 0x10000003, "ptr", buf, "uint*", &size, "uint", cbHeader, "int")
    if got != size
        return
    dwType := NumGet(buf, 0, "UInt")
    hDevice := NumGet(buf, 8, "Ptr")
    line := ""
    rowData := ""
    if dwType = 1 {
        base := cbHeader
        makeCode := NumGet(buf, base, "UShort")
        flags := NumGet(buf, base + 2, "UShort")
        vkey := NumGet(buf, base + 6, "UShort")
        if flags & 1
            return
        line := Format("[Keyboard] MakeCode:0x{:X} VKey:0x{:X} Flags:0x{:X}", makeCode, vkey, flags)
    } else if dwType = 0 {
        base := cbHeader
        usButtonFlags := NumGet(buf, base + 4, "UShort")
        if usButtonFlags = 0
            return
        info := {usagePage: 0x01, usage: 0x02}
        bytesNorm := ""
        line := ""
        isButtonUpReport := false
        upBytesHexForCapture := ""
        if usButtonFlags & 0x0800 {
            wheelDelta := NumGet(buf, base + 6, "Short")
            bytesNorm := WheelBytesForDelta("H", wheelDelta)
            if bytesNorm = ""
                return
            line := Format("[Mouse] Wheel Tilt {} (Delta:{})", wheelDelta > 0 ? "Right" : "Left", wheelDelta)
        } else if usButtonFlags & 0x0400 {
            wheelDelta := NumGet(buf, base + 6, "Short")
            bytesNorm := WheelBytesForDelta("V", wheelDelta)
            if bytesNorm = ""
                return
            line := Format("[Mouse] Wheel Scroll {} (Delta:{})", wheelDelta > 0 ? "Up" : "Down", wheelDelta)
        } else {
            downFlags := usButtonFlags & 0x0155
            upFlags := usButtonFlags & 0x02AA
            if downFlags = 0 && upFlags = 0
                return
            if downFlags != 0 {
                names := []
                if downFlags & 0x0001
                    names.Push("Left")
                if downFlags & 0x0004
                    names.Push("Right")
                if downFlags & 0x0010
                    names.Push("Middle")
                if downFlags & 0x0040
                    names.Push("Button4")
                if downFlags & 0x0100
                    names.Push("Button5")
                bytesNorm := Format("{:04X}", downFlags)
                line := Format("[Mouse] Page:0x01 Usage:0x02 Button: {} (Flags:0x{:04X})", names.Length ? StrJoin(names, "+") : "?", downFlags)
                upBytesHexForCapture := Format("{:04X}", downFlags << 1)
            } else {
                isButtonUpReport := true
                names := []
                if upFlags & 0x0002
                    names.Push("Left")
                if upFlags & 0x0008
                    names.Push("Right")
                if upFlags & 0x0020
                    names.Push("Middle")
                if upFlags & 0x0080
                    names.Push("Button4")
                if upFlags & 0x0200
                    names.Push("Button5")
                bytesNorm := Format("{:04X}", upFlags)
                line := Format("[Mouse] Page:0x01 Usage:0x02 Button Released: {} (Flags:0x{:04X})", names.Length ? StrJoin(names, "+") : "?", upFlags)
            }
        }
        rowData := {page: info.usagePage, bytesHex: bytesNorm, stdMouse: true}
        if MouseReplayRawShouldIgnore(bytesNorm, isButtonUpReport, hDevice)
            return
        if isButtonUpReport {
            if HandleRawModifierUp(info.usagePage, bytesNorm) != ""
                RefreshModifierLiveIndicator()
        } else {
            if rawCaptureArmed {
                if IsObject(txtCaptureStatus)
                    txtCaptureStatus.Value := "That was a standard mouse button/wheel - use `"Capture`" for those. Still waiting for a vendor HID button..."
                LogRawSniffEvent(line, rowData)
                return
            }
            for slot in ["Mod", "Mod2"] {
                if !modRawCaptureArmedBySlot[slot]
                    continue
                modRawCaptureArmedBySlot[slot] := false
                dmMap := deviceModifiersBySlot[slot]
                capTag := modCaptureTagBySlot[slot] != "" ? modCaptureTagBySlot[slot] : editingDevTab
                oldDm := dmMap.Has(capTag) ? dmMap[capTag] : ""
                newMode := (slot = "Mod") ? (oldDm != "" ? oldDm.mode : "toggle") : Mod2StoredMode(oldDm)
                dmMap[capTag] := {kind: "raw", sc: 0, rawPage: info.usagePage, rawBytesHex: bytesNorm, rawUpBytesHex: upBytesHexForCapture, mode: newMode, lpOn: ModLpOn(oldDm), lpMs: ModLpMs(oldDm)}
                if slot = "Mod" {
                    if IsObject(txtModifierStatus) {
                        RefreshModifierStatusText(capTag)
                        UpdateModifierModeUI(capTag)
                    }
                    RegisterDeviceModifierHotkey(capTag)
                    SaveModifierSettingsForTag(capTag)
                } else {
                    if IsObject(txtModifierStatus2)
                        UpdateMod2UI(capTag)
                    ResetModifierStateForTag(capTag)
                    RefreshModifierLiveIndicator()
                    SaveModifier2SettingsForTag(capTag)
                }
                LogRawSniffEvent(line, rowData)
                return
            }
            for slot in ["Mod", "Mod2"] {
                if !profileModRawCaptureArmedBySlot[slot]
                    continue
                profileModRawCaptureArmedBySlot[slot] := false
                if IsObject(profileModCaptureCallbackBySlot[slot])
                    profileModCaptureCallbackBySlot[slot].Call(info.usagePage, bytesNorm, upBytesHexForCapture)
                profileModCaptureCallbackBySlot[slot] := ""
                profileModCaptureStatusCallbackBySlot[slot] := ""
                ResumeProfileModifierHotkeysIfNeededForSlot(slot)
                LogRawSniffEvent(line, rowData)
                return
            }
            if rawMapCaptureArmed {
                if info.usagePage != rawMapCaptureExpectedPage || bytesNorm != rawMapCaptureExpectedBytesHex {
                    if IsObject(rawMapCaptureStatusCallback)
                        rawMapCaptureStatusCallback.Call(Format("That was a different button (Page:0x{:X} Bytes:{}) - press the SAME button that generated the selected line (Page:0x{:X} Bytes:{}).", info.usagePage, bytesNorm, rawMapCaptureExpectedPage, rawMapCaptureExpectedBytesHex))
                } else {
                    rawMapCaptureArmed := false
                    CompleteRawMapCaptureConfig(upBytesHexForCapture)
                }
                LogRawSniffEvent(line, rowData)
                return
            }
            matchedTag := HandleRawModifierDown(info.usagePage, bytesNorm)
            if matchedTag != "" {
                RefreshModifierLiveIndicator()
                LogRawSniffEvent(line, rowData)
                return
            }
        }
    } else if dwType = 2 {
        base := cbHeader
        dwSizeHid := NumGet(buf, base, "UInt")
        dataOff := base + 8
        info := GetRawDeviceInfo(hDevice)
        bytes := ""
        loop dwSizeHid
            bytes .= Format("{:02X} ", NumGet(buf, dataOff + A_Index - 1, "UChar"))
        bytesNorm := StrReplace(Trim(bytes), " ", "")
        pageStr := info ? Format("Page:0x{:X} Usage:0x{:X}", info.usagePage, info.usage) : "Page:?"
        line := "[HID] " pageStr " Bytes: " Trim(bytes)
        if info {
            rowData := {page: info.usagePage, bytesHex: bytesNorm}
            if rawCaptureAwaitingRelease && hDevice = rawCaptureDownHDevice {
                if bytesNorm != capturedRawBytesHex {
                    if IsGenuineHoldRelease(rawCaptureDownTick) {
                        capturedRawUpBytesHex := bytesNorm
                        rawCaptureAwaitingRelease := false
                        if IsObject(txtCaptureStatus) {
                            txtCaptureStatus.Value := Format("Captured: Page:0x{:X} Bytes:{} - hold capable", capturedRawPage, capturedRawBytesHex)
                            ReconcileMainHoldDdls()
                        }
                    } else if IsObject(txtCaptureStatus)
                        txtCaptureStatus.Value := Format("Captured: Page:0x{:X} Bytes:{} - release came too fast (<{}ms), ignoring - hold/release the button now to enable hold support...", capturedRawPage, capturedRawBytesHex, MinHoldReleaseGapMs)
                }
                LogRawSniffEvent(line, rowData)
                return
            }
            if rawCaptureArmed {
                rawCaptureArmed := false
                capturedRawPage := info.usagePage
                capturedRawBytesHex := bytesNorm
                capturedRawUpBytesHex := ""
                lastCaptureKind := "raw"
                capturedSC := 0
                rawCaptureAwaitingRelease := true
                rawCaptureDownHDevice := hDevice
                rawCaptureDownTick := A_TickCount
                windowToken := ++rawCaptureReleaseWindowToken
                SetTimer(() => FinalizeRawCapture(windowToken), -RawCaptureReleaseWindowMs)
                if IsObject(txtCaptureStatus) {
                    txtCaptureStatus.Value := Format("Captured: Page:0x{:X} Bytes:{} - hold/release the button now to enable hold support...", info.usagePage, bytesNorm)
                    ReconcileMainHoldDdls()
                }
                LogRawSniffEvent(line, rowData)
                return
            }
            for step in [["Mod", "await"], ["Mod", "arm"], ["Mod2", "await"], ["Mod2", "arm"]] {
                slot := step[1]
                statusCtrl := (slot = "Mod2") ? txtModifierStatus2 : txtModifierStatus
                label := (slot = "Mod2") ? "Mod 2" : "Modifier"
                if step[2] = "await" {
                    if !modRawCaptureAwaitingReleaseBySlot[slot] || hDevice != modRawCaptureDownHDeviceBySlot[slot]
                        continue
                    awaitTag := modCaptureTagBySlot[slot] != "" ? modCaptureTagBySlot[slot] : editingDevTab
                    awaitDm := deviceModifiersBySlot[slot][awaitTag]
                    if bytesNorm != awaitDm.rawBytesHex {
                        if IsGenuineHoldRelease(modRawCaptureDownTickBySlot[slot]) {
                            awaitDm.rawUpBytesHex := bytesNorm
                            modRawCaptureAwaitingReleaseBySlot[slot] := false
                            CompleteModifierRawCaptureConfigForSlot(slot)
                        } else if IsObject(statusCtrl)
                            statusCtrl.Value := Format("{}: Raw Page:0x{:X} Bytes:{} - release came too fast (<{}ms), ignoring - hold/release the button now to enable Held mode...", label, awaitDm.rawPage, awaitDm.rawBytesHex, MinHoldReleaseGapMs)
                    }
                    LogRawSniffEvent(line, rowData)
                    return
                } else {
                    if !modRawCaptureArmedBySlot[slot]
                        continue
                    modRawCaptureArmedBySlot[slot] := false
                    dmMap := deviceModifiersBySlot[slot]
                    capTag := modCaptureTagBySlot[slot] != "" ? modCaptureTagBySlot[slot] : editingDevTab
                    oldDm := dmMap.Has(capTag) ? dmMap[capTag] : ""
                    newMode := (slot = "Mod") ? (oldDm != "" ? oldDm.mode : "toggle") : Mod2StoredMode(oldDm)
                    dmMap[capTag] := {kind: "raw", sc: 0, rawPage: info.usagePage, rawBytesHex: bytesNorm, rawUpBytesHex: "", mode: newMode, lpOn: ModLpOn(oldDm), lpMs: ModLpMs(oldDm)}
                    modRawCaptureAwaitingReleaseBySlot[slot] := true
                    modRawCaptureDownHDeviceBySlot[slot] := hDevice
                    modRawCaptureDownTickBySlot[slot] := A_TickCount
                    windowToken := ++modRawCaptureReleaseWindowTokenBySlot[slot]
                    SetTimer(() => FinalizeModifierRawCaptureForSlot(windowToken, slot), -RawCaptureReleaseWindowMs)
                    if IsObject(statusCtrl)
                        statusCtrl.Value := Format("{}: Raw Page:0x{:X} Bytes:{} - hold/release the button now to enable Held mode...", label, info.usagePage, bytesNorm)
                    LogRawSniffEvent(line, rowData)
                    return
                }
            }
            for slot in ["Mod", "Mod2"] {
                if !profileModRawCaptureAwaitingReleaseBySlot[slot] || hDevice != profileModRawCaptureDownHDeviceBySlot[slot]
                    continue
                if bytesNorm != profileModRawCaptureDownBytesHexBySlot[slot] {
                    if IsGenuineHoldRelease(profileModRawCaptureDownTickBySlot[slot]) {
                        profileModRawCaptureAwaitingReleaseBySlot[slot] := false
                        CompleteProfileModifierRawCaptureConfigForSlot(bytesNorm, slot)
                    } else if IsObject(profileModCaptureStatusCallbackBySlot[slot])
                        profileModCaptureStatusCallbackBySlot[slot].Call(Format("Modifier: Raw Page:0x{:X} Bytes:{} - release came too fast (<{}ms), ignoring - hold/release the button now to enable Held mode...", profileModRawCaptureDownPageBySlot[slot], profileModRawCaptureDownBytesHexBySlot[slot], MinHoldReleaseGapMs))
                }
                LogRawSniffEvent(line, rowData)
                return
            }
            if rawMapCaptureAwaitingRelease && hDevice = rawMapCaptureDownHDevice {
                if bytesNorm != rawMapCaptureExpectedBytesHex {
                    rawMapCaptureAwaitingRelease := false
                    if IsGenuineHoldRelease(rawMapCaptureDownTick)
                        CompleteRawMapCaptureConfig(bytesNorm)
                    else
                        CompleteRawMapCaptureConfig("")
                }
                LogRawSniffEvent(line, rowData)
                return
            }
            for slot in ["Mod", "Mod2"] {
                if !profileModRawCaptureArmedBySlot[slot]
                    continue
                profileModRawCaptureArmedBySlot[slot] := false
                profileModRawCaptureDownPageBySlot[slot] := info.usagePage
                profileModRawCaptureDownBytesHexBySlot[slot] := bytesNorm
                profileModRawCaptureAwaitingReleaseBySlot[slot] := true
                profileModRawCaptureDownHDeviceBySlot[slot] := hDevice
                profileModRawCaptureDownTickBySlot[slot] := A_TickCount
                windowToken := ++profileModRawCaptureReleaseWindowTokenBySlot[slot]
                SetTimer(() => FinalizeProfileModifierRawCaptureForSlot(windowToken, slot), -RawCaptureReleaseWindowMs)
                if IsObject(profileModCaptureStatusCallbackBySlot[slot])
                    profileModCaptureStatusCallbackBySlot[slot].Call(Format("Modifier: Raw Page:0x{:X} Bytes:{} - hold/release the button now to enable Held mode...", info.usagePage, bytesNorm))
                LogRawSniffEvent(line, rowData)
                return
            }
            if rawMapCaptureArmed {
                if info.usagePage != rawMapCaptureExpectedPage || bytesNorm != rawMapCaptureExpectedBytesHex {
                    if IsObject(rawMapCaptureStatusCallback)
                        rawMapCaptureStatusCallback.Call(Format("That was a different event (Page:0x{:X} Bytes:{}) - press the SAME button that generated the selected line (Page:0x{:X} Bytes:{}).", info.usagePage, bytesNorm, rawMapCaptureExpectedPage, rawMapCaptureExpectedBytesHex))
                } else {
                    rawMapCaptureArmed := false
                    rawMapCaptureAwaitingRelease := true
                    rawMapCaptureDownHDevice := hDevice
                    rawMapCaptureDownTick := A_TickCount
                    windowToken := ++rawMapCaptureReleaseWindowToken
                    SetTimer(() => FinalizeRawMapCapture(windowToken), -RawCaptureReleaseWindowMs)
                    if IsObject(rawMapCaptureStatusCallback)
                        rawMapCaptureStatusCallback.Call(Format("Page:0x{:X} Bytes:{} - hold/release the button now to enable hold support...", info.usagePage, bytesNorm))
                }
                LogRawSniffEvent(line, rowData)
                return
            }
            matchedTag := HandleRawModifierDown(info.usagePage, bytesNorm)
            releasedTag := HandleRawModifierUp(info.usagePage, bytesNorm)
            if matchedTag != "" || releasedTag != "" {
                RefreshModifierLiveIndicator()
                LogRawSniffEvent(line, rowData)
                return
            }
            rawButtonKey := MakeRawButtonKey(info.usagePage, bytesNorm)
            downUpBytes := FindRawMappingUpBytes(info.usagePage, bytesNorm)
            if downUpBytes != "" {
                if masterEnabled
                    OnButtonDown(rawButtonKey, "raw")
            } else {
                upDownBytes := FindRawMappingDownBytesForUp(info.usagePage, bytesNorm)
                if upDownBytes != "" {
                    if masterEnabled
                        OnButtonUp(MakeRawButtonKey(info.usagePage, upDownBytes), "raw")
                } else {
                    devTab := DevTabForButtonKey(rawButtonKey, "raw")
                    activeList := activeListByTag[devTab]
                    effProfile := EffectiveProfileForButton(rawButtonKey, "raw", devTab, activeList)
                    for key in mapOrder {
                        m := mappings[key]
                        if (MapKind(m)) != "raw"
                            continue
                        if (MapProfile(m)) != effProfile
                            continue
                        if effProfile != "Default" && (MapDevTab(m)) != devTab
                            continue
                        if (MapList(m)) != activeList
                            continue
                        if m.page = info.usagePage && m.bytesHex = bytesNorm {
                            if masterEnabled && m.enabled
                                FireMapping(m)
                        }
                    }
                }
            }
        }
    } else {
        return
    }
    LogRawSniffEvent(line, rowData)
}
