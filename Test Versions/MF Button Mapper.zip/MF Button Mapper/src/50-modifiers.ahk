
MarkHeldModifiersComboUsed() {
    global DEVICE_TAGS, mod1HeldByTag, mod2HeldByTag, mod1ComboUsedByTag, mod2ComboUsedByTag
    for tag in DEVICE_TAGS {
        if mod1HeldByTag[tag]
            mod1ComboUsedByTag[tag] := true
        if mod2HeldByTag[tag]
            mod2ComboUsedByTag[tag] := true
    }
}

CancelPendingProfileModifierCaptureForSlot(slot) {
    global profileModCaptureHookBySlot, profileModRawCaptureArmedBySlot, profileModCaptureCallbackBySlot
    global profileModCaptureStatusCallbackBySlot, profileModRawCaptureAwaitingReleaseBySlot
    if IsObject(profileModCaptureHookBySlot[slot]) {
        try profileModCaptureHookBySlot[slot].Stop()
        profileModCaptureHookBySlot[slot] := ""
    }
    profileModRawCaptureArmedBySlot[slot] := false
    profileModRawCaptureAwaitingReleaseBySlot[slot] := false
    profileModCaptureCallbackBySlot[slot] := ""
    profileModCaptureStatusCallbackBySlot[slot] := ""
    CancelModifierMouseCapture(slot = "Mod" ? "pmod1" : "pmod2")
    ResumeProfileModifierHotkeysIfNeededForSlot(slot)
}

CancelPendingProfileModifierCapture() {
    CancelPendingProfileModifierCaptureForSlot("Mod")
}

CancelPendingProfileModifier2Capture() {
    CancelPendingProfileModifierCaptureForSlot("Mod2")
}

ProfileModifierMouseCapturedForSlot(buttonKey, applyFn, slot) {
    global profileModCaptureHookBySlot
    if !(IsObject(profileModCaptureHookBySlot[slot]) && profileModCaptureHookBySlot[slot].InProgress)
        return
    try profileModCaptureHookBySlot[slot].Stop()
    profileModCaptureHookBySlot[slot] := ""
    raw := StdMouseRawReportFromButton(buttonKey)
    if IsObject(raw)
        applyFn.Call(raw.page, raw.bytesHex, raw.upBytesHex)
    ResumeProfileModifierHotkeysIfNeededForSlot(slot)
}

ResumeProfileModifierHotkeysIfNeededForSlot(slot) {
    global profileModCaptureSuspendedBySlot
    if profileModCaptureSuspendedBySlot[slot] {
        DecrementCaptureSuspend()
        profileModCaptureSuspendedBySlot[slot] := false
    }
}

ResumeProfileModifierHotkeysIfNeeded() {
    ResumeProfileModifierHotkeysIfNeededForSlot("Mod")
}

ResumeProfileModifier2HotkeysIfNeeded() {
    ResumeProfileModifierHotkeysIfNeededForSlot("Mod2")
}

EffectiveModifier(profileName, devTab) {
    global profiles, deviceModifiers
    pk := ProfileKey(devTab, profileName)
    if profiles.Has(pk) {
        p := profiles[pk]
        pTag := ProfDevTabForMatch(p)
        if pTag = devTab {
            pk := ProfModKind(p)
            if pk != "none" && pk != ""
                return {kind: pk
                    , sc: ProfModSc(p)
                    , rawPage: p.HasOwnProp("modRawPage") ? p.modRawPage : 0
                    , rawBytesHex: p.HasOwnProp("modRawBytesHex") ? p.modRawBytesHex : ""
                    , rawUpBytesHex: p.HasOwnProp("modRawUpBytesHex") ? p.modRawUpBytesHex : ""
                    , mode: Mod1ModeOf(p)
                    , lpOn: LpOnOf(p, "modLpOn")
                    , lpMs: LpMsOf(p, "modLpMs")}
        }
    }
    return deviceModifiers[devTab]
}

EffectiveModifier2(profileName, devTab) {
    global profiles, deviceModifiers2
    pk := ProfileKey(devTab, profileName)
    if profiles.Has(pk) {
        p := profiles[pk]
        pTag := ProfDevTabForMatch(p)
        if pTag = devTab {
            pk2 := ProfMod2Kind(p)
            if pk2 != "none" && pk2 != ""
                return {kind: pk2
                    , sc: ProfMod2Sc(p)
                    , rawPage: p.HasOwnProp("mod2RawPage") ? p.mod2RawPage : 0
                    , rawBytesHex: p.HasOwnProp("mod2RawBytesHex") ? p.mod2RawBytesHex : ""
                    , rawUpBytesHex: p.HasOwnProp("mod2RawUpBytesHex") ? p.mod2RawUpBytesHex : ""
                    , mode: StoredModeOf(p, "mod2Mode")
                    , lpOn: LpOnOf(p, "mod2LpOn")
                    , lpMs: LpMsOf(p, "mod2LpMs")}
        }
    }
    return deviceModifiers2[devTab]
}

LpOnOf(obj, prop) => (IsObject(obj) && obj.HasOwnProp(prop) && obj.%prop% = 1) ? true : false

LpMsOf(obj, prop) {
    if IsObject(obj) && obj.HasOwnProp(prop) {
        v := obj.%prop%
        if IsInteger(v) && Integer(v) >= 1
            return Integer(v)
    }
    return 500
}

StoredModeOf(obj, prop) {
    if IsObject(obj) && obj.HasOwnProp(prop) {
        v := obj.%prop%
        if v = "hold" || v = "toggle"
            return v
    }
    return ""
}

EffectivePassthroughSetting(pkey, which, devTab) {
    global profiles, deviceModifiers, deviceModifiers2
    field := (which = "Mod2") ? "passthroughMod2" : "passthroughMod1"
    if profiles.Has(pkey) {
        p := profiles[pkey]
        pTag := ProfDevTabForMatch(p)
        if pTag = devTab {
            ownKind := (which = "Mod2") ? ProfMod2Kind(p) : ProfModKind(p)
            if ownKind != "none" && ownKind != ""
                return IsObject(p) && p.HasOwnProp(field) ? !!p.%field% : false
        }
    }
    dm := (which = "Mod2") ? deviceModifiers2[devTab] : deviceModifiers[devTab]
    return ModPtOn(dm)
}

ModLpOn(m) => LpOnOf(m, "lpOn")
ModLpMs(m) => LpMsOf(m, "lpMs")
Mod2StoredMode(m) => StoredModeOf(m, "mode")
ModPtOn(m) => LpOnOf(m, "ptOn")

Mod1ModeOf(obj) => (IsObject(obj) && obj.HasOwnProp("modMode") && obj.modMode != "") ? obj.modMode : "toggle"

ProfModKind(p)  => p.HasOwnProp("modKind") ? p.modKind : "none"
ProfMod2Kind(p) => p.HasOwnProp("mod2Kind") ? p.mod2Kind : "none"
ProfModSc(p)    => p.HasOwnProp("modSc") ? p.modSc : 0
ProfMod2Sc(p)   => p.HasOwnProp("mod2Sc") ? p.mod2Sc : 0

ProfDevTabForMatch(p) => p.HasOwnProp("devTab") ? p.devTab : ""
ProfDevTabOrRemote(p) => p.HasOwnProp("devTab") ? p.devTab : "Remote"

ParseLpMs(val) {
    trimmed := Trim(String(val))
    return (IsInteger(trimmed) && Integer(trimmed) >= 1) ? Integer(trimmed) : 500
}

ProfileModCfgSig(p) {
    return Format("{}|{}|{}|{}|{}|{}"
        , Mod1ModeOf(p)
        , LpOnOf(p, "modLpOn") ? 1 : 0
        , LpMsOf(p, "modLpMs")
        , StoredModeOf(p, "mod2Mode")
        , LpOnOf(p, "mod2LpOn") ? 1 : 0
        , LpMsOf(p, "mod2LpMs"))
}

ResolvedMod2Mode(profileName, devTab) {
    m2mode := Mod2StoredMode(EffectiveModifier2(profileName, devTab))
    if m2mode != ""
        return m2mode
    return EffectiveModifier(profileName, devTab).mode
}

ResolvedMod2ModeOf(m1, m2) {
    m2mode := Mod2StoredMode(m2)
    return (m2mode != "") ? m2mode : m1.mode
}

TapLongPairOf(m1, m2) {
    if m1.kind = "none" || m1.kind != m2.kind
        return ""
    if m1.kind = "sc" {
        if m1.sc != m2.sc
            return ""
    } else if m1.kind = "raw" {
        if m1.rawPage != m2.rawPage || m1.rawBytesHex != m2.rawBytesHex
            return ""
        if m1.rawUpBytesHex = "" || m1.rawUpBytesHex != m2.rawUpBytesHex
            return ""
        if m1.rawUpBytesHex = m1.rawBytesHex
            return ""
    } else {
        return ""
    }
    if m1.mode != "toggle" || ResolvedMod2ModeOf(m1, m2) != "toggle"
        return ""
    lp1 := m1.lpOn ? 1 : 0
    lp2 := m2.lpOn ? 1 : 0
    if lp1 = lp2
        return ""
    return lp1 ? "Mod" : "Mod2"
}

DevTabForButtonKey(buttonKey, kind) {
    global mapOrder, mappings, deviceModifiers, deviceModifiers2, profiles
    for tag, dm in deviceModifiers {
        dmKey := dm.kind = "sc" ? Format("SC{:03X}", dm.sc)
            : (dm.kind = "raw" ? MakeRawButtonKey(dm.rawPage, dm.rawBytesHex) : "")
        if dmKey != "" && dmKey = buttonKey
            return tag
    }
    for tag, dm2 in deviceModifiers2 {
        if dm2.kind = "sc" && Format("SC{:03X}", dm2.sc) = buttonKey
            return tag
    }
    for pkey, p in profiles {
        if !p.HasOwnProp("devTab") || ProfModKind(p) = "none"
            continue
        pKey := p.modKind = "sc" ? Format("SC{:03X}", p.modSc)
            : (p.modKind = "raw" ? MakeRawButtonKey(p.modRawPage, p.modRawBytesHex) : "")
        if pKey != "" && pKey = buttonKey
            return p.devTab
    }
    for pkey, p in profiles {
        if !p.HasOwnProp("devTab") || ProfMod2Kind(p) = "none"
            continue
        pKey2 := p.mod2Kind = "sc" ? Format("SC{:03X}", p.mod2Sc)
            : (p.mod2Kind = "raw" ? MakeRawButtonKey(p.mod2RawPage, p.mod2RawBytesHex) : "")
        if pKey2 != "" && pKey2 = buttonKey
            return p.devTab
    }
    for id in mapOrder {
        m := mappings[id]
        if MapKind(m) != kind
            continue
        if MappingButtonKey(m) = buttonKey
            return MapDevTab(m)
    }
    return DefaultDevTabForKind(kind)
}

FinalizeModifierRawCaptureForSlot(token, slot) {
    global modRawCaptureAwaitingReleaseBySlot, modRawCaptureReleaseWindowTokenBySlot
    if !modRawCaptureAwaitingReleaseBySlot[slot] || token != modRawCaptureReleaseWindowTokenBySlot[slot]
        return
    modRawCaptureAwaitingReleaseBySlot[slot] := false
    CompleteModifierRawCaptureConfigForSlot(slot)
}

CompleteModifierRawCaptureConfigForSlot(slot) {
    global modCaptureTagBySlot, editingDevTab
    tag := modCaptureTagBySlot[slot] != "" ? modCaptureTagBySlot[slot] : editingDevTab
    if (slot = "Mod2") {
        UpdateMod2UI(tag)
    } else {
        RefreshModifierStatusText(tag)
        UpdateModifierModeUI(tag)
    }
    RegisterDeviceModifierHotkeyForSlot(tag, slot)
    if (slot = "Mod2")
        SaveModifier2SettingsForTag(tag)
    else
        SaveModifierSettingsForTag(tag)
}

FinalizeProfileModifierRawCaptureForSlot(token, slot) {
    global profileModRawCaptureAwaitingReleaseBySlot, profileModRawCaptureReleaseWindowTokenBySlot
    if !profileModRawCaptureAwaitingReleaseBySlot[slot] || token != profileModRawCaptureReleaseWindowTokenBySlot[slot]
        return
    profileModRawCaptureAwaitingReleaseBySlot[slot] := false
    CompleteProfileModifierRawCaptureConfigForSlot("", slot)
}

CompleteProfileModifierRawCaptureConfigForSlot(upBytesHex, slot) {
    global profileModCaptureCallbackBySlot, profileModCaptureStatusCallbackBySlot, profileModRawCaptureDownPageBySlot, profileModRawCaptureDownBytesHexBySlot
    if IsObject(profileModCaptureCallbackBySlot[slot])
        profileModCaptureCallbackBySlot[slot].Call(profileModRawCaptureDownPageBySlot[slot], profileModRawCaptureDownBytesHexBySlot[slot], upBytesHex)
    profileModCaptureCallbackBySlot[slot] := ""
    profileModCaptureStatusCallbackBySlot[slot] := ""
    ResumeProfileModifierHotkeysIfNeededForSlot(slot)
}

CompleteProfileModifierRawCaptureConfig(upBytesHex) {
    CompleteProfileModifierRawCaptureConfigForSlot(upBytesHex, "Mod")
}

CompleteProfileModifier2RawCaptureConfig(upBytesHex) {
    CompleteProfileModifierRawCaptureConfigForSlot(upBytesHex, "Mod2")
}

SetCaptureModifierRawModeForSlot(slot, val) {
    global captureModifierRawModeBySlot
    captureModifierRawModeBySlot[slot] := !!val
}

SetCaptureModifierRawMode(val) {
    SetCaptureModifierRawModeForSlot("Mod", val)
}

ResetPendingModifierCaptureStateForSlot(slot) {
    global modCaptureHookBySlot, modRawCaptureArmedBySlot
    if IsObject(modCaptureHookBySlot[slot]) {
        try modCaptureHookBySlot[slot].Stop()
        modCaptureHookBySlot[slot] := ""
    }
    modRawCaptureArmedBySlot[slot] := false
    CancelModifierMouseCapture(slot = "Mod2" ? "mod2" : "mod1")
    ResumeModifierHotkeysIfNeededForSlot(slot)
}

ResetPendingModifierCaptureState() {
    ResetPendingModifierCaptureStateForSlot("Mod")
}

CancelPendingModifierCaptureForSlot(slot) {
    global modCaptureHookBySlot, modCaptureTagBySlot, modRawCaptureArmedBySlot
    if IsObject(modCaptureHookBySlot[slot]) {
        try modCaptureHookBySlot[slot].Stop()
        modCaptureHookBySlot[slot] := ""
    }
    SetTimer((slot = "Mod2") ? ArmModifierRawCapture2 : ArmModifierRawCapture, 0)
    modRawCaptureArmedBySlot[slot] := false
    CancelModifierMouseCapture(slot = "Mod2" ? "mod2" : "mod1")
    modCaptureTagBySlot[slot] := ""
    ResumeModifierHotkeysIfNeededForSlot(slot)
}

CancelPendingModifierCapture() {
    CancelPendingModifierCaptureForSlot("Mod")
}

ResumeModifierHotkeysIfNeededForSlot(slot) {
    global modCaptureSuspendedBySlot
    if modCaptureSuspendedBySlot[slot] {
        DecrementCaptureSuspend()
        modCaptureSuspendedBySlot[slot] := false
    }
}

ResumeModifierHotkeysIfNeeded() {
    ResumeModifierHotkeysIfNeededForSlot("Mod")
}

BeginModifierMouseCapture(owner, cb) {
    global modMouseCaptureCbs, modMouseCaptureArmed
    modMouseCaptureCbs[owner] := cb
    SetModMouseCaptureArmed(false)
    SetTimer(ArmModifierMouseCapture, -300)
}

ArmModifierMouseCapture() {
    global modMouseCaptureCbs, modMouseCaptureArmed
    if modMouseCaptureCbs.Count
        SetModMouseCaptureArmed(true)
}

CancelModifierMouseCapture(owner) {
    global modMouseCaptureCbs, modMouseCaptureArmed
    if modMouseCaptureCbs.Has(owner)
        modMouseCaptureCbs.Delete(owner)
    if !modMouseCaptureCbs.Count {
        SetTimer(ArmModifierMouseCapture, 0)
        SetModMouseCaptureArmed(false)
    }
}

DispatchModifierMouseCapture(buttonKey) {
    global modMouseCaptureCbs
    cbs := modMouseCaptureCbs
    modMouseCaptureCbs := Map()
    for owner, cb in cbs
        cb.Call(buttonKey)
}

StartModifierCaptureForSlot(slot) {
    global modCaptureSuspendedBySlot, modCaptureHookBySlot, modCaptureTagBySlot, editingDevTab
    modCaptureTagBySlot[slot] := editingDevTab
    ResetPendingModifierCaptureStateForSlot(slot)
    SetCaptureModifierRawModeForSlot(slot, false)
    IncrementCaptureSuspend()
    modCaptureSuspendedBySlot[slot] := true
    ctrl := (slot = "Mod2") ? txtModifierStatus2 : txtModifierStatus
    ctrl.Value := "Waiting for a key, mouse button or wheel notch..."
    modCaptureHookBySlot[slot] := (slot = "Mod2") ? NewCaptureInputHook(OnModifierCaptureKey2) : NewCaptureInputHook(OnModifierCaptureKey)
    BeginModifierMouseCapture((slot = "Mod2") ? "mod2" : "mod1", (slot = "Mod2") ? OnModifierMouseCaptured2 : OnModifierMouseCaptured)
}

StartModifierCapture(*) {
    StartModifierCaptureForSlot("Mod")
}

StartModifierRawCaptureForSlot(slot) {
    global modCaptureTagBySlot, editingDevTab
    modCaptureTagBySlot[slot] := editingDevTab
    ResetPendingModifierCaptureStateForSlot(slot)
    SetCaptureModifierRawModeForSlot(slot, true)
    ctrl := (slot = "Mod2") ? txtModifierStatus2 : txtModifierStatus
    ctrl.Value := "Get ready... (waiting for your click to finish)"
    SetTimer((slot = "Mod2") ? ArmModifierRawCapture2 : ArmModifierRawCapture, -300)
}

StartModifierRawCapture(*) {
    StartModifierRawCaptureForSlot("Mod")
}

ArmModifierRawCaptureForSlot(slot) {
    global modRawCaptureArmedBySlot
    modRawCaptureArmedBySlot[slot] := true
    ctrl := (slot = "Mod2") ? txtModifierStatus2 : txtModifierStatus
    ctrl.Value := "Waiting for button press (raw HID)..."
}

ArmModifierRawCapture() {
    ArmModifierRawCaptureForSlot("Mod")
}

OnModifierCaptureKeyForSlot(ihObj, VK, SC, slot) {
    global deviceModifiersBySlot, modCaptureTagBySlot, editingDevTab
    ihObj.Stop()
    CancelModifierMouseCapture((slot = "Mod2") ? "mod2" : "mod1")
    tag := modCaptureTagBySlot[slot] != "" ? modCaptureTagBySlot[slot] : editingDevTab
    dm := deviceModifiersBySlot[slot]
    oldDm := dm.Has(tag) ? dm[tag] : ""
    mode := (slot = "Mod2") ? Mod2StoredMode(oldDm) : (IsObject(oldDm) ? oldDm.mode : "toggle")
    dm[tag] := {kind: "sc", sc: SC, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: mode, lpOn: ModLpOn(oldDm), lpMs: ModLpMs(oldDm)}
    if (slot = "Mod2") {
        UpdateMod2UI(tag)
    } else {
        RefreshModifierStatusText(tag)
        UpdateModifierModeUI(tag)
    }
    RegisterDeviceModifierHotkeyForSlot(tag, slot)
    if (slot = "Mod2")
        SaveModifier2SettingsForTag(tag)
    else
        SaveModifierSettingsForTag(tag)
    ResumeModifierHotkeysIfNeededForSlot(slot)
}

OnModifierCaptureKey(ihObj, VK, SC) {
    OnModifierCaptureKeyForSlot(ihObj, VK, SC, "Mod")
}

OnModifierMouseCapturedForSlot(buttonKey, slot) {
    global deviceModifiersBySlot, modCaptureTagBySlot, editingDevTab, modCaptureHookBySlot
    if !(IsObject(modCaptureHookBySlot[slot]) && modCaptureHookBySlot[slot].InProgress)
        return
    try modCaptureHookBySlot[slot].Stop()
    modCaptureHookBySlot[slot] := ""
    tag := modCaptureTagBySlot[slot] != "" ? modCaptureTagBySlot[slot] : editingDevTab
    raw := StdMouseRawReportFromButton(buttonKey)
    if !IsObject(raw) {
        if (slot = "Mod2")
            RefreshMod2StatusText(tag)
        else
            RefreshModifierStatusText(tag)
        ResumeModifierHotkeysIfNeededForSlot(slot)
        return
    }
    dm := deviceModifiersBySlot[slot]
    oldDm := dm.Has(tag) ? dm[tag] : ""
    mode := (slot = "Mod2") ? Mod2StoredMode(oldDm) : (IsObject(oldDm) ? oldDm.mode : "toggle")
    dm[tag] := {kind: "raw", sc: 0, rawPage: raw.page, rawBytesHex: raw.bytesHex, rawUpBytesHex: raw.upBytesHex, mode: mode, lpOn: ModLpOn(oldDm), lpMs: ModLpMs(oldDm)}
    if (slot = "Mod2") {
        UpdateMod2UI(tag)
    } else {
        RefreshModifierStatusText(tag)
        UpdateModifierModeUI(tag)
    }
    RegisterDeviceModifierHotkeyForSlot(tag, slot)
    if (slot = "Mod2")
        SaveModifier2SettingsForTag(tag)
    else
        SaveModifierSettingsForTag(tag)
    ResumeModifierHotkeysIfNeededForSlot(slot)
}

OnModifierMouseCaptured(buttonKey) {
    OnModifierMouseCapturedForSlot(buttonKey, "Mod")
}

SetCaptureModifier2RawMode(val) {
    SetCaptureModifierRawModeForSlot("Mod2", val)
}

ResetPendingModifier2CaptureState() {
    ResetPendingModifierCaptureStateForSlot("Mod2")
}

CancelPendingModifierCapture2() {
    CancelPendingModifierCaptureForSlot("Mod2")
}

ResumeModifier2HotkeysIfNeeded() {
    ResumeModifierHotkeysIfNeededForSlot("Mod2")
}

StartModifierCapture2(*) {
    StartModifierCaptureForSlot("Mod2")
}

StartModifierRawCapture2(*) {
    StartModifierRawCaptureForSlot("Mod2")
}

ArmModifierRawCapture2() {
    ArmModifierRawCaptureForSlot("Mod2")
}

OnModifierCaptureKey2(ihObj, VK, SC) {
    OnModifierCaptureKeyForSlot(ihObj, VK, SC, "Mod2")
}

OnModifierMouseCaptured2(buttonKey) {
    OnModifierMouseCapturedForSlot(buttonKey, "Mod2")
}

RefreshModifierStatusText(tag := "") {
    global editingDevTab, deviceModifiers
    if tag = ""
        tag := editingDevTab
    dm := deviceModifiers[tag]
    if dm.kind = "sc"
        txtModifierStatus.Value := Format("Modifier: SC{:03X}", dm.sc)
    else if dm.kind = "raw" {
        mouseKey := StdMouseButtonFromRawReport(dm.rawPage, dm.rawBytesHex)
        if mouseKey != "" {
            mouseNote := dm.rawUpBytesHex != "" ? " - hold-capable" : (IsMouseWheelKey(mouseKey) ? " - Toggle-only (wheel notches have no hold)" : " - Toggle-only")
            txtModifierStatus.Value := "Modifier: " MouseButtonDisplayName(mouseKey) mouseNote
        } else {
            holdNote := dm.rawUpBytesHex != "" ? Format(" - hold-capable (release: Bytes:{})", dm.rawUpBytesHex) : " - Toggle-only (no distinct release report detected)"
            txtModifierStatus.Value := Format("Modifier: Raw Page:0x{:X} Bytes:{}{}", dm.rawPage, dm.rawBytesHex, holdNote)
        }
    } else
        txtModifierStatus.Value := "Modifier: not set"
}

UpdateModifierModeUI(tag := "") {
    global editingDevTab, deviceModifiers
    if tag = ""
        tag := editingDevTab
    dm := deviceModifiers[tag]
    if dm.kind = "raw" && dm.rawUpBytesHex = "" {
        dm.mode := "toggle"
        ddlModifierMode.Choose(2)
        ddlModifierMode.Enabled := false
    } else {
        ddlModifierMode.Enabled := true
        ddlModifierMode.Choose(dm.mode = "toggle" ? 2 : 1)
    }
    UpdateMod2UI(tag)
}

UpdateMod2UI(tag := "") {
    global editingDevTab, deviceModifiers, deviceModifiers2, tabModifierSection
    if tag = ""
        tag := editingDevTab
    dm := deviceModifiers[tag]
    dm2 := deviceModifiers2[tag]
    isToggle := dm.mode = "toggle"
    hasOwn := dm2.kind != "none"
    showMod2Tab := tabModifierSection.Value = 2
    btnCaptureModifier2.Visible := showMod2Tab
    btnCaptureModifier2Raw.Visible := showMod2Tab
    btnClearModifier2.Visible := showMod2Tab
    txtModifierStatus2.Visible := showMod2Tab
    showOwn := showMod2Tab && hasOwn
    lblMod2ModeLabel.Visible := showOwn
    ddlMod2Mode.Visible := showOwn
    chkMod2Lp.Visible := showOwn
    edMod2LpMs.Visible := showOwn
    lblMod2LpMsUnit.Visible := showOwn
    holdIncapable := IsHoldIncapableMod(dm2)
    if holdIncapable {
        ddlMod2Mode.Choose(2)
        ddlMod2Mode.Enabled := false
    } else {
        stored := Mod2StoredMode(dm2)
        shownMode := stored != "" ? stored : (isToggle ? "toggle" : "hold")
        ddlMod2Mode.Enabled := true
        ddlMod2Mode.Choose(shownMode = "toggle" ? 2 : 1)
    }
    lpOn := ModLpOn(dm2)
    chkMod2Lp.Value := lpOn ? 1 : 0
    edMod2LpMs.Value := ModLpMs(dm2)
    chkMod2Lp.Enabled := !holdIncapable
    edMod2LpMs.Enabled := !holdIncapable && lpOn
    chkMod2Pt.Value := ModPtOn(dm2) ? 1 : 0
    chkMod2Pt.Visible := showOwn
    chkMod2Pt.Enabled := !holdIncapable
    RefreshMod2StatusText(tag)
    UpdateModLpUI(tag)
}

IsHoldIncapableMod(m) => (m.kind = "raw" && m.rawUpBytesHex = "")

UpdateModLpUI(tag := "") {
    global editingDevTab, deviceModifiers, tabModifierSection
    if tag = ""
        tag := editingDevTab
    dm := deviceModifiers[tag]
    showMod1Tab := tabModifierSection.Value = 1
    holdIncapable := IsHoldIncapableMod(dm)
    blocked := holdIncapable
    lpOn := ModLpOn(dm)
    chkModLp.Value := lpOn ? 1 : 0
    edModLpMs.Value := ModLpMs(dm)
    chkModLp.Enabled := !blocked
    edModLpMs.Enabled := !blocked && lpOn
    if holdIncapable
        txtModLpHint.Value := "Unavailable: no release report"
    chkModLp.Visible := showMod1Tab
    edModLpMs.Visible := showMod1Tab
    lblModLpMsUnit.Visible := showMod1Tab
    txtModLpHint.Visible := showMod1Tab && blocked
    chkModPt.Value := ModPtOn(dm) ? 1 : 0
    chkModPt.Enabled := !blocked
    chkModPt.Visible := showMod1Tab
}

RefreshMod2StatusText(tag := "") {
    global editingDevTab, deviceModifiers2
    if tag = ""
        tag := editingDevTab
    dm2 := deviceModifiers2[tag]
    if dm2.kind = "sc"
        txtModifierStatus2.Value := Format("Mod 2: SC{:03X}", dm2.sc)
    else if dm2.kind = "raw" {
        mouseKey := StdMouseButtonFromRawReport(dm2.rawPage, dm2.rawBytesHex)
        if mouseKey != "" {
            mouseNote := dm2.rawUpBytesHex != "" ? " - hold-capable" : " - Toggle-only (wheel notches have no hold - won't work as Mod 2's Held-mode button)"
            txtModifierStatus2.Value := "Mod 2: " MouseButtonDisplayName(mouseKey) mouseNote
        } else {
            holdNote := dm2.rawUpBytesHex != "" ? Format(" - hold-capable (release: Bytes:{})", dm2.rawUpBytesHex) : " - Toggle-only (no distinct release report detected - won't work as Mod 2's Held-mode button)"
            txtModifierStatus2.Value := Format("Mod 2: Raw Page:0x{:X} Bytes:{}{}", dm2.rawPage, dm2.rawBytesHex, holdNote)
        }
    } else
        txtModifierStatus2.Value := "Mod 2: not set"
}

OnModLpChangeForSlot(slot) {
    global deviceModifiersBySlot, editingDevTab
    tag := editingDevTab
    ctrl := (slot = "Mod2") ? chkMod2Lp : chkModLp
    deviceModifiersBySlot[slot][tag].lpOn := ctrl.Value ? true : false
    if (slot = "Mod2") {
        SaveModifier2SettingsForTag(tag)
        ResetModifierStateForTag(tag)
        RefreshModifierLiveIndicator()
        UpdateMod2UI(tag)
    } else {
        SaveModifierSettingsForTag(tag)
        ResetModifierStateForTag(tag)
        RefreshModifierLiveIndicator()
        UpdateModLpUI(tag)
    }
}

OnModLpChange(*) {
    OnModLpChangeForSlot("Mod")
}

OnModPtChangeForSlot(slot) {
    global deviceModifiersBySlot, editingDevTab, chkModPt, chkMod2Pt
    tag := editingDevTab
    ctrl := (slot = "Mod2") ? chkMod2Pt : chkModPt
    deviceModifiersBySlot[slot][tag].ptOn := ctrl.Value ? true : false
    if (slot = "Mod2") {
        SaveModifier2SettingsForTag(tag)
        UpdateMod2UI(tag)
    } else {
        SaveModifierSettingsForTag(tag)
        UpdateModLpUI(tag)
    }
    InvalidateMouseBlockCache()
}

OnModPtChange(*) {
    OnModPtChangeForSlot("Mod")
}

OnMod2PtChange(*) {
    OnModPtChangeForSlot("Mod2")
}

SetModLpMsForSlot(slot, val) {
    global deviceModifiersBySlot, editingDevTab
    tag := editingDevTab
    trimmed := Trim(val)
    n := IsInteger(trimmed) ? Integer(trimmed) : 0
    if n < 1
        n := 500
    ctrl := (slot = "Mod2") ? edMod2LpMs : edModLpMs
    ctrl.Value := n
    dm := deviceModifiersBySlot[slot][tag]
    if ModLpMs(dm) = n
        return
    dm.lpMs := n
    if (slot = "Mod2")
        SaveModifier2SettingsForTag(tag)
    else
        SaveModifierSettingsForTag(tag)
    ResetModifierStateForTag(tag)
    RefreshModifierLiveIndicator()
}

SetModLpMs(val) {
    SetModLpMsForSlot("Mod", val)
}

OnMod2ModeChange(*) {
    global deviceModifiers2, editingDevTab
    tag := editingDevTab
    deviceModifiers2[tag].mode := ddlMod2Mode.Value = 2 ? "toggle" : "hold"
    SaveModifier2SettingsForTag(tag)
    ResetModifierStateForTag(tag)
    RefreshModifierLiveIndicator()
    UpdateMod2UI(tag)
}

OnMod2LpChange(*) {
    OnModLpChangeForSlot("Mod2")
}

SetMod2LpMs(val) {
    SetModLpMsForSlot("Mod2", val)
}

RefreshModifierLiveIndicator() {
    global activeListByTag, mod1HeldByTag, mod2HeldByTag, DEVICE_TAGS, modifierIndicatorDirty, g_lastModifierIndicatorText
    if !IsObject(txtModifierActive)
        return
    if !DllCall("IsWindowVisible", "ptr", g.Hwnd) {
        modifierIndicatorDirty := true
        return
    }
    parts := []
    for tag in DEVICE_TAGS {
        if activeListByTag[tag] = "Main" {
            parts.Push(tag ": Main")
            continue
        }
        effectiveMode := (activeListByTag[tag] = "Mod2" ? mod2HeldByTag[tag] : mod1HeldByTag[tag]) ? "hold" : "toggle"
        listLabel := (activeListByTag[tag] = "Mod2") ? "Mod 2" : "Mod 1"
        parts.Push(tag ": " listLabel " (" (effectiveMode = "toggle" ? "toggled" : "held") ")")
    }
    text := "Modifier: " parts[1] " | " parts[2] " | " parts[3]
    if text = g_lastModifierIndicatorText {
        modifierIndicatorDirty := false
        return
    }
    txtModifierActive.Value := text
    g_lastModifierIndicatorText := text
    modifierIndicatorDirty := false
}

OnModifierModeChange(*) {
    global deviceModifiers, editingDevTab
    deviceModifiers[editingDevTab].mode := ddlModifierMode.Value = 2 ? "toggle" : "hold"
    RegisterDeviceModifierHotkey(editingDevTab)
    UpdateMod2UI(editingDevTab)
    SaveModifierSettingsForTag(editingDevTab)
}

ClearModifierForTag(*) {
    global deviceModifiers, editingDevTab
    CancelPendingModifierCapture()
    deviceModifiers[editingDevTab] := {kind: "none", sc: 0, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: "toggle", lpOn: false, lpMs: 500}
    RefreshModifierStatusText(editingDevTab)
    UpdateModifierModeUI(editingDevTab)
    RegisterDeviceModifierHotkey(editingDevTab)
    SaveModifierSettingsForTag(editingDevTab)
}

ClearModifierForTag2(*) {
    global deviceModifiers2, editingDevTab
    CancelPendingModifierCapture2()
    deviceModifiers2[editingDevTab] := {kind: "none", sc: 0, rawPage: 0, rawBytesHex: "", rawUpBytesHex: "", mode: "", lpOn: false, lpMs: 500}
    UpdateMod2UI(editingDevTab)
    RegisterDeviceModifier2Hotkey(editingDevTab)
    SaveModifier2SettingsForTag(editingDevTab)
}

IsModifierVK(vk) {
    return vk = 0x10 || vk = 0x11 || vk = 0x12 || vk = 0x5B || vk = 0x5C
        || (vk >= 0xA0 && vk <= 0xA5)
}

ModPrefixForVK(vk) {
    if (vk = 0x10 || vk = 0xA0 || vk = 0xA1)
        return "+"
    if (vk = 0x11 || vk = 0xA2 || vk = 0xA3)
        return "^"
    if (vk = 0x12 || vk = 0xA4 || vk = 0xA5)
        return "!"
    if (vk = 0x5B || vk = 0x5C)
        return "#"
    return ""
}

BuildModStrFromHeld(heldMods) {
    hasCtrl := false, hasAlt := false, hasShift := false, hasWin := false
    for vk in heldMods {
        switch ModPrefixForVK(vk) {
            case "^": hasCtrl := true
            case "!": hasAlt := true
            case "+": hasShift := true
            case "#": hasWin := true
        }
    }
    modStr := ""
    if hasCtrl
        modStr .= "^"
    if hasAlt
        modStr .= "!"
    if hasShift
        modStr .= "+"
    if hasWin
        modStr .= "#"
    return modStr
}

CheckModLongPressRaw(devTab, which, mode, token, rawPage, rawUpBytesHex) {
    global modLpPhysDownByTag, modLpTokenByTag, mod1HeldByTag, mod2HeldByTag
    global mod1ArmedRawByTag, mod2ArmedRawByTag
    global mod1ComboUsedByTag, mod2ComboUsedByTag
    if modLpTokenByTag[devTab].%which% != token || !modLpPhysDownByTag[devTab].%which%
        return
    if mode = "hold" {
        if which = "Mod" {
            mod1HeldByTag[devTab] := true
            mod1ComboUsedByTag[devTab] := false
            mod1ArmedRawByTag[devTab] := {page: rawPage, upBytesHex: rawUpBytesHex}
        } else {
            mod2HeldByTag[devTab] := true
            mod2ComboUsedByTag[devTab] := false
            mod2ArmedRawByTag[devTab] := {page: rawPage, upBytesHex: rawUpBytesHex}
        }
        RecomputeHeldActiveList(devTab)
    } else {
        ToggleLatched(devTab, which)
        NotifyModifierToggled(devTab)
    }
    RefreshModifierLiveIndicator()
}

CheckPairLongRaw(devTab, which, token) {
    global modLpPhysDownByTag, modLpTokenByTag, modPairStateByTag
    if modLpTokenByTag[devTab].%which% != token || !modLpPhysDownByTag[devTab].%which%
        return
    modPairStateByTag[devTab].fired := true
    ToggleLatched(devTab, which)
    NotifyModifierToggled(devTab)
    RefreshModifierLiveIndicator()
}

IsScModifierButton(buttonKey) {
    global deviceModifiers, deviceModifiers2, profiles
    for tag, dm in deviceModifiers {
        if dm.kind = "sc" && Format("SC{:03X}", dm.sc) = buttonKey
            return true
    }
    for tag, dm2 in deviceModifiers2 {
        if dm2.kind = "sc" && Format("SC{:03X}", dm2.sc) = buttonKey
            return true
    }
    for pkey, pdata in profiles {
        if ProfModKind(pdata) = "sc" && Format("SC{:03X}", pdata.modSc) = buttonKey
            return true
    }
    for pkey, pdata in profiles {
        if ProfMod2Kind(pdata) = "sc" && Format("SC{:03X}", pdata.mod2Sc) = buttonKey
            return true
    }
    return false
}

ResetModifierStateForTag(tag) {
    global latchedListByTag, mod1HeldByTag, mod2HeldByTag, activeListByTag, heldOwnerByTag
    global mod1ArmedRawByTag, mod2ArmedRawByTag
    global mod1ArmedScByTag, mod2ArmedScByTag
    global mod1ComboUsedByTag, mod2ComboUsedByTag
    global modLpPhysDownByTag, modLpTokenByTag, modPairStateByTag, buttonPressState
    latchedListByTag[tag] := "Main"
    mod1HeldByTag[tag] := false
    mod2HeldByTag[tag] := false
    mod1ArmedRawByTag[tag] := {page: 0, upBytesHex: ""}
    mod2ArmedRawByTag[tag] := {page: 0, upBytesHex: ""}
    mod1ArmedScByTag[tag] := ""
    mod2ArmedScByTag[tag] := ""
    heldOwnerByTag[tag] := ""
    mod1ComboUsedByTag[tag] := false
    mod2ComboUsedByTag[tag] := false
    activeListByTag[tag] := "Main"
    modLpPhysDownByTag[tag].Mod := false
    modLpPhysDownByTag[tag].Mod2 := false
    modLpTokenByTag[tag].Mod += 1
    modLpTokenByTag[tag].Mod2 += 1
    modPairStateByTag[tag].long := ""
    modPairStateByTag[tag].fired := false
    for bk, bst in buttonPressState {
        if bst.pairLong != "" && bst.pairTag = tag
            bst.pairLong := ""
    }
}

RegisterDeviceModifierHotkeyForSlot(tag, slot) {
    global deviceModifiersBySlot, modifierHotkeyRegisteredScByTag, modifier2HotkeyRegisteredScByTag
    ResetModifierStateForTag(tag)
    RefreshModifierLiveIndicator()
    dm := deviceModifiersBySlot[slot][tag]
    scByTag := (slot = "Mod") ? modifierHotkeyRegisteredScByTag : modifier2HotkeyRegisteredScByTag
    oldSc := scByTag[tag]
    newSc := (dm.kind = "sc") ? dm.sc : 0
    scByTag[tag] := newSc
    if oldSc && oldSc != newSc
        RegisterHotkeyForButton(Format("SC{:03X}", oldSc))
    if newSc
        RegisterHotkeyForButton(Format("SC{:03X}", newSc))
}

RegisterDeviceModifierHotkey(tag) {
    RegisterDeviceModifierHotkeyForSlot(tag, "Mod")
}

RegisterDeviceModifier2Hotkey(tag) {
    RegisterDeviceModifierHotkeyForSlot(tag, "Mod2")
}

RecomputeHeldActiveList(devTab) {
    global mod1HeldByTag, mod2HeldByTag, activeListByTag, latchedListByTag, heldOwnerByTag
    oldList := activeListByTag[devTab]
    owner := heldOwnerByTag[devTab]
    if owner = "Mod" && !mod1HeldByTag[devTab]
        owner := ""
    if owner = "Mod2" && !mod2HeldByTag[devTab]
        owner := ""
    if owner = "" {
        if mod1HeldByTag[devTab]
            owner := "Mod"
        else if mod2HeldByTag[devTab]
            owner := "Mod2"
    }
    heldOwnerByTag[devTab] := owner
    activeListByTag[devTab] := (owner != "") ? owner : latchedListByTag[devTab]
    if activeListByTag[devTab] != oldList {
        ApplyLedIndicatorForTag(devTab)
        InvalidateMouseBlockCache()
    }
}

FindConflictingModifier(kind, buttonKey, profile, devTab) {
    effMod := EffectiveModifier(profile, devTab)
    if effMod.kind = kind {
        mKey := kind = "sc" ? Format("SC{:03X}", effMod.sc) : MakeRawButtonKey(effMod.rawPage, effMod.rawBytesHex)
        if mKey = buttonKey
            return "Mod 1"
    }
    effMod2 := EffectiveModifier2(profile, devTab)
    if effMod2.kind = kind {
        mKey2 := kind = "sc" ? Format("SC{:03X}", effMod2.sc) : MakeRawButtonKey(effMod2.rawPage, effMod2.rawBytesHex)
        if mKey2 = buttonKey
            return "Mod 2"
    }
    return ""
}

CheckModLongPressSc(buttonKey, devTab, which, mode, token) {
    global buttonPressState, mod1HeldByTag, mod2HeldByTag
    global mod1ArmedScByTag, mod2ArmedScByTag
    global mod1ComboUsedByTag, mod2ComboUsedByTag
    if !buttonPressState.Has(buttonKey)
        return
    st := buttonPressState[buttonKey]
    if st.token != token || !st.pressed
        return
    if mode = "hold" {
        if which = "Mod" {
            mod1HeldByTag[devTab] := true
            mod1ComboUsedByTag[devTab] := false
            mod1ArmedScByTag[devTab] := buttonKey
        } else {
            mod2HeldByTag[devTab] := true
            mod2ComboUsedByTag[devTab] := false
            mod2ArmedScByTag[devTab] := buttonKey
        }
        RecomputeHeldActiveList(devTab)
    } else {
        ToggleLatched(devTab, which)
        NotifyModifierToggled(devTab)
    }
    RefreshModifierLiveIndicator()
}

CheckPairLongSc(buttonKey, devTab, which, token) {
    global buttonPressState
    if !buttonPressState.Has(buttonKey)
        return
    st := buttonPressState[buttonKey]
    if st.token != token || !st.pressed || st.pairLong != which
        return
    st.pairFired := true
    ToggleLatched(devTab, which)
    NotifyModifierToggled(devTab)
    RefreshModifierLiveIndicator()
}

RefreshModifierGroupBoxForTag() {
    global editingDevTab, lblModifierSectionTitle
    lblModifierSectionTitle.Text := "Modifier button (" editingDevTab ")"
    RefreshModifierStatusText(editingDevTab)
    UpdateModifierModeUI(editingDevTab)
    UpdateLedIndicatorOptionForTag()
    UpdateNotifyModifierToggleOptionForTag()
}

UpdateNotifyModifierToggleOptionForTag() {
    global editingDevTab, notifyModifierToggleByTag
    if !IsObject(chkNotifyModifierToggle)
        return
    chkNotifyModifierToggle.Value := notifyModifierToggleByTag[editingDevTab]
}

UpdateLedIndicatorOptionForTag() {
    global editingDevTab, tabModifierSection, capsLockLedDeviceIndex
    global ledIndicatorChoiceByTag, ledIndicatorChoiceByTag2
    global lockFlashEnabledByTagSlot, lockFlashIntervalMsByTagSlot
    if !IsObject(radLedOff)
        return
    isMod2 := tabModifierSection.Value = 2
    slot := isMod2 ? 2 : 1
    lblLedIndicator.Text := "LED indicator when `"" (isMod2 ? "Mod 2" : "Mod 1") "`" active:"
    choiceMap := isMod2 ? ledIndicatorChoiceByTag2 : ledIndicatorChoiceByTag

    choice := choiceMap[editingDevTab]
    radLedOff.Value := (choice = "Off") ? 1 : 0
    radLedScroll.Value := (choice = "ScrollLock") ? 1 : 0
    radLedCaps.Value := (choice = "CapsLock") ? 1 : 0
    radLedNum.Value := (choice = "NumLock") ? 1 : 0

    chkScrollLockFlash.Value := lockFlashEnabledByTagSlot["ScrollLock"][editingDevTab][slot]
    edScrollLockFlashMs.Value := lockFlashIntervalMsByTagSlot["ScrollLock"][editingDevTab][slot]
    chkScrollLockFlash.Enabled := (choice = "ScrollLock")
    edScrollLockFlashMs.Enabled := (choice = "ScrollLock") && chkScrollLockFlash.Value

    chkCapsLockFlash.Value := lockFlashEnabledByTagSlot["CapsLock"][editingDevTab][slot]
    edCapsLockFlashMs.Value := lockFlashIntervalMsByTagSlot["CapsLock"][editingDevTab][slot]
    chkCapsLockFlash.Enabled := (choice = "CapsLock")
    edCapsLockFlashMs.Enabled := (choice = "CapsLock") && chkCapsLockFlash.Value

    chkNumLockFlash.Value := lockFlashEnabledByTagSlot["NumLock"][editingDevTab][slot]
    edNumLockFlashMs.Value := lockFlashIntervalMsByTagSlot["NumLock"][editingDevTab][slot]
    chkNumLockFlash.Enabled := (choice = "NumLock")
    edNumLockFlashMs.Enabled := (choice = "NumLock") && chkNumLockFlash.Value

    if IsObject(ddlCapsLockLedDevice) {
        ddlCapsLockLedDevice.Choose(Max(capsLockLedDeviceIndex, 0) + 1)
        ddlCapsLockLedDevice.Enabled := true
    }
}

OnModifierSectionTabChanged() {
    global editingDevTab
    isMod1 := tabModifierSection.Value = 1
    for ctrl in [btnCaptureModifier, btnCaptureModifierRaw, lblModifierModeLabel, ddlModifierMode, btnClearModifier, txtModifierStatus]
        ctrl.Visible := isMod1
    UpdateMod2UI(editingDevTab)
    UpdateLedIndicatorOptionForTag()
}

SaveModifierSettingsForTag(tag) {
    global deviceModifiers
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        dm := deviceModifiers[tag]
        sf := SettingsFile()
        section := "Modifier_" tag
        IniWrite(dm.kind, sf, section, "Kind")
        IniWrite(Format("{:X}", dm.sc), sf, section, "Sc")
        IniWrite(Format("{:X}", dm.rawPage), sf, section, "RawPage")
        IniWrite(dm.rawBytesHex, sf, section, "RawBytesHex")
        IniWrite(dm.rawUpBytesHex, sf, section, "RawUpBytesHex")
        IniWrite(dm.mode, sf, section, "Mode")
        IniWrite(ModLpOn(dm) ? "1" : "0", sf, section, "LongPress")
        IniWrite(ModLpMs(dm), sf, section, "LongPressMs")
        IniWrite(ModPtOn(dm) ? "1" : "0", sf, section, "Passthrough")
    } catch as e {
        LogWarn("save", "SaveModifierSettingsForTag(" tag "): " e.Message)
    }
}

SaveModifier2SettingsForTag(tag) {
    global deviceModifiers2
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    try {
        dm2 := deviceModifiers2[tag]
        sf := SettingsFile()
        section := "Modifier2_" tag
        IniWrite(dm2.kind, sf, section, "Kind")
        IniWrite(Format("{:X}", dm2.sc), sf, section, "Sc")
        IniWrite(Format("{:X}", dm2.rawPage), sf, section, "RawPage")
        IniWrite(dm2.rawBytesHex, sf, section, "RawBytesHex")
        IniWrite(dm2.rawUpBytesHex, sf, section, "RawUpBytesHex")
        IniWrite(Mod2StoredMode(dm2), sf, section, "Mode")
        IniWrite(ModLpOn(dm2) ? "1" : "0", sf, section, "LongPress")
        IniWrite(ModLpMs(dm2), sf, section, "LongPressMs")
        IniWrite(ModPtOn(dm2) ? "1" : "0", sf, section, "Passthrough")
    } catch as e {
        LogWarn("save", "SaveModifier2SettingsForTag(" tag "): " e.Message)
    }
}
