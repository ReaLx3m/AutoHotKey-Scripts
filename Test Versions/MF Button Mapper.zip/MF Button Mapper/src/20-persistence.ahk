
SaveSettings() {
    global appWatchEnabled, notifyModifierToggleByTag, ledIndicatorChoiceByTag, capsLockLedDeviceIndex, runElevated, runAtStartup, runAtStartupMode
    global ledIndicatorChoiceByTag2
    global lockFlashEnabledByTagSlot, lockFlashIntervalMsByTagSlot
    global masterEnabled, startHidden, MinHoldReleaseGapMs, disableMultiMapWarning
    global nativeMouseHookSetting
    global kbdListGateOn
    global deviceModifiers, DEVICE_TAGS
    global deviceModifiers2, mod1HeldByTag, mod2HeldByTag
    global editingDevTab
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    sf := SettingsFile()
    content := "[Settings]`r`n"
    content .= "MasterEnabled=" (masterEnabled ? "1" : "0") "`r`n"
    content .= "StartHidden=" (startHidden ? "1" : "0") "`r`n"
    content .= "MinHoldReleaseGapMs=" MinHoldReleaseGapMs "`r`n"
    content .= "AppWatchEnabled=" (appWatchEnabled ? "1" : "0") "`r`n"
    content .= "DisableMultiMapWarning=" (disableMultiMapWarning ? "1" : "0") "`r`n"
    content .= "NativeMouseHook=" nativeMouseHookSetting "`r`n"
    content .= "KeyboardListGate=" (kbdListGateOn ? "On" : "Off") "`r`n"
    for tag in DEVICE_TAGS
        content .= "NotifyModifierToggle_" tag "=" (notifyModifierToggleByTag[tag] ? "1" : "0") "`r`n"
    for tag in DEVICE_TAGS {
        content .= "LedIndicatorChoice_" tag "=" ledIndicatorChoiceByTag[tag] "`r`n"
        content .= "ScrollLockFlashEnabled_" tag "=" (lockFlashEnabledByTagSlot["ScrollLock"][tag][1] ? "1" : "0") "`r`n"
        content .= "ScrollLockFlashIntervalMs_" tag "=" lockFlashIntervalMsByTagSlot["ScrollLock"][tag][1] "`r`n"
        content .= "CapsLockFlashEnabled_" tag "=" (lockFlashEnabledByTagSlot["CapsLock"][tag][1] ? "1" : "0") "`r`n"
        content .= "CapsLockFlashIntervalMs_" tag "=" lockFlashIntervalMsByTagSlot["CapsLock"][tag][1] "`r`n"
        content .= "NumLockFlashEnabled_" tag "=" (lockFlashEnabledByTagSlot["NumLock"][tag][1] ? "1" : "0") "`r`n"
        content .= "NumLockFlashIntervalMs_" tag "=" lockFlashIntervalMsByTagSlot["NumLock"][tag][1] "`r`n"
    }
    for tag in DEVICE_TAGS {
        content .= "LedIndicatorChoice2_" tag "=" ledIndicatorChoiceByTag2[tag] "`r`n"
        content .= "ScrollLockFlashEnabled2_" tag "=" (lockFlashEnabledByTagSlot["ScrollLock"][tag][2] ? "1" : "0") "`r`n"
        content .= "ScrollLockFlashIntervalMs2_" tag "=" lockFlashIntervalMsByTagSlot["ScrollLock"][tag][2] "`r`n"
        content .= "CapsLockFlashEnabled2_" tag "=" (lockFlashEnabledByTagSlot["CapsLock"][tag][2] ? "1" : "0") "`r`n"
        content .= "CapsLockFlashIntervalMs2_" tag "=" lockFlashIntervalMsByTagSlot["CapsLock"][tag][2] "`r`n"
        content .= "NumLockFlashEnabled2_" tag "=" (lockFlashEnabledByTagSlot["NumLock"][tag][2] ? "1" : "0") "`r`n"
        content .= "NumLockFlashIntervalMs2_" tag "=" lockFlashIntervalMsByTagSlot["NumLock"][tag][2] "`r`n"
    }
    content .= "CapsLockLedDeviceIndex=" capsLockLedDeviceIndex "`r`n"
    content .= "RunElevated=" (runElevated ? "1" : "0") "`r`n"
    content .= "RunAtStartup=" (runAtStartup ? "1" : "0") "`r`n"
    content .= "RunAtStartupMode=" runAtStartupMode "`r`n"
    for lApp in launchOnExitApps
        content .= "LaunchOnExit_" lApp.key "=" (launchOnExitSelected[lApp.key] ? "1" : "0") "`r`n"
    for tApp in terminateApps
        content .= "TerminateOnStart_" tApp.key "=" (terminateAppsSelected[tApp.key] ? "1" : "0") "`r`n"
    for tag in DEVICE_TAGS {
        content .= "Mod1Held_" tag "=" (mod1HeldByTag[tag] ? "1" : "0") "`r`n"
        content .= "Mod2Held_" tag "=" (mod2HeldByTag[tag] ? "1" : "0") "`r`n"
    }
    content .= "EditingDevTab=" editingDevTab "`r`n"
    content .= "ProfileOrder=" JoinCsv(ComputeAllProfileKeys()) "`r`n"
    content .= "`r`n"
    for tag in DEVICE_TAGS {
        dm := deviceModifiers[tag]
        content .= "[Modifier_" tag "]`r`n"
        content .= "Kind=" dm.kind "`r`n"
        content .= "Sc=" Format("{:X}", dm.sc) "`r`n"
        content .= "RawPage=" Format("{:X}", dm.rawPage) "`r`n"
        content .= "RawBytesHex=" dm.rawBytesHex "`r`n"
        content .= "RawUpBytesHex=" dm.rawUpBytesHex "`r`n"
        content .= "Mode=" dm.mode "`r`n"
        content .= "LongPress=" (ModLpOn(dm) ? "1" : "0") "`r`n"
        content .= "LongPressMs=" ModLpMs(dm) "`r`n"
        content .= "Passthrough=" (ModPtOn(dm) ? "1" : "0") "`r`n"
        content .= "`r`n"
    }
    for tag in DEVICE_TAGS {
        dm2 := deviceModifiers2[tag]
        content .= "[Modifier2_" tag "]`r`n"
        content .= "Kind=" dm2.kind "`r`n"
        content .= "Sc=" Format("{:X}", dm2.sc) "`r`n"
        content .= "RawPage=" Format("{:X}", dm2.rawPage) "`r`n"
        content .= "RawBytesHex=" dm2.rawBytesHex "`r`n"
        content .= "RawUpBytesHex=" dm2.rawUpBytesHex "`r`n"
        content .= "Mode=" Mod2StoredMode(dm2) "`r`n"
        content .= "LongPress=" (ModLpOn(dm2) ? "1" : "0") "`r`n"
        content .= "LongPressMs=" ModLpMs(dm2) "`r`n"
        content .= "Passthrough=" (ModPtOn(dm2) ? "1" : "0") "`r`n"
        content .= "`r`n"
    }
    errMsg := ""
    if !WriteFileAtomic(sf, content, &errMsg) {
        LogWarn("save", sf ": " errMsg)
        NotifySaveFailure(sf, errMsg)
    }
}

WriteMappingSection(pf, section, m) {
    try IniDelete(pf, section)
    for f in MappingIniFields(m)
        IniWrite(f.value, pf, section, f.key)
}

FormatMappingSection(section, m) {
    s := "[" section "]`r`n"
    for f in MappingIniFields(m)
        s .= f.key "=" f.value "`r`n"
    s .= "`r`n"
    return s
}

SaveProfile(pkey) {
    global profiles, mapOrder, mappings, profileFiles, legacyLongPressMs
    global failedLoadProfiles, failedProfileSaveNotified
    if !PersistenceAllowed()
        return
    if failedLoadProfiles.Has(pkey) {
        pname := ProfileKeyName(pkey)
        LogWarn("save", "SaveProfile: refused to overwrite '" pname "' - its file failed to load earlier this session")
        if !failedProfileSaveNotified.Has(pkey) {
            failedProfileSaveNotified[pkey] := true
            MsgBox("The profile '" pname "' could not be read when the app started, so changes "
                . "to it this session are not being saved - this protects its file on disk from "
                . "being overwritten with an incomplete copy.`n`n"
                . "Fix or remove '" pname "'`'s file and restart the app to edit it again."
                , "MF Button Mapper - profile not saved", "Icon!")
        }
        return
    }
    EnsureDataDirs()
    pname := ProfileKeyName(pkey)
    if !profileFiles.Has(pkey) {
        RebuildProfileIndex()
        return
    }
    pf := profileFiles[pkey]
    pdata := profiles.Has(pkey) ? profiles[pkey] : {processNames: []}

    content := "[Profile]`r`n"
    content .= "Name=" pname "`r`n"
    content .= "ProcessNames=" JoinCsv(pdata.HasOwnProp("processNames") ? pdata.processNames : []) "`r`n"
    content .= "ModKind=" (ProfModKind(pdata)) "`r`n"
    content .= "ModSc=" Format("{:X}", ProfModSc(pdata)) "`r`n"
    content .= "ModRawPage=" Format("{:X}", pdata.HasOwnProp("modRawPage") ? pdata.modRawPage : 0) "`r`n"
    content .= "ModRawBytesHex=" (pdata.HasOwnProp("modRawBytesHex") ? pdata.modRawBytesHex : "") "`r`n"
    content .= "ModRawUpBytesHex=" (pdata.HasOwnProp("modRawUpBytesHex") ? pdata.modRawUpBytesHex : "") "`r`n"
    content .= "ModMode=" Mod1ModeOf(pdata) "`r`n"
    content .= "ModLongPress=" (LpOnOf(pdata, "modLpOn") ? "1" : "0") "`r`n"
    content .= "ModLongPressMs=" LpMsOf(pdata, "modLpMs") "`r`n"
    content .= "Mod2Kind=" (ProfMod2Kind(pdata)) "`r`n"
    content .= "Mod2Sc=" Format("{:X}", ProfMod2Sc(pdata)) "`r`n"
    content .= "Mod2RawPage=" Format("{:X}", pdata.HasOwnProp("mod2RawPage") ? pdata.mod2RawPage : 0) "`r`n"
    content .= "Mod2RawBytesHex=" (pdata.HasOwnProp("mod2RawBytesHex") ? pdata.mod2RawBytesHex : "") "`r`n"
    content .= "Mod2RawUpBytesHex=" (pdata.HasOwnProp("mod2RawUpBytesHex") ? pdata.mod2RawUpBytesHex : "") "`r`n"
    content .= "Mod2Mode=" StoredModeOf(pdata, "mod2Mode") "`r`n"
    content .= "Mod2LongPress=" (LpOnOf(pdata, "mod2LpOn") ? "1" : "0") "`r`n"
    content .= "Mod2LongPressMs=" LpMsOf(pdata, "mod2LpMs") "`r`n"
    content .= "PassthroughMod1=" (pdata.HasOwnProp("passthroughMod1") && pdata.passthroughMod1 ? "1" : "0") "`r`n"
    content .= "PassthroughMod2=" (pdata.HasOwnProp("passthroughMod2") && pdata.passthroughMod2 ? "1" : "0") "`r`n"
    content .= ProfileLedIniLines(pdata)
    content .= "DevTab=" (ProfDevTabOrRemote(pdata)) "`r`n"
    content .= "Enabled=" ((pdata.HasOwnProp("enabled") ? pdata.enabled : true) ? "1" : "0") "`r`n"

    orderList := []
    sectionsText := ""
    for key in mapOrder {
        if (MapProfileKey(mappings[key])) != pkey
            continue
        section := MappingSectionName(key)
        orderList.Push(section)
        sectionsText .= FormatMappingSection(section, mappings[key])
    }
    content .= "Order=" JoinCsv(orderList) "`r`n`r`n"
    content .= sectionsText

    errMsg := ""
    if !WriteFileAtomic(pf, content, &errMsg) {
        LogWarn("save", pf ": " errMsg)
        NotifySaveFailure(pf, errMsg)
    }
}

DeleteProfileFileOrNeutralize(pf) {
    sc := AtomicSidecarPaths(pf)
    try FileDelete(sc.tmp)
    try FileDelete(sc.bak)
    if !FileExist(pf)
        return "deleted"
    try FileDelete(pf)
    catch as e
        LogWarn("delete", pf ": FileDelete failed: " e.Message)
    if !FileExist(pf)
        return "deleted"
    try {
        f := FileOpen(pf, "w", "UTF-8-RAW")
        if IsObject(f)
            f.Close()
    }
    try {
        if FileGetSize(pf) = 0 {
            LogWarn("delete", pf ": could not be deleted, emptied instead")
            return "emptied"
        }
    }
    ok := true
    try {
        for section in StrSplit(IniRead(pf), "`n", "`r") {
            if section = ""
                continue
            try {
                IniDelete(pf, section)
            } catch {
                ok := false
            }
        }
    } catch {
        ok := false
    }
    if ok
        LogWarn("delete", pf ": could not be deleted, emptied instead")
    else
        LogWarn("delete", pf ": could not be deleted or fully emptied - stuck")
    return ok ? "emptied" : "stuck"
}

RebuildProfileIndex() {
    global profiles, mapOrder, mappings, profileFiles
    if !PersistenceAllowed()
        return
    EnsureDataDirs()
    allProfileKeys := ComputeAllProfileKeys()

    newProfileFiles := Map()
    usedBases := Map()
    for pkey in allProfileKeys {
        pName := ProfileKeyName(pkey)
        pTab := ProfileKeyTab(pkey)
        base := SanitizeProfileFileName(pName)
        cand := base
        suffix := 2
        while usedBases.Has(pTab "|" StrLower(cand)) {
            cand := base "_" suffix
            suffix += 1
        }
        usedBases[pTab "|" StrLower(cand)] := true
        newProfileFiles[pkey] := (pTab = "" ? ProfilesDir() : ProfileTabDir(pTab)) "\" cand ".ini"
    }

    changed := []
    for pkey, newPath in newProfileFiles {
        oldPath := profileFiles.Has(pkey) ? profileFiles[pkey] : ""
        if oldPath != newPath
            changed.Push(pkey)
    }

    stillUsedPaths := Map()
    for pkey, p in newProfileFiles
        stillUsedPaths[p] := true
    for pkey, oldPath in profileFiles {
        if !newProfileFiles.Has(pkey) || newProfileFiles[pkey] != oldPath {
            if !stillUsedPaths.Has(oldPath)
                DeleteProfileFileOrNeutralize(oldPath)
        }
    }

    profileFiles := newProfileFiles

    SaveProfileOrderSetting()
    for pkey in changed
        SaveProfile(pkey)
}

LoadMappings() {
    global loadCompleted, legacyLoadFailed
    global failedLoadProfiles
    failedLoadProfiles := Map()
    try {
    EnsureDataDirs()

    if !FileExist(SettingsFile()) && FileExist(mapFile) {
        legacyLoadFailed := false
        LoadLegacyMappings()
        if legacyLoadFailed
            throw Error("The legacy configuration in '" mapFile "' could not be fully read.")
        loadCompleted := true
        RebuildProfileIndex()
        SaveMacros()
        MarkLegacyMigrationComplete()
        ApplyLoadedStateToUI()
        return
    }
    if !FileExist(SettingsFile()) {
        loadCompleted := true
        return
    }

    sf := SettingsFile()

    stageFailures := []

    try {
        LoadSettingsSection(sf)
    } catch as e {
        LogWarn("load", "LoadSettingsSection: " e.Message " (What=" e.What ", Line=" e.Line ")")
        stageFailures.Push("Settings (" e.Message ")")
    }

    try {
        LoadMacros()
    } catch as e {
        LogWarn("load", "LoadMacros: " e.Message " (What=" e.What ", Line=" e.Line ")")
        stageFailures.Push("Macros (" e.Message ")")
    }

    try {
        LoadPsScripts()
    } catch as e {
        LogWarn("load", "LoadPsScripts: " e.Message " (What=" e.What ", Line=" e.Line ")")
        stageFailures.Push("PsScripts (" e.Message ")")
    }

    try {
        LoadCmdScripts()
    } catch as e {
        LogWarn("load", "LoadCmdScripts: " e.Message " (What=" e.What ", Line=" e.Line ")")
        stageFailures.Push("CmdScripts (" e.Message ")")
    }

    migratedDevTabProfiles := []
    retaggedMappingProfiles := Map()
    migratedRawMouseProfiles := Map()
    migratedRawMouseCountBox := {count: 0}
    fileByKey := Map()
    foundOrder := []
    migratedToTabFolder := []
    ordered := []
    profileContexts := []
    failedProfiles := []
    scanOk := false
    recordsOk := false

    try {
        MigrateFlatProfileFiles(fileByKey, foundOrder, migratedToTabFolder)
    } catch as e {
        LogWarn("load", "MigrateFlatProfileFiles: " e.Message " (What=" e.What ", Line=" e.Line ")")
        stageFailures.Push("Profile file migration (" e.Message ")")
    }

    try {
        ordered := ScanProfileFiles(sf, fileByKey, foundOrder)
        scanOk := true
    } catch as e {
        LogWarn("load", "ScanProfileFiles: " e.Message " (What=" e.What ", Line=" e.Line ")")
        stageFailures.Push("Profile scan (" e.Message ")")
    }

    if scanOk {
        try {
            profileContexts := LoadProfileRecords(sf, ordered, fileByKey, migratedDevTabProfiles, failedProfiles)
            recordsOk := true
        } catch as e {
            LogWarn("load", "LoadProfileRecords: " e.Message " (What=" e.What ", Line=" e.Line ")")
            stageFailures.Push("Profile records (" e.Message ")")
        }
    } else {
        stageFailures.Push("Profile records (skipped - profile scan did not complete)")
    }

    if recordsOk {
        try {
            LoadMappingSections(profileContexts, retaggedMappingProfiles, migratedRawMouseProfiles, migratedRawMouseCountBox)
        } catch as e {
            LogWarn("load", "LoadMappingSections: " e.Message " (What=" e.What ", Line=" e.Line ")")
            stageFailures.Push("Mapping sections (" e.Message ")")
        }
    } else {
        stageFailures.Push("Mapping sections (skipped - profile records did not complete)")
    }

    if stageFailures.Length {
        msg := "Your configuration could not be fully loaded from:`n" SettingsFile() "`n`n"
            . "The following stage(s) failed to load:`n"
        for f in stageFailures
            msg .= "- " f "`n"
        msg .= "`nEverything else listed above this loaded normally, but the app is NOT "
            . "running on default settings - it is running on an incomplete copy. Saving "
            . "has been disabled for this session so your files on disk are not "
            . "overwritten with it.`n`n"
            . "Close the app, fix or remove the affected file(s), then start it again."
        MsgBox(msg, "MF Button Mapper - Load Error", "Icon!")
        return
    }

    loadCompleted := true

    if failedProfiles.Length {
        msg := failedProfiles.Length " profile(s) could not be read and were skipped - the rest of your profiles loaded normally:`n`n"
        for pname in failedProfiles
            msg .= "- " pname "`n"
        msg .= "`nTheir files on disk were not touched. Fix or remove the affected file(s) and restart to try loading them again."
        MsgBox(msg, "Some profiles could not be loaded", "Icon!")
    }

    if migratedDevTabProfiles.Length {
        msg := "The following profile(s) predate the per-profile device tag feature and had no tag saved. They've been defaulted to 'Remote' - open each one and re-tag it if it should be Mouse or Keyboard instead:`n`n"
        for pname in migratedDevTabProfiles
            msg .= "- " pname "`n"
        MsgBox(msg, "Profiles defaulted to Remote", "Icon!")
    }
    if migratedToTabFolder.Length {
        msg := "Profile files are now stored in a folder per device tab, so two profiles can share a name on different tabs.`n`nThese profile file(s) were moved into their tab's folder:`n`n"
        for entry in migratedToTabFolder
            msg .= "- " entry "`n"
        MsgBox(msg, "Profiles reorganised into tab folders", "Iconi")
    }
    if retaggedMappingProfiles.Count {
        msg := "Some mappings were tagged for a different device tab than the profile that owns them - most likely because the profile predates the per-profile tag feature and was defaulted to 'Remote' while its mappings were tagged by kind.`n`nThose mappings were previously hidden from the Keymaps list. They've now been re-tagged to match their profile, so they're visible and editable again:`n`n"
        for pname, info in retaggedMappingProfiles
            msg .= "- " pname ": " info.count " mapping(s) -> " info.tab "`n"
        msg .= "`nIf any of these should live on a different tab, move them to a profile on that tab."
        MsgBox(msg, "Mappings re-tagged to match their profile", "Iconi")
    }

    if migratedRawMouseCountBox.count {
        for mpkey in migratedRawMouseProfiles {
            try
                SaveProfile(mpkey)
            catch as e
                LogWarn("load", mpkey ": raw->mouse re-save failed: " e.Message)
        }
        MsgBox(migratedRawMouseCountBox.count " saved mapping(s) on the standard mouse buttons / wheel were converted to the new mouse-hook type.`n`nThey behave as before, except that the button's normal click/scroll action is now blocked while a mapping is active for it.`n`n(Extra vendor buttons on gaming mice are not affected.)", "Mouse mappings upgraded", "Iconi")
    }

    try {
        ApplyLoadedStateToUI()
    } catch as e {
        LogWarn("load", "ApplyLoadedStateToUI: " e.Message " (What=" e.What ", Line=" e.Line ")")
    }

    } catch as e {
        LogWarn("load", SettingsFile() ": " e.Message " (What=" e.What ", Line=" e.Line ")")
        MsgBox("Your configuration could not be fully loaded from:`n" SettingsFile() "`n`n"
            . "Reason: " e.Message "`n`n"
            . "Only part of it was read, so the app is NOT running on default settings - it is "
            . "running on an incomplete copy. Saving has been disabled for this session so your "
            . "files on disk are not overwritten with it.`n`n"
            . "Close the app, fix or remove the file above, then start it again."
            , "MF Button Mapper - Load Error", "Icon!")
    }
}
