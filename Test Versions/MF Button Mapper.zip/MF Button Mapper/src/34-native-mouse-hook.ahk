
NativeHookWakeMsg() {
    return 0x8051
}

NativeMouseHookIsRunning() {
    global nativeHookRunning
    return nativeHookRunning ? true : false
}

NativeMouseHookStart(mode := 0) {
    global nativeHookBusy, nativeHookRunning, nativeHookLeaked, nativeHookLastFailure
    if nativeHookBusy {
        nativeHookLastFailure := "start/stop already in progress"
        LogWarn("NativeHook", "Start refused: " nativeHookLastFailure)
        return false
    }
    if nativeHookRunning
        return true
    if nativeHookLeaked {
        nativeHookLastFailure := "a previous native hook thread could not be stopped; native start disabled until the script restarts"
        LogWarn("NativeHook", "Start refused: " nativeHookLastFailure)
        return false
    }
    nativeHookBusy := true
    try {
        ok := NativeHookStartImpl(mode)
    } finally {
        nativeHookBusy := false
    }
    return ok
}

NativeMouseHookStop() {
    global nativeHookBusy, nativeHookLastFailure
    if nativeHookBusy {
        nativeHookLastFailure := "start/stop already in progress"
        LogWarn("NativeHook", "Stop refused: " nativeHookLastFailure)
        return false
    }
    nativeHookBusy := true
    try {
        ok := NativeHookStopImpl()
    } finally {
        nativeHookBusy := false
    }
    return ok
}

NativeHookFail(msg) {
    global nativeHookLastFailure
    nativeHookLastFailure := msg
    LogWarn("NativeHook", "Start failed: " msg)
    return false
}

NativeHookDecodeBlob(info, &why) {
    why := ""
    hex := NativeHookBlobHex()
    n := info["bytes"]
    if StrLen(hex) != 2 * n {
        why := "blob length mismatch: hex has " StrLen(hex) " chars, expected " (2 * n)
        return ""
    }
    if !RegExMatch(hex, "^[0-9a-f]+$") {
        why := "blob hex contains characters other than 0-9a-f"
        return ""
    }
    buf := Buffer(n)
    h := 0x811C9DC5
    loop n {
        b := Integer("0x" SubStr(hex, 2 * A_Index - 1, 2))
        NumPut("UChar", b, buf, A_Index - 1)
        h := ((h ^ b) * 0x01000193) & 0xFFFFFFFF
    }
    if h != info["fnv1a32"] {
        why := "blob checksum mismatch: computed " Format("0x{:08X}", h) ", expected " Format("0x{:08X}", info["fnv1a32"])
        return ""
    }
    return buf
}

NativeHookDescribeError(err, L) {
    if err = L["ERR_ABI"]
        return "ABI/size mismatch between loader and blob (0x" Format("{:08X}", err) ")"
    if err = L["ERR_API"]
        return "an API pointer slot was zero (0x" Format("{:08X}", err) ")"
    if err = L["ERR_THUNK"]
        return "thunk address was zero (0x" Format("{:08X}", err) ")"
    return "Win32 error " err " (0x" Format("{:08X}", err) ")"
}

NativeHookWaitThreadEnd(hThread, ms) {
    t0 := A_TickCount
    loop {
        if DllCall("WaitForSingleObject", "ptr", hThread, "uint", 0, "uint") = 0
            return true
        if ((A_TickCount - t0) & 0xFFFFFFFF) >= ms
            return false
        Sleep(2)
    }
}

NativeHookReleaseAll() {
    global nativeHookCtx, nativeHookCode, nativeHookCodeSize, nativeHookThread, nativeHookThreadId
    global nativeHookRunning, nativeHookMode
    global nativeHookPubSigTable, nativeHookPubSigRects
    global nativeHookLastDrainSeq, nativeHookLastDrainDropped
    global nativeHookResyncTailPending
    nativeHookLastDrainSeq := -1
    nativeHookLastDrainDropped := 0
    nativeHookResyncTailPending := Map()
    SetTimer(NativeHookPublishBackstop, 0)
    SetTimer(NativeHookPublishNow, 0)
    nativeHookPubSigTable := ""
    nativeHookPubSigRects := ""
    if nativeHookThread
        DllCall("CloseHandle", "ptr", nativeHookThread)
    if nativeHookCode
        DllCall("VirtualFree", "ptr", nativeHookCode, "uptr", 0, "uint", 0x8000)
    if nativeHookCtx
        DllCall("VirtualFree", "ptr", nativeHookCtx, "uptr", 0, "uint", 0x8000)
    nativeHookCtx := 0
    nativeHookCode := 0
    nativeHookCodeSize := 0
    nativeHookThread := 0
    nativeHookThreadId := 0
    nativeHookRunning := false
    nativeHookMode := 0
}

NativeHookLeak(why) {
    global nativeHookLeaked, nativeHookRunning, nativeHookLastFailure, nativeHookCtx
    nativeHookLeaked := true
    nativeHookRunning := false
    if nativeHookCtx {
        Lk := NativeHookLayout()
        NumPut("UInt", 0, nativeHookCtx, Lk["OFF_enabled"])
        NumPut("UInt", Lk["MODE_OBSERVE"], nativeHookCtx, Lk["OFF_mode"])
    }
    SetTimer(NativeHookPublishBackstop, 0)
    SetTimer(NativeHookPublishNow, 0)
    nativeHookLastFailure := why
    LogWarn("NativeHook", "LEAKING native hook memory on purpose (thread not proven gone): " why)
    return false
}

NativeHookStartImpl(mode) {
    global nativeHookCtx, nativeHookCode, nativeHookCodeSize, nativeHookThread, nativeHookThreadId
    global nativeHookMode, nativeHookRunning, nativeHookLastFailure
    static apiList := [
        ["CallNextHookEx", "user32.dll"],
        ["SetWindowsHookExW", "user32.dll"],
        ["UnhookWindowsHookEx", "user32.dll"],
        ["GetMessageW", "user32.dll"],
        ["PeekMessageW", "user32.dll"],
        ["PostMessageW", "user32.dll"],
        ["GetCurrentThreadId", "kernel32.dll"],
        ["GetTickCount", "kernel32.dll"],
        ["QueryPerformanceCounter", "kernel32.dll"],
        ["GetLastError", "kernel32.dll"]
    ]
    nativeHookLastFailure := ""

    if A_PtrSize != 8
        return NativeHookFail("64-bit AutoHotkey required (A_PtrSize=" A_PtrSize ")")
    info := NativeHookBlobInfo()
    L := NativeHookLayout()
    if info["abi"] != L["ABI_VERSION"]
        return NativeHookFail("ABI mismatch: blob info abi=" info["abi"] ", layout abi=" L["ABI_VERSION"])
    if apiList.Length != L["API_COUNT"]
        return NativeHookFail("API count mismatch: loader lists " apiList.Length ", header defines " L["API_COUNT"])
    if mode != L["MODE_OBSERVE"] && mode != L["MODE_ON"] {
        LogWarn("NativeHook", "Unknown mode " mode " coerced to Observe")
        mode := L["MODE_OBSERVE"]
    }
    blob := NativeHookDecodeBlob(info, &why)
    if !blob
        return NativeHookFail(why)
    n := info["bytes"]

    apiPtrs := []
    for item in apiList {
        hMod := DllCall("GetModuleHandle", "str", item[2], "ptr")
        p := hMod ? DllCall("GetProcAddress", "ptr", hMod, "astr", item[1], "ptr") : 0
        if !p
            return NativeHookFail("could not resolve " item[2] "!" item[1])
        apiPtrs.Push(p)
    }

    thunkOff := (n + 15) & ~15
    codeSize := ((thunkOff + 22 + 4095) // 4096) * 4096
    code := DllCall("VirtualAlloc", "ptr", 0, "uptr", codeSize, "uint", 0x3000, "uint", 0x04, "ptr")
    if !code
        return NativeHookFail("VirtualAlloc(code) failed, error " A_LastError)
    ctx := DllCall("VirtualAlloc", "ptr", 0, "uptr", L["CTX_SIZE"], "uint", 0x3000, "uint", 0x04, "ptr")
    if !ctx {
        err := A_LastError
        DllCall("VirtualFree", "ptr", code, "uptr", 0, "uint", 0x8000)
        return NativeHookFail("VirtualAlloc(ctx) failed, error " err)
    }

    DllCall("RtlMoveMemory", "ptr", code, "ptr", blob, "uptr", n)
    NumPut("UChar", 0x49, "UChar", 0xB9, "UPtr", ctx,
           "UChar", 0x48, "UChar", 0xB8, "UPtr", code + info["offProc"],
           "UChar", 0xFF, "UChar", 0xE0, code + thunkOff)

    NumPut("UInt", L["ABI_VERSION"], ctx, L["OFF_abi"])
    NumPut("UInt", L["CTX_SIZE"], ctx, L["OFF_size"])
    NumPut("UInt", 0, ctx, L["OFF_enabled"])
    NumPut("UInt", mode, ctx, L["OFF_mode"])
    NumPut("UPtr", A_ScriptHwnd, ctx, L["OFF_wakeHwnd"])
    NumPut("UInt", NativeHookWakeMsg(), ctx, L["OFF_wakeMsg"])
    NumPut("UPtr", code + thunkOff, ctx, L["OFF_thunk"])
    NumPut("UPtr", 0, ctx, L["OFF_hMod"])
    for i, item in apiList {
        apiName := item[1]
        NumPut("UPtr", apiPtrs[i], ctx, L["OFF_api"] + 8 * L["API_" apiName])
    }

    oldProt := 0
    if !DllCall("VirtualProtect", "ptr", code, "uptr", codeSize, "uint", 0x20, "uint*", &oldProt, "int") {
        err := A_LastError
        DllCall("VirtualFree", "ptr", code, "uptr", 0, "uint", 0x8000)
        DllCall("VirtualFree", "ptr", ctx, "uptr", 0, "uint", 0x8000)
        return NativeHookFail("VirtualProtect(RX) failed, error " err " (exploit protection / security software?)")
    }
    DllCall("FlushInstructionCache", "ptr", DllCall("GetCurrentProcess", "ptr"), "ptr", code, "uptr", codeSize)

    tid := 0
    hThread := DllCall("CreateThread", "ptr", 0, "uptr", 0, "ptr", code + info["offThread"], "ptr", ctx,
                       "uint", 0, "uint*", &tid, "ptr")
    if !hThread {
        err := A_LastError
        DllCall("VirtualFree", "ptr", code, "uptr", 0, "uint", 0x8000)
        DllCall("VirtualFree", "ptr", ctx, "uptr", 0, "uint", 0x8000)
        return NativeHookFail("CreateThread failed, error " err)
    }
    nativeHookCtx := ctx
    nativeHookCode := code
    nativeHookCodeSize := codeSize
    nativeHookThread := hThread
    nativeHookThreadId := tid
    nativeHookMode := mode

    t0 := A_TickCount
    state := NumGet(ctx, L["OFF_state"], "UInt")
    while state = L["ST_NEW"] && ((A_TickCount - t0) & 0xFFFFFFFF) < 2000 {
        Sleep(2)
        state := NumGet(ctx, L["OFF_state"], "UInt")
    }

    if state = L["ST_READY"] {
        hookHandle := NumGet(ctx, L["OFF_hookHandle"], "Ptr")
        if !hookHandle
            LogWarn("NativeHook", "READY but hookHandle is 0 (unexpected)")
        nativeHookRunning := true
        LogWarn("NativeHook", "Native mouse hook thread started (mode " (mode = L["MODE_ON"] ? "On" : "Observe")
            ", tid " tid ", blob " n " bytes, hook 0x" Format("{:X}", hookHandle) ")")
        return true
    }

    if state = L["ST_FAILED"] {
        reason := NativeHookDescribeError(NumGet(ctx, L["OFF_lastError"], "UInt"), L)
        if NativeHookWaitThreadEnd(hThread, 1000) {
            NativeHookReleaseAll()
            return NativeHookFail("native thread reported FAILED: " reason)
        }
        NativeHookLeak("thread reported FAILED (" reason ") but did not exit within 1 s")
        return NativeHookFail("native thread reported FAILED: " reason " (memory kept)")
    }

    DllCall("PostThreadMessageW", "uint", tid, "uint", 0x12, "uptr", 0, "ptr", 0, "int")
    if NativeHookWaitThreadEnd(hThread, 1000) {
        NativeHookReleaseAll()
        return NativeHookFail("native thread did not report READY within 2 s (state " state ")")
    }
    NativeHookLeak("thread did not report READY within 2 s and did not react to WM_QUIT")
    return NativeHookFail("native thread did not report READY within 2 s (memory kept)")
}

NativeHookStopImpl() {
    global nativeHookCtx, nativeHookThread, nativeHookThreadId, nativeHookLeaked
    if nativeHookLeaked {
        return false
    }
    if !nativeHookCtx
        return true

    L := NativeHookLayout()
    if !DllCall("PostThreadMessageW", "uint", nativeHookThreadId, "uint", 0x12, "uptr", 0, "ptr", 0, "int")
        LogWarn("NativeHook", "PostThreadMessage(WM_QUIT) failed, error " A_LastError " (thread may already be gone)")

    if NativeHookWaitThreadEnd(nativeHookThread, 1000) {
        state := NumGet(nativeHookCtx, L["OFF_state"], "UInt")
        if state != L["ST_EXITED"]
            LogWarn("NativeHook", "Thread ended but state is " state " (expected " L["ST_EXITED"] ")")
        try NativeMouseWake(0, 0, 0, 0)
        NativeHookReleaseAll()
        LogWarn("NativeHook", "Native mouse hook thread stopped, memory freed")
        return true
    }
    NativeHookLeak("thread did not exit within 1 s after WM_QUIT")
    return false
}

NativeMouseHookNormalizeSetting(v) {
    v := Trim(String(v))
    if v = "Observe"
        return "Observe"
    if v = "On"
        return "On"
    return "Off"
}

NativeMouseHookApplySetting() {
    global nativeMouseHookSetting, nativeHookMode
    UpdateNativeHookTrayChecks()
    want := nativeMouseHookSetting
    if want = "Off" {
        if !NativeMouseHookIsRunning()
            return true
        ok := NativeMouseHookStop()
        NativeHookEnsureLegacy()
        return ok
    }
    L := NativeHookLayout()
    isOn := (want = "On")
    wantMode := isOn ? L["MODE_ON"] : L["MODE_OBSERVE"]
    if NativeMouseHookIsRunning() && nativeHookMode != wantMode {
        wasOn := (nativeHookMode = L["MODE_ON"])
        ok := NativeMouseHookStop()
        if wasOn
            NativeHookEnsureLegacy()
        if !ok
            return false
    }
    justStarted := false
    if !NativeMouseHookIsRunning() {
        if !NativeMouseHookStart(wantMode) || !NativeHookAssertMode(wantMode) {
            if isOn
                NativeHookEnsureLegacy()
            return false
        }
        justStarted := true
    }
    if isOn {
        NativeHookRetireLegacy()
        if justStarted
            NativeHookReleaseSwallowed()
    }
    if justStarted
        NativeHookPublishStart()
    return true
}

NativeHookAssertMode(wantMode) {
    global nativeHookCtx, nativeHookLastFailure
    L := NativeHookLayout()
    mode := NumGet(nativeHookCtx, L["OFF_mode"], "UInt")
    enabled := NumGet(nativeHookCtx, L["OFF_enabled"], "UInt")
    if mode = wantMode && enabled = 0
        return true
    nativeHookLastFailure := "safety check failed: ctx.mode=" mode " ctx.enabled=" enabled " after start (expected " wantMode "/0)"
    LogWarn("NativeHook", nativeHookLastFailure " - stopping the native hook")
    NativeMouseHookStop()
    return false
}

SetNativeMouseHookSetting(value, showErrors := true) {
    global nativeMouseHookSetting, nativeHookLastFailure
    value := NativeMouseHookNormalizeSetting(value)
    nativeMouseHookSetting := value
    SaveNativeMouseHookSetting()
    ok := NativeMouseHookApplySetting()
    if !ok && showErrors {
        why := nativeHookLastFailure != "" ? nativeHookLastFailure : "unknown reason (see the log)"
        MsgBox("The native mouse hook could not be " (value = "Off" ? "stopped" : "started") ":`n`n" why
            . "`n`nThe normal (legacy) mouse hook is unaffected and keeps working.", "Native mouse hook", "Icon!")
    }
    return ok
}

NativeHookTrayLabel(v) {
    if v = "Observe"
        return "Observe (count only, beside the normal hook)"
    if v = "On"
        return "On (native hook replaces the normal hook)"
    return "Off (normal hook only)"
}

NativeHookTrayPick(value, *) {
    SetNativeMouseHookSetting(value)
}

UpdateNativeHookTrayChecks() {
    global nativeHookTrayMenu, nativeMouseHookSetting
    if !nativeHookTrayMenu
        return
    for v in ["Off", "Observe", "On"] {
        if v = nativeMouseHookSetting
            nativeHookTrayMenu.Check(NativeHookTrayLabel(v))
        else
            nativeHookTrayMenu.Uncheck(NativeHookTrayLabel(v))
    }
}

NativeMouseHookRestartForOrder(*) {
    global nativeHookMode
    if !NativeMouseHookIsRunning()
        return
    if nativeHookMode = NativeHookLayout()["MODE_ON"]
        return
    LogWarn("NativeHook", "Legacy hook was reinstalled by the watchdog: restarting the native hook so it stays in front")
    if !NativeMouseHookStop()
        return
    NativeMouseHookApplySetting()
}

NativeMouseHookOnExit(*) {
    try NativeMouseHookStop()
    return 0
}

NativeHookDumpSection() {
    global nativeHookCtx, nativeHookRunning, nativeHookBusy, nativeHookLeaked
    global nativeHookThreadId, nativeHookLastFailure, nativeMouseHookSetting
    global nativeHookMode, nativeHookDrained, nativeHookRecoveries, mouseHookHandle
    global nativeHookResyncCount
    Critical "On"
    try {
        head := "`n`nNATIVE mouse hook: setting " nativeMouseHookSetting
        if nativeHookBusy
            return head ", start/stop in progress - counters not read."
        if !nativeHookRunning || !nativeHookCtx {
            text := head ", NOT running."
            if nativeHookLeaked
                text .= " A previous thread could not be stopped; native start is disabled until the script restarts."
            if nativeHookLastFailure != ""
                text .= "`n  last failure: " nativeHookLastFailure
            return text
        }
        L := NativeHookLayout()
        c := nativeHookCtx
        events := NumGet(c, L["OFF_eventCount"], "UInt")
        decoded := NumGet(c, L["OFF_decodedCount"], "UInt")
        maxWait := NumGet(c, L["OFF_maxWaitMs"], "UInt")
        over50 := NumGet(c, L["OFF_waitOver50"], "UInt")
        over100 := NumGet(c, L["OFF_waitOver100"], "UInt")
        maxQpc := NumGet(c, L["OFF_maxCallbackQpc"], "UInt64")
        lastTick := NumGet(c, L["OFF_lastTick"], "UInt")
        dropped := NumGet(c, L["OFF_dropped"], "UInt")
        postFailed := NumGet(c, L["OFF_postFailed"], "UInt")
        ringHead := NumGet(c, L["OFF_ringHead"], "UInt")
        ringTail := NumGet(c, L["OFF_ringTail"], "UInt")
        ringPending := (ringHead - ringTail) & 0xFFFFFFFF
        notifyPending := NumGet(c, L["OFF_notifyPending"], "UInt")
        NumPut("UInt", 0, c, L["OFF_eventCount"])
        NumPut("UInt", 0, c, L["OFF_decodedCount"])
        NumPut("UInt", 0, c, L["OFF_maxWaitMs"])
        NumPut("UInt", 0, c, L["OFF_waitOver50"])
        NumPut("UInt", 0, c, L["OFF_waitOver100"])
        NumPut("UInt64", 0, c, L["OFF_maxCallbackQpc"])
        pubText := NativeHookPublishReadback(c, L)
    } finally {
        Critical "Off"
    }
    freq := QpcFreq()
    maxUs := freq > 0 ? Round(maxQpc * 1000000 / freq) : 0
    lastAgo := lastTick = 0 ? "no event yet" : (((A_TickCount - lastTick) & 0xFFFFFFFF) " ms ago")
    isOn := nativeHookMode = L["MODE_ON"]
    modeText := isOn ? "mode ON: swallows mapped buttons, the normal hook is removed" : "mode Observe: counts only - swallows nothing"
    text := head " (thread " nativeHookThreadId ", " modeText ")`n"
        . Format("  legacy (normal) hook: {}`n", mouseHookHandle ? "installed" : "NOT installed")
        . Format("  since last dump: {} event(s) ({} button/wheel), {} over 50 ms, {} over 100 ms`n", events, decoded, over50, over100)
        . Format("  worst queue wait: {} ms (~15.6 ms resolution){}; slowest button/wheel decision: {} us`n", maxWait
            , isOn ? " <- the number to judge On mode by" : "", maxUs)
        . Format("  last event: {}; ring dropped: {}; wake-post failures: {} (cumulative)`n", lastAgo, dropped, postFailed)
        . Format("  ring health: {} event(s) pending drain, notifyPending={}; resyncs this session: {} (0 = never had to recover from a drop/gap)`n"
            , ringPending, notifyPending, nativeHookResyncCount)
        . Format("  events drained on the main thread: {} (session); watchdog recoveries: {}", nativeHookDrained, nativeHookRecoveries)
        . pubText
    text .= "`n" NativeHookConsistencyCheck()
    LogWarn("NativeHook", "dump: " StrReplace(StrReplace(text, "`n  ", "; "), "`n", " "))
    return text
}

NativeHookButtonNames() {
    static names := ["LButton", "RButton", "MButton", "XButton1", "XButton2", "WheelUp", "WheelDown", "WheelLeft", "WheelRight"]
    return names
}

NativeHookRequestPublish() {
    global nativeHookRunning
    if nativeHookRunning
        SetTimer(NativeHookPublishNow, -1)
}

NativeHookPublishNow(*) {
    NativeHookPublish()
}
NativeHookPublishBackstop(*) {
    NativeHookPublish()
}

NativeHookPublishStart() {
    global mouseCaptureArmed, modMouseCaptureArmed
    NativeHookPublish()
    NativeHookSetArm("OFF_armLearn", mouseCaptureArmed)
    NativeHookSetArm("OFF_armMod", modMouseCaptureArmed)
    SetTimer(NativeHookPublishBackstop, 250)
}

NativeHookPublish() {
    global nativeHookCtx, nativeHookRunning, nativeHookBusy, nativeHookMode
    global nativeHookPubSigTable, nativeHookPubSigRects, nativeHookPubCount, nativeHookPubGate
    global ownWindowRects, masterEnabled, mouseBlockDecisionCache, mouseBlockCacheDirty
    static rectOverflowLogged := false
    if !nativeHookRunning || !nativeHookCtx || nativeHookBusy
        return false
    wasCritical := A_IsCritical
    Critical "On"
    try {
        c := nativeHookCtx
        L := NativeHookLayout()
        if mouseBlockCacheDirty
            RebuildMouseBlockDecisionCache()
        changed := false

        sig := ""
        vals := []
        for name in NativeHookButtonNames() {
            blk := 0, msw := 0
            if mouseBlockDecisionCache.Has(name) {
                d := mouseBlockDecisionCache[name]
                blk := d.block ? 1 : 0
                msw := d.modRoles.Length > 0 ? 1 : 0
            }
            vals.Push([L["BTN_" StrUpper(name)], blk, msw])
            sig .= blk msw
        }
        if sig != nativeHookPubSigTable {
            for v in vals {
                NumPut("UChar", v[2], c, L["OFF_table"] + 2 * v[1])
                NumPut("UChar", v[3], c, L["OFF_table"] + 2 * v[1] + 1)
            }
            nativeHookPubSigTable := sig
            changed := true
        }

        rsig := ""
        rects := []
        if IsSet(ownWindowRects) {
            for hwnd, r in ownWindowRects {
                if rects.Length >= L["MAX_RECTS"] {
                    if !rectOverflowLogged {
                        rectOverflowLogged := true
                        LogWarn("NativeHook", "more than " L["MAX_RECTS"] " own-window rects; the extra ones are not published (a click on them could be swallowed)")
                    }
                    break
                }
                rects.Push(r)
                rsig .= r[1] "," r[2] "," r[3] "," r[4] ";"
            }
        }
        if rsig != nativeHookPubSigRects {
            seq := NumGet(c, L["OFF_rectSeq"], "UInt")
            NumPut("UInt", (seq + 1) & 0xFFFFFFFF, c, L["OFF_rectSeq"])
            NumPut("UInt", rects.Length, c, L["OFF_rectCount"])
            for i, r in rects {
                base := L["OFF_rects"] + 16 * (i - 1)
                NumPut("Int", r[1], "Int", r[2], "Int", r[3], "Int", r[4], c, base)
            }
            NumPut("UInt", (seq + 2) & 0xFFFFFFFF, c, L["OFF_rectSeq"])
            nativeHookPubSigRects := rsig
            changed := true
        }

        gate := masterEnabled && !A_IsSuspended
        nativeHookPubGate := gate ? true : false
        wantEnabled := (nativeHookMode = L["MODE_ON"] && gate) ? 1 : 0
        if NumGet(c, L["OFF_enabled"], "UInt") != wantEnabled {
            NumPut("UInt", wantEnabled, c, L["OFF_enabled"])
            changed := true
        }
        if changed
            nativeHookPubCount += 1
    } finally {
        if !wasCritical
            Critical "Off"
    }
    return true
}

NativeHookPublishReadback(c, L) {
    global nativeHookPubCount, nativeHookPubGate
    blockNames := "", swallowNames := ""
    for name in NativeHookButtonNames() {
        idx := L["BTN_" StrUpper(name)]
        if NumGet(c, L["OFF_table"] + 2 * idx, "UChar")
            blockNames .= (blockNames != "" ? ", " : "") name
        if NumGet(c, L["OFF_table"] + 2 * idx + 1, "UChar")
            swallowNames .= (swallowNames != "" ? ", " : "") name
    }
    rectN := NumGet(c, L["OFF_rectCount"], "UInt")
    enabled := NumGet(c, L["OFF_enabled"], "UInt")
    gateText := nativeHookPubGate ? "open" : "CLOSED"
    if blockNames = ""
        blockNames := "-"
    if swallowNames = ""
        swallowNames := "-"
    return Format("`n  published {} time(s); gate (master on, not suspended): {}; ctx.enabled={} (stays 0 until mode On, B5b)`n"
        . "  hook holds: block [{}], hold-back modifier clicks [{}], own-window rects {}",
        nativeHookPubCount, gateText, enabled, blockNames, swallowNames, rectN)
}

SetMouseCaptureArmed(v) {
    global mouseCaptureArmed
    mouseCaptureArmed := v ? true : false
    NativeHookSetArm("OFF_armLearn", v)
}

SetModMouseCaptureArmed(v) {
    global modMouseCaptureArmed
    modMouseCaptureArmed := v ? true : false
    NativeHookSetArm("OFF_armMod", v)
}

NativeHookSetArm(offName, v) {
    global nativeHookCtx, nativeHookRunning, nativeHookBusy
    if !nativeHookRunning || !nativeHookCtx || nativeHookBusy
        return
    wasCritical := A_IsCritical
    Critical "On"
    try {
        if nativeHookRunning && nativeHookCtx && !nativeHookBusy
            NumPut("UInt", v ? 1 : 0, nativeHookCtx, NativeHookLayout()[offName])
    } finally {
        if !wasCritical
            Critical "Off"
    }
}

NativeHookConsistencyCheck() {
    global nativeHookCtx, nativeHookRunning, nativeHookBusy, nativeHookMode
    global mouseCaptureArmed, modMouseCaptureArmed, ownWindowRects, masterEnabled
    if !nativeHookRunning || !nativeHookCtx || nativeHookBusy
        return "  self-check: skipped (native hook not running, or start/stop in progress)"
    NativeHookPublish()
    L := NativeHookLayout()
    snap := Map()
    wasCritical := A_IsCritical
    Critical "On"
    try {
        if !nativeHookRunning || !nativeHookCtx
            return "  self-check: skipped (native hook stopped)"
        c := nativeHookCtx
        for name in NativeHookButtonNames() {
            idx := L["BTN_" StrUpper(name)]
            snap[name] := [NumGet(c, L["OFF_table"] + 2 * idx, "UChar"), NumGet(c, L["OFF_table"] + 2 * idx + 1, "UChar")]
        }
        rectN := NumGet(c, L["OFF_rectCount"], "UInt")
        ctxRects := ""
        loop Min(rectN, L["MAX_RECTS"]) {
            base := L["OFF_rects"] + 16 * (A_Index - 1)
            ctxRects .= NumGet(c, base, "Int") "," NumGet(c, base + 4, "Int") "," NumGet(c, base + 8, "Int") "," NumGet(c, base + 12, "Int") ";"
        }
        armLearn := NumGet(c, L["OFF_armLearn"], "UInt")
        armMod := NumGet(c, L["OFF_armMod"], "UInt")
        enabled := NumGet(c, L["OFF_enabled"], "UInt")
    } finally {
        if !wasCritical
            Critical "Off"
    }
    problems := []
    for name in NativeHookButtonNames() {
        freshBlk := ComputeMouseButtonShouldBlock(name) ? 1 : 0
        freshMsw := ComputeMouseModifierSwallowRoles(name).Length > 0 ? 1 : 0
        if snap[name][1] != freshBlk
            problems.Push(Format("{} block: hook {} / fresh {}", name, snap[name][1], freshBlk))
        if snap[name][2] != freshMsw
            problems.Push(Format("{} hold-back: hook {} / fresh {}", name, snap[name][2], freshMsw))
    }
    freshRects := ""
    n := 0
    if IsSet(ownWindowRects) {
        for hwnd, r in ownWindowRects {
            if n >= L["MAX_RECTS"]
                break
            freshRects .= r[1] "," r[2] "," r[3] "," r[4] ";"
            n += 1
        }
    }
    if ctxRects != freshRects
        problems.Push(Format("own-window rects: hook [{}] / fresh [{}]", ctxRects, freshRects))
    ahkLearn := mouseCaptureArmed ? 1 : 0
    ahkMod := modMouseCaptureArmed ? 1 : 0
    isOn := nativeHookMode = L["MODE_ON"]
    if armLearn != ahkLearn && !(isOn && armLearn = 0 && ahkLearn = 1)
        problems.Push(Format("armLearn: hook {} / AHK {}", armLearn, ahkLearn))
    if armMod != ahkMod && !(isOn && armMod = 0 && ahkMod = 1)
        problems.Push(Format("armMod: hook {} / AHK {}", armMod, ahkMod))
    wantEnabled := (isOn && masterEnabled && !A_IsSuspended) ? 1 : 0
    if enabled != wantEnabled
        problems.Push(Format("enabled: hook {} / expected {}", enabled, wantEnabled))
    if problems.Length = 0
        return "  self-check: OK - table (9 buttons), own-window rects, capture-arm flags and enabled all match a fresh computation"
    text := "  self-check: " problems.Length " MISMATCH(ES) between the native hook and a fresh computation:"
    for p in problems
        text .= "`n    - " p
    LogWarn("NativeHook", "self-check mismatch: " problems.Length " item(s); first: " problems[1])
    return text
}

NativeMouseWake(wParam, lParam, msg, hwnd) {
    global nativeHookDrainBusy
    if nativeHookDrainBusy
        return
    nativeHookDrainBusy := true
    try {
        NativeHookDrain()
    } finally {
        nativeHookDrainBusy := false
    }
}

NativeHookDrain() {
    global nativeHookCtx, nativeHookRunning, nativeHookLastDrainSeq, nativeHookLastDrainDropped
    if !nativeHookRunning || !nativeHookCtx
        return
    wasCritical := A_IsCritical
    Critical "On"
    try {
        NativeHookDrainLocked()
    } finally {
        if !wasCritical
            Critical "Off"
    }
}

NativeHookDrainLocked() {
    global nativeHookCtx, nativeHookRunning, nativeHookLastDrainSeq, nativeHookLastDrainDropped
    if !nativeHookRunning || !nativeHookCtx
        return
    c := nativeHookCtx
    L := NativeHookLayout()

    NumPut("UInt", 0, c, L["OFF_notifyPending"])

    dropped := NumGet(c, L["OFF_dropped"], "UInt")
    if dropped != nativeHookLastDrainDropped {
        prevDropped := nativeHookLastDrainDropped
        LogWarn("NativeHook", "ring dropped count moved " prevDropped " -> " dropped " (events were lost)")
        nativeHookLastDrainDropped := dropped
        NativeHookResync("ring dropped " prevDropped " -> " dropped)
    }

    loop {
        if !nativeHookRunning || !nativeHookCtx
            return
        head := NumGet(c, L["OFF_ringHead"], "UInt")
        tail := NumGet(c, L["OFF_ringTail"], "UInt")
        while tail != head {
            base := L["OFF_ring"] + NativeHookEventSize() * (tail & (L["RING_SIZE"] - 1))
            NativeHookDrainOneEvent(c, L, base)
            tail := (tail + 1) & 0xFFFFFFFF
            NumPut("UInt", tail, c, L["OFF_ringTail"])
        }
    } until (NumGet(c, L["OFF_ringHead"], "UInt") = head)
}

NativeHookEventSize() {
    static sz := NativeHookLayout()["EVENT_SIZE"]
    return sz
}

NativeHookDrainOneEvent(c, L, base) {
    global nativeHookLastDrainSeq, nativeHookDrained, nativeHookResyncTailPending
    global mouseSwallowedDown, mouseModSwallowed, mouseBlockDecisionCache, mouseBlockCacheDirty
    nativeHookDrained += 1
    type := NumGet(c, base + L["EV_OFF_type"], "UChar")
    btn := NumGet(c, base + L["EV_OFF_btn"], "UChar")
    count := NumGet(c, base + L["EV_OFF_count"], "UChar")
    seq := NumGet(c, base + L["EV_OFF_seq"], "UInt")

    if nativeHookLastDrainSeq != -1 {
        expected := (nativeHookLastDrainSeq + 1) & 0xFFFFFFFF
        if seq != expected {
            LogWarn("NativeHook", "ring seq gap: expected " expected ", got " seq " (events were lost between them)")
            NativeHookResync("ring seq gap " expected " -> " seq)
        }
    }
    nativeHookLastDrainSeq := seq

    names := NativeHookButtonNames()
    if btn >= names.Length {
        LogWarn("NativeHook", "ring event with out-of-range button index " btn " (type " type "), dropped")
        return
    }
    buttonKey := names[btn + 1]

    if type = L["EV_DOWN"] {
        if mouseModSwallowed.Has(buttonKey)
            mouseModSwallowed.Delete(buttonKey)
        if nativeHookResyncTailPending.Has(buttonKey)
            nativeHookResyncTailPending.Delete(buttonKey)
        mouseSwallowedDown[buttonKey] := true
        QueueMouseDispatch(buttonKey, true)
    } else if type = L["EV_UP"] {
        if mouseSwallowedDown.Has(buttonKey)
            mouseSwallowedDown.Delete(buttonKey)
        QueueMouseDispatch(buttonKey, false)
    } else if type = L["EV_MODDOWN"] {
        if mouseBlockCacheDirty
            RebuildMouseBlockDecisionCache()
        roles := mouseBlockDecisionCache.Has(buttonKey) ? mouseBlockDecisionCache[buttonKey].modRoles : []
        mouseModSwallowed[buttonKey] := roles
        if nativeHookResyncTailPending.Has(buttonKey)
            nativeHookResyncTailPending.Delete(buttonKey)
        QueueMouseDispatch(buttonKey, true, roles)
    } else if type = L["EV_MODUP"] {
        if nativeHookResyncTailPending.Has(buttonKey) {
            nativeHookResyncTailPending.Delete(buttonKey)
            LogWarn("NativeHook", "resync: absorbed the delayed MODUP tail of " buttonKey " (already settled by an earlier resync)")
            return
        }
        roles := []
        if mouseModSwallowed.Has(buttonKey) {
            roles := mouseModSwallowed[buttonKey]
            mouseModSwallowed.Delete(buttonKey)
        }
        QueueMouseDispatch(buttonKey, false, roles)
    } else if type = L["EV_WHEEL"] {
        loop count {
            QueueMouseDispatch(buttonKey, true)
            QueueMouseDispatch(buttonKey, false)
        }
    } else if type = L["EV_CAPTURE_LEARN"] {
        SetMouseCaptureArmed(false)
        SetTimer(OnMouseButtonCaptured.Bind(buttonKey), -1)
    } else if type = L["EV_CAPTURE_MOD"] {
        SetModMouseCaptureArmed(false)
        SetTimer(DispatchModifierMouseCapture.Bind(buttonKey), -1)
    } else {
        LogWarn("NativeHook", "ring event type " type " for " buttonKey " not dispatched (unknown type)")
    }
}

NativeHookEnsureLegacy() {
    global mouseHookHandle
    if mouseHookHandle
        return
    LogWarn("NativeHook", "installing the legacy (AHK) mouse hook")
    InstallMouseHook()
}

NativeHookRetireLegacy() {
    global mouseHookHandle
    if !mouseHookHandle
        return
    UninstallMouseHook()
    NativeHookReleaseSwallowed()
    LogWarn("NativeHook", "legacy (AHK) mouse hook removed: the native hook is now the only mouse hook")
}

NativeHookReleaseSwallowed() {
    global mouseSwallowedDown, mouseModSwallowed
    keys := []
    for k in mouseSwallowedDown
        keys.Push(k)
    for k in keys {
        mouseSwallowedDown.Delete(k)
        QueueMouseDispatch(k, false)
        LogWarn("NativeHook", "released swallowed press of " k)
    }
    keys := []
    for k in mouseModSwallowed
        keys.Push(k)
    for k in keys {
        roles := mouseModSwallowed[k]
        mouseModSwallowed.Delete(k)
        QueueMouseDispatch(k, false, roles)
        LogWarn("NativeHook", "released held-back modifier click of " k)
    }
}

NativeHookResync(reason) {
    global mouseSwallowedDown, mouseModSwallowed, nativeHookResyncTailPending, nativeHookResyncCount
    if mouseSwallowedDown.Count = 0 && mouseModSwallowed.Count = 0
        return
    nativeHookResyncCount += 1
    LogWarn("NativeHook", "resync #" nativeHookResyncCount " (" reason "): releasing "
        mouseSwallowedDown.Count " swallowed press(es) and " mouseModSwallowed.Count
        " held-back modifier click(s) the AHK side still believes are down")
    for k in mouseModSwallowed
        nativeHookResyncTailPending[k] := true
    NativeHookReleaseSwallowed()
}

NativeHookWatchdog() {
    global nativeHookRunning, nativeHookBusy, nativeHookCtx, nativeHookThread, nativeHookMode
    global nativeMouseHookSetting, mouseHookHandle
    global MOUSE_HOOK_WATCHDOG_IDLE_MS, MOUSE_HOOK_WATCHDOG_SILENT_MS
    if nativeHookBusy || nativeMouseHookSetting != "On"
        return
    if !nativeHookRunning {
        if !mouseHookHandle {
            LogWarn("NativeHook", "watchdog: setting is On but neither the native nor the legacy hook is installed - recovering")
            SetTimer(NativeMouseHookRecover, -1)
        }
        return
    }
    L := NativeHookLayout()
    if nativeHookMode != L["MODE_ON"]
        return
    reason := ""
    wasCritical := A_IsCritical
    Critical "On"
    try {
        if !nativeHookRunning || !nativeHookCtx
            return
        if DllCall("WaitForSingleObject", "ptr", nativeHookThread, "uint", 0, "uint") = 0 {
            reason := "the native hook thread has ended unexpectedly"
        } else if NumGet(nativeHookCtx, L["OFF_state"], "UInt") != L["ST_READY"] {
            reason := "the native hook thread is no longer READY (state " NumGet(nativeHookCtx, L["OFF_state"], "UInt") ")"
        } else {
            lastTick := NumGet(nativeHookCtx, L["OFF_lastTick"], "UInt")
            if lastTick != 0 {
                lii := Buffer(8, 0)
                NumPut("UInt", 8, lii, 0)
                if DllCall("GetLastInputInfo", "ptr", lii) {
                    idleMs := (A_TickCount - NumGet(lii, 4, "UInt")) & 0xFFFFFFFF
                    silentMs := (A_TickCount - lastTick) & 0xFFFFFFFF
                    if idleMs <= MOUSE_HOOK_WATCHDOG_IDLE_MS && silentMs >= MOUSE_HOOK_WATCHDOG_SILENT_MS
                        reason := "no native hook callback for " silentMs " ms despite input activity " idleMs " ms ago (hook removed by Windows?)"
                }
            }
        }
    } finally {
        if !wasCritical
            Critical "Off"
    }
    if reason != "" {
        LogWarn("NativeHook", "watchdog: " reason " - restarting the native hook")
        SetTimer(NativeMouseHookRecover, -1)
    }
}

NativeMouseHookRecover(*) {
    global nativeHookBusy, nativeHookRecoveries, nativeHookLastFailure
    static stamps := []
    if nativeHookBusy {
        SetTimer(NativeMouseHookRecover, -250)
        return
    }
    now := A_TickCount
    fresh := []
    for s in stamps {
        if ((now - s) & 0xFFFFFFFF) < 60000
            fresh.Push(s)
    }
    stamps := fresh
    stamps.Push(now)
    nativeHookRecoveries += 1
    if stamps.Length > 3 {
        nativeHookLastFailure := "watchdog gave up after repeated native hook failures; running on the legacy hook"
        LogWarn("NativeHook", nativeHookLastFailure)
        if NativeMouseHookIsRunning()
            NativeMouseHookStop()
        NativeHookEnsureLegacy()
        return
    }
    LogWarn("NativeHook", "recovery #" nativeHookRecoveries ": stop + restart")
    if NativeMouseHookIsRunning()
        NativeMouseHookStop()
    NativeMouseHookApplySetting()
}
