
ProfileTabButtonCustomDraw(wParam, lParam, msg, hwnd) {
    global profileTabDisabledHwnds
    global NM_CUSTOMDRAW, CDDS_PREPAINT, CDRF_DODEFAULT, CDRF_SKIPDEFAULT
    global DISABLED_BK, DISABLED_TX
    try {
        hwndFrom := NumGet(lParam, 0, "Ptr")
        if !profileTabDisabledHwnds.Has(hwndFrom)
            return
        if NumGet(lParam, A_PtrSize * 2, "Int") != NM_CUSTOMDRAW
            return

        nmhdrSize := (A_PtrSize = 8) ? 24 : 12
        offDrawStage := nmhdrSize
        offHdc := (A_PtrSize = 8) ? 32 : 16
        offRc := offHdc + A_PtrSize

        stage := NumGet(lParam, offDrawStage, "UInt")
        if stage != CDDS_PREPAINT
            return CDRF_DODEFAULT

        hdc := NumGet(lParam, offHdc, "Ptr")
        rectBuf := Buffer(16, 0)
        left := NumGet(lParam, offRc, "Int")
        top := NumGet(lParam, offRc + 4, "Int")
        right := NumGet(lParam, offRc + 8, "Int")
        bottom := NumGet(lParam, offRc + 12, "Int")
        NumPut("Int", left, rectBuf, 0)
        NumPut("Int", top, rectBuf, 4)
        NumPut("Int", right, rectBuf, 8)
        NumPut("Int", bottom, rectBuf, 12)

        hBrush := DllCall("gdi32\CreateSolidBrush", "UInt", DISABLED_BK, "Ptr")
        DllCall("user32\FillRect", "Ptr", hdc, "Ptr", rectBuf, "Ptr", hBrush)
        DllCall("gdi32\DeleteObject", "Ptr", hBrush)

        DllCall("gdi32\SetBkMode", "Ptr", hdc, "Int", 1)
        DllCall("gdi32\SetTextColor", "Ptr", hdc, "UInt", DISABLED_TX)
        label := profileTabDisabledHwnds[hwndFrom]
        DT_CENTER := 0x1, DT_VCENTER := 0x4, DT_SINGLELINE := 0x20
        DllCall("user32\DrawText", "Ptr", hdc, "Str", label, "Int", -1
            , "Ptr", rectBuf, "UInt", DT_CENTER | DT_VCENTER | DT_SINGLELINE)

        return CDRF_SKIPDEFAULT
    }
}

CopyMappingsToProfile(sourceKeys, targetKey, *) {
    global profiles, editingProfileName, editingDevTab
    targetProfile := ProfileKeyName(targetKey)
    copiedCount := 0
    lastDesc := ""
    targetPdata := profiles.Has(targetKey) ? profiles[targetKey] : {}
    targetIsDefault := ProfileKeyTab(targetKey) = ""
    targetDevTab := (!targetIsDefault && IsObject(targetPdata) && targetPdata.HasOwnProp("devTab")) ? targetPdata.devTab : ""
    addedIds := []
    skippedCount := 0
    for sourceKey in sourceKeys {
        if !mappings.Has(sourceKey)
            continue
        src := mappings[sourceKey]
        kind := MapKind(src)
        buttonKey := MappingButtonKey(src)
        if kind = "mouse" && MouseButtonRemapBlockedInProfile(buttonKey, targetProfile, MapList(src)) {
            skippedCount++
            continue
        }
        newId := GenerateId(targetProfile, buttonKey)

        newMap := {
            profile: targetProfile,
            kind: kind,
            actionType: MapActionType(src),
            desc: src.desc,
            target: src.target,
            appArgs: MapAppArgs(src),
            macroSteps: src.HasOwnProp("macroSteps") ? CloneMacroSteps(src.macroSteps) : [],
            macroName: MapMacroName(src),
            scriptName: MapScriptName(src),
            hideWindow: MapHideWindow(src),
            enabled: src.enabled,
            pressType: MapPressType(src),
            runMode: MapRunMode(src),
            repeatMs: MapRepeatMs(src),
            delayEnabled: MapDelayEnabled(src),
            delayMs: MapDelayMs(src),
            longPressMs: MapLongPressMs(src),
            list: MapList(src),
            devTab: targetDevTab != "" ? targetDevTab : MapDevTab(src)
        }
        if kind = "raw" {
            newMap.page := src.page
            newMap.bytesHex := src.bytesHex
        } else if kind = "mouse" {
            newMap.button := src.button
        } else {
            newMap.sc := src.sc
        }

        mappings[newId] := newMap
        mapOrder.Push(newId)
        addedIds.Push(newId)
        if kind = "sc"
            RegisterHotkeyForButton(buttonKey)

        copiedCount++
        lastDesc := src.desc
    }

    if skippedCount
        MsgBox(skippedCount = 1 ? "Skipped 1 mapping: Left and Right click can't be remapped in the Default profile." : "Skipped " skippedCount " mappings: Left and Right click can't be remapped in the Default profile.", "Not allowed in Default", "Icon!")
    if !copiedCount
        return

    for id in addedIds
        SaveProfileMapping(targetKey, id)
    InvalidateMouseBlockCache()
    if targetKey = ProfileKey(editingDevTab, editingProfileName)
        RefreshList()
    txtStatus.Value := copiedCount = 1
        ? "Copied '" lastDesc "' to profile '" targetProfile "'."
        : "Copied " copiedCount " mappings to profile '" targetProfile "'."
}

BuildProfileNamesList() {
    global profiles, profileOrder, editingDevTab
    names := ["Default"]
    seen := Map()
    for pkey in profileOrder {
        if pkey = "Default" || seen.Has(pkey) || !profiles.Has(pkey)
            continue
        seen[pkey] := true
        pdata := profiles[pkey]
        pDevTab := ProfileKeyTab(pkey)
        if pDevTab = ""
            pDevTab := ProfDevTabOrRemote(pdata)
        if pDevTab != editingDevTab
            continue
        names.Push(ProfileKeyName(pkey))
    }
    for pkey, pdata in profiles {
        if pkey = "Default" || seen.Has(pkey)
            continue
        seen[pkey] := true
        pDevTab := ProfileKeyTab(pkey)
        if pDevTab = ""
            pDevTab := ProfDevTabOrRemote(pdata)
        if pDevTab != editingDevTab
            continue
        names.Push(ProfileKeyName(pkey))
    }
    return names
}

MoveEditingProfileOrder(direction) {
    global profileOrder, editingProfileName, editingDevTab
    if editingProfileName = "Default"
        return
    names := BuildProfileNamesList()
    idx := 0
    for i, n in names {
        if n = editingProfileName {
            idx := i
            break
        }
    }
    if idx = 0
        return
    targetIdx := idx + direction
    if targetIdx < 2 || targetIdx > names.Length
        return
    keyA := ProfileKey(editingDevTab, names[idx])
    keyB := ProfileKey(editingDevTab, names[targetIdx])
    posA := 0, posB := 0
    for i, k in profileOrder {
        if k = keyA
            posA := i
        else if k = keyB
            posB := i
    }
    if posA = 0 || posB = 0
        return
    tmp := profileOrder[posA]
    profileOrder[posA] := profileOrder[posB]
    profileOrder[posB] := tmp
    RefreshProfileList()
    SaveProfileOrderSetting()
}

DestroyProfileTabButtons() {
    global profileTabButtons, profileTabDisabledHwnds
    for entry in profileTabButtons
        DestroyGuiControl(entry.btn)
    profileTabButtons := []
    profileTabDisabledHwnds := Map()
}

LayoutProfileTabsPage(names, startIdx) {
    global g, profileTabButtons, editingProfileName, profileTabPageStack
    global profileTabAreaX, profileTabAreaW, profileTabAreaY, profileTabRowH
    global profileTabGap, profileTabArrowsReserveW, profileTabBtnH
    global editingDevTab, profileTabDisabledHwnds

    DestroyProfileTabButtons()
    rightLimit := profileTabAreaX + profileTabAreaW
    idx := startIdx

    x := profileTabAreaX
    rowEntries := []
    while idx <= names.Length {
        name := names[idx]
        pkey := ProfileKey(editingDevTab, name)
        isEnabled := ProfileIsEnabled(pkey)
        label := ProfileHasOwnModifierButtons(pkey) ? name Chr(0x1D39) : name
        btn := g.Add("Button", "x-1000 y-1000 h" profileTabBtnH, label)
        btn.GetPos(, , &bw, &bh)
        if (x + bw > rightLimit) && (x > profileTabAreaX) {
            DestroyGuiControl(btn)
            break
        }
        btn.Move(x, profileTabAreaY)
        if name = editingProfileName
            btn.SetFont("bold")
        if !isEnabled
            profileTabDisabledHwnds[btn.Hwnd] := label
        btn.OnEvent("Click", ProfileTabClick.Bind(name))
        entry := {name: name, btn: btn}
        profileTabButtons.Push(entry)
        rowEntries.Push(entry)
        x := x + bw + profileTabGap
        idx += 1
    }

    hasMoreAfter := idx <= names.Length
    hasMoreBefore := profileTabPageStack.Length > 0

    if (hasMoreAfter || hasMoreBefore) && rowEntries.Length > 0 {
        arrowsZoneX := rightLimit - profileTabArrowsReserveW
        while rowEntries.Length > 0 {
            last := rowEntries[rowEntries.Length]
            last.btn.GetPos(&bx, &by, &bw, &bh)
            if (bx + bw <= arrowsZoneX)
                break
            if profileTabDisabledHwnds.Has(last.btn.Hwnd)
                profileTabDisabledHwnds.Delete(last.btn.Hwnd)
            DestroyGuiControl(last.btn)
            profileTabButtons.Pop()
            rowEntries.Pop()
            idx -= 1
        }
        hasMoreAfter := idx <= names.Length
    }

    return {idxAfter: idx, hasMoreAfter: hasMoreAfter, hasMoreBefore: hasMoreBefore, row2Y: profileTabAreaY}
}

PositionProfileTabArrows(result) {
    global btnProfileTabPrev, btnProfileTabNext
    global profileTabAreaX, profileTabAreaW, profileTabArrowW, profileTabGap
    btnProfileTabNext.Visible := result.hasMoreAfter
    btnProfileTabPrev.Visible := result.hasMoreBefore
    if result.hasMoreAfter || result.hasMoreBefore {
        nextX := profileTabAreaX + profileTabAreaW - profileTabArrowW
        btnProfileTabNext.Move(nextX, result.row2Y)
        btnProfileTabPrev.Move(nextX - profileTabArrowW - profileTabGap, result.row2Y)
    }
}

RenderProfileTabStrip() {
    global profileTabStartIdx, profileTabPageStack
    names := BuildProfileNamesList()
    if names.Length = 0 {
        DestroyProfileTabButtons()
        btnProfileTabPrev.Visible := false
        btnProfileTabNext.Visible := false
        return
    }
    if profileTabStartIdx < 1 || profileTabStartIdx > names.Length {
        profileTabStartIdx := 1
        profileTabPageStack := []
    }
    result := LayoutProfileTabsPage(names, profileTabStartIdx)
    PositionProfileTabArrows(result)
}

UpdateProfileToggleButtonLabel() {
    global editingProfileName, editingDevTab
    if !IsObject(btnToggleProfileEnabled)
        return
    if editingProfileName = "Default" {
        btnToggleProfileEnabled.Text := "Disable Profile"
        return
    }
    pkey := ProfileKey(editingDevTab, editingProfileName)
    btnToggleProfileEnabled.Text := ProfileIsEnabled(pkey) ? "Disable Profile" : "Enable Profile"
}

RefreshProfileList() {
    global profileTabStartIdx, profileTabPageStack, editingProfileName
    UpdateProfileToggleButtonLabel()
    names := BuildProfileNamesList()
    if names.Length = 0 {
        DestroyProfileTabButtons()
        btnProfileTabPrev.Visible := false
        btnProfileTabNext.Visible := false
        return
    }
    if profileTabStartIdx < 1 || profileTabStartIdx > names.Length {
        profileTabStartIdx := 1
        profileTabPageStack := []
    }
    selIdx := 0
    for i, n in names {
        if n = editingProfileName {
            selIdx := i
            break
        }
    }
    result := ""
    Loop {
        result := LayoutProfileTabsPage(names, profileTabStartIdx)
        if selIdx = 0 || (selIdx >= profileTabStartIdx && selIdx < result.idxAfter)
            break
        if !result.hasMoreAfter
            break
        profileTabPageStack.Push(profileTabStartIdx)
        profileTabStartIdx := result.idxAfter
    }
    PositionProfileTabArrows(result)
}

ProfileTabPageNext(*) {
    global profileTabStartIdx, profileTabPageStack
    names := BuildProfileNamesList()
    result := LayoutProfileTabsPage(names, profileTabStartIdx)
    if result.hasMoreAfter {
        profileTabPageStack.Push(profileTabStartIdx)
        profileTabStartIdx := result.idxAfter
    }
    RenderProfileTabStrip()
}

ProfileTabPagePrev(*) {
    global profileTabStartIdx, profileTabPageStack
    if profileTabPageStack.Length > 0
        profileTabStartIdx := profileTabPageStack.Pop()
    RenderProfileTabStrip()
}

ProfileTabClick(name, *) {
    global editingProfileName, editingId, lastCaptureKind, capturedMouseButton, editingListName
    if name = editingProfileName
        return
    editingProfileName := name
    RestoreEditingListForCurrentProfile()
    RefreshList()
    if editingId != "" {
        editingId := ""
        txtCaptureStatus.Value := "Not editing a mapping - fields kept; use Add to save them to this profile."
    } else if lastCaptureKind = "mouse" && capturedMouseButton != "" && InStr(txtCaptureStatus.Value, "Captured mouse button") = 1 {
        hint := " - not allowed on M (Main) in Default profile"
        st := StrReplace(txtCaptureStatus.Value, hint, "")
        if MouseButtonRemapBlockedInProfile(capturedMouseButton, editingProfileName, editingListName)
            st .= hint
        txtCaptureStatus.Value := st
    }
    UpdateAddDevTabLock()
    RefreshProfileList()
}

SetEditingList(name) {
    global editingListName, editingListNameByProfileKey, editingDevTab, editingProfileName
    editingListName := name
    radListMain.Value := (name = "Main") ? 1 : 0
    radListMod.Value := (name = "Mod") ? 1 : 0
    radListMod2.Value := (name = "Mod2") ? 1 : 0
    editingListNameByProfileKey[ProfileKey(editingDevTab, editingProfileName)] := name
    RefreshList()
    ResetCaptureUI()
}

RestoreEditingListForCurrentProfile() {
    global editingListName, editingListNameByProfileKey, editingDevTab, editingProfileName
    key := ProfileKey(editingDevTab, editingProfileName)
    editingListName := editingListNameByProfileKey.Has(key) ? editingListNameByProfileKey[key] : "Main"
    radListMain.Value := (editingListName = "Main") ? 1 : 0
    radListMod.Value := (editingListName = "Mod") ? 1 : 0
    radListMod2.Value := (editingListName = "Mod2") ? 1 : 0
}

SetEditingDevTab(name) {
    global editingDevTab, editingProfileName, editingProfileNameByTab, profiles
    editingProfileNameByTab[editingDevTab] := editingProfileName
    editingDevTab := name
    tabDevFilter.Value := (name = "Mouse") ? 1 : (name = "Keyboard") ? 2 : 3
    editingProfileName := editingProfileNameByTab.Has(name) ? editingProfileNameByTab[name] : "Default"
    if editingProfileName != "Default" {
        if !profiles.Has(ProfileKey(editingDevTab, editingProfileName))
            editingProfileName := "Default"
    }
    RestoreEditingListForCurrentProfile()
    RefreshProfileList()
    RefreshList()
    ResetCaptureUI()
    UpdateAddDevTabLock()
    RefreshModifierGroupBoxForTag()
    RefreshModifierLiveIndicator()
    SaveEditingDevTab()
}

OnDevFilterTabChanged() {
    idx := tabDevFilter.Value
    name := (idx = 1) ? "Mouse" : ((idx = 2) ? "Keyboard" : "Remote")
    SetEditingDevTab(name)
}

SelectedAddDevTab() {
    if radAddKeyboard.Value
        return "Keyboard"
    if radAddMouse.Value
        return "Mouse"
    return "Remote"
}

SetAddDevTabSelection(name) {
    radAddKeyboard.Value := (name = "Keyboard") ? 1 : 0
    radAddMouse.Value := (name = "Mouse") ? 1 : 0
    radAddRemote.Value := (name = "Remote") ? 1 : 0
}

UpdateAddDevTabLock() {
    global editingProfileName, editingDevTab
    SetAddDevTabSelection(editingDevTab)
    locked := editingProfileName != "Default"
    radAddMouse.Enabled := !locked || editingDevTab = "Mouse"
    radAddKeyboard.Enabled := !locked || editingDevTab = "Keyboard"
    radAddRemote.Enabled := !locked || editingDevTab = "Remote"
}

OpenProfileDialog(mode) {
    global editingProfileName, editingDevTab, profiles
    if mode = "rename" && editingProfileName = "Default" {
        MsgBox("The Default profile can't be edited.", "Not allowed", "Icon!")
        return
    }
    existingKey := mode = "rename" ? ProfileKey(editingDevTab, editingProfileName) : ""
    existingName := mode = "rename" ? editingProfileName : ""
    if mode = "rename" && !profiles.Has(existingKey) {
        MsgBox("That profile could not be found on the '" editingDevTab "' tab. Re-select it from the list and try again.", "Profile not found", "Icon!")
        return
    }
    existingProcCsv := mode = "rename" ? JoinCsv(profiles[existingKey].processNames) : ""
    existingDevTab := (mode = "rename" && profiles[existingKey].HasOwnProp("devTab")) ? profiles[existingKey].devTab : editingDevTab
    ptDevTab := existingDevTab
    if mode = "rename" {
        pmSrc := profiles[existingKey]
        pmKind := ProfModKind(pmSrc)
        pmSc := ProfModSc(pmSrc)
        pmRawPage := pmSrc.HasOwnProp("modRawPage") ? pmSrc.modRawPage : 0
        pmRawBytesHex := pmSrc.HasOwnProp("modRawBytesHex") ? pmSrc.modRawBytesHex : ""
        pmRawUpBytesHex := pmSrc.HasOwnProp("modRawUpBytesHex") ? pmSrc.modRawUpBytesHex : ""
        pmMode := Mod1ModeOf(pmSrc)
        pm2Kind := ProfMod2Kind(pmSrc)
        pm2Sc := ProfMod2Sc(pmSrc)
        pm2RawPage := pmSrc.HasOwnProp("mod2RawPage") ? pmSrc.mod2RawPage : 0
        pm2RawBytesHex := pmSrc.HasOwnProp("mod2RawBytesHex") ? pmSrc.mod2RawBytesHex : ""
        pm2RawUpBytesHex := pmSrc.HasOwnProp("mod2RawUpBytesHex") ? pmSrc.mod2RawUpBytesHex : ""
        pm2Mode := StoredModeOf(pmSrc, "mod2Mode")
        pmLpOnInit := LpOnOf(pmSrc, "modLpOn")
        pmLpMsInit := LpMsOf(pmSrc, "modLpMs")
        pm2LpOnInit := LpOnOf(pmSrc, "mod2LpOn")
        pm2LpMsInit := LpMsOf(pmSrc, "mod2LpMs")
    } else {
        pmKind := "none"
        pmSc := 0
        pmRawPage := 0
        pmRawBytesHex := ""
        pmRawUpBytesHex := ""
        pmMode := "toggle"
        pm2Kind := "none"
        pm2Sc := 0
        pm2RawPage := 0
        pm2RawBytesHex := ""
        pm2RawUpBytesHex := ""
        pm2Mode := ""
        pmLpOnInit := false
        pmLpMsInit := 500
        pm2LpOnInit := false
        pm2LpMsInit := 500
    }
    pmPtInit := (mode = "rename" && pmSrc.HasOwnProp("passthroughMod1")) ? !!pmSrc.passthroughMod1 : false
    pm2PtInit := (mode = "rename" && pmSrc.HasOwnProp("passthroughMod2")) ? !!pmSrc.passthroughMod2 : false
    pmLedInit := ProfileLedFieldsFrom(mode = "rename" ? profiles[existingKey] : "")

    gp := Gui("+Owner" g.Hwnd, mode = "rename" ? "Edit Profile" : "New Profile")
    gp.SetFont("s10", "Segoe UI")
    gp.Add("Text", "xm y10", "Profile name:")
    edName := gp.Add("Edit", "x+10 yp-3 w200", existingName)
    gp.Add("Text", "xm y+12 w420", "Process names this profile activates for (comma-separated, e.g. kodi.exe, kodi64.exe):")
    edProc := gp.Add("Edit", "xm y+6 w330 r2 Multi -WantReturn VScroll", existingProcCsv)
    btnBrowseProc := gp.Add("Button", "x+8 w80", "Browse...")
    btnBrowseProc.OnEvent("Click", (*) => BrowseForProcessNameInto(edProc))
    procRowBottom := CenterPmRow([edProc, btnBrowseProc])

    gp.Add("Text", "xm y" (procRowBottom + 15), "Tag as:")
    radPtMouse := gp.Add("Radio", "x+8 yp w60 +0x8 Group", "Mouse")
    radPtMouse.OnEvent("Click", (*) => (ptDevTab := "Mouse", UpdatePmUI()))
    radPtKeyboard := gp.Add("Radio", "x+5 yp w90 +0x8", "Keyboard")
    radPtKeyboard.OnEvent("Click", (*) => (ptDevTab := "Keyboard", UpdatePmUI()))
    radPtRemote := gp.Add("Radio", "x+5 yp w70 +0x8", "Remote")
    radPtRemote.OnEvent("Click", (*) => (ptDevTab := "Remote", UpdatePmUI()))
    radPtMouse.Value := (existingDevTab = "Mouse") ? 1 : 0
    radPtKeyboard.Value := (existingDevTab = "Keyboard") ? 1 : 0
    radPtRemote.Value := (existingDevTab = "Remote") ? 1 : 0

    grpPm := gp.Add("GroupBox", "xm y+15 w420 h130", "Mod 1 button (this profile only)")
    btnPmCapture := gp.Add("Button", "xp12 yp20 w110", "Capture")
    btnPmCaptureRaw := gp.Add("Button", "x+12 yp", "Capture raw HID")
    btnPmClear := gp.Add("Button", "x+12 yp w110", "Clear (use main)")
    CenterPmRow([btnPmCapture, btnPmCaptureRaw, btnPmClear])
    txtPmStatus := gp.Add("Text", "xm+12 y+10 w396", "Not set (using main modifier)")

    CenterPmRow(cprCtls) {
        cprRowY := ""
        cprRowH := 0
        for cprCtl in cprCtls {
            cprCtl.GetPos(, &cprY, , &cprH)
            if cprRowY = "" || cprY < cprRowY
                cprRowY := cprY
            if cprH > cprRowH
                cprRowH := cprH
        }
        for cprCtl in cprCtls {
            cprCtl.GetPos(, , , &cprH)
            cprCtl.Move(, cprRowY + Round((cprRowH - cprH) / 2))
        }
        return cprRowY + cprRowH
    }

    lblPmModeCaption := gp.Add("Text", "xm+12 y+8", "Mode:")
    ddlPmMode := gp.Add("DropDownList", "x+8 yp w90 Choose1", ["Held", "Toggle"])
    chkPmLp := gp.Add("Checkbox", "x+20 yp", "Long press")
    chkPmLp.Value := pmLpOnInit ? 1 : 0
    edPmLpMs := gp.Add("Edit", "x+8 yp w55", pmLpMsInit)
    lblPmLpMsUnit := gp.Add("Text", "x+6 yp", "ms")
    pmLpRowBottom := CenterPmRow([lblPmModeCaption, ddlPmMode, chkPmLp, edPmLpMs, lblPmLpMsUnit])
    txtPmLpHint := gp.Add("Text", "xm+12 y" (pmLpRowBottom + 4) " w396 c808080", "Unavailable: this button has no release report")
    txtPmLpHint.GetPos(, &pmLpHintY, , &pmLpHintH)
    grpPm.GetPos(, &pmGrpY)
    chkPmPt := gp.Add("Checkbox", "xm+12 y" (pmLpHintY + pmLpHintH + 8), "Passthrough (don't suppress on combo)")
    chkPmPt.Value := pmPtInit ? 1 : 0
    chkPmPt.GetPos(, &chkPmPtY, , &chkPmPtH)
    grpPm.Move(, , , chkPmPtY + chkPmPtH + 10 - pmGrpY)
    chkPmLp.OnEvent("Click", (*) => UpdatePmLpUI())
    edPmLpMs.OnEvent("LoseFocus", (*) => edPmLpMs.Value := ParseLpMs(edPmLpMs.Value))
    ddlPmMode.OnEvent("Change", (*) => (pmMode := ddlPmMode.Value = 2 ? "toggle" : "hold", UpdatePmUI()))

    RefreshPmStatus() {
        if pmKind = "sc"
            txtPmStatus.Value := Format("Modifier: SC{:03X}", pmSc)
        else if pmKind = "raw" {
            holdNote := pmRawUpBytesHex != "" ? " - Hold capable" : " - Single shot"
            pmMouseKey := StdMouseButtonFromRawReport(pmRawPage, pmRawBytesHex)
            if pmMouseKey != ""
                txtPmStatus.Value := "Modifier: " MouseButtonDisplayName(pmMouseKey) holdNote
            else
                txtPmStatus.Value := Format("Modifier: Raw Page:0x{:X} Bytes:{}{}", pmRawPage, pmRawBytesHex, holdNote)
        } else
            txtPmStatus.Value := "Not set (using main modifier)"
    }
    UpdatePmModeUI() {
        if pmKind = "raw" && pmRawUpBytesHex = "" {
            pmMode := "toggle"
            ddlPmMode.Choose(2)
            ddlPmMode.Enabled := false
        } else {
            ddlPmMode.Enabled := true
            ddlPmMode.Choose(pmMode = "toggle" ? 2 : 1)
        }
    }

    UpdatePmLpUI() {
        pmLpOwn := pmKind != "none"
        pmLpNoRelease := IsHoldIncapableMod({kind: pmKind, rawUpBytesHex: pmRawUpBytesHex})
        pmLpBlocked := !pmLpOwn || pmLpNoRelease
        chkPmLp.Enabled := !pmLpBlocked
        edPmLpMs.Enabled := !pmLpBlocked && chkPmLp.Value = 1
        chkPmPt.Enabled := !pmLpBlocked
        if !pmLpOwn
            txtPmLpHint.Value := "Needs its own button (else main settings apply)"
        else if pmLpNoRelease
            txtPmLpHint.Value := "Unavailable: this button has no release report"
        else
            txtPmLpHint.Value := ""
    }
    RefreshPmStatus()

    StartProfileModifierCaptureForSlot(slot, statusCtrl, applySc, applyRaw) {
        global profileModCaptureSuspendedBySlot, profileModCaptureHookBySlot
        CancelPendingProfileModifierCaptureForSlot(slot)
        profileModCaptureSuspendedBySlot[slot] := true
        IncrementCaptureSuspend()
        statusCtrl.Value := "Waiting for a key, mouse button or wheel notch..."
        mouseOwner := slot = "Mod2" ? "pmod2" : "pmod1"
        profileModCaptureHookBySlot[slot] := NewCaptureInputHook((ihObj, VK, SC) => (
            ihObj.Stop(),
            CancelModifierMouseCapture(mouseOwner),
            applySc(SC),
            UpdatePmUI(),
            ResumeProfileModifierHotkeysIfNeededForSlot(slot)))
        BeginModifierMouseCapture(mouseOwner, (buttonKey) => ProfileModifierMouseCapturedForSlot(buttonKey, applyRaw, slot))
    }
    StartProfileModifierCapture(*) {
        StartProfileModifierCaptureForSlot("Mod", txtPmStatus,
            (SC) => (pmKind := "sc", pmSc := SC, pmRawPage := 0, pmRawBytesHex := "", pmRawUpBytesHex := "", RefreshPmStatus()),
            (page, bytesHex, upBytesHex) => (pmKind := "raw", pmRawPage := page, pmRawBytesHex := bytesHex, pmRawUpBytesHex := upBytesHex, pmSc := 0, RefreshPmStatus(), UpdatePmUI()))
    }
    StartProfileModifierRawCaptureForSlot(slot, statusCtrl, applyRaw, armFn) {
        global profileModRawCaptureArmedBySlot, profileModCaptureCallbackBySlot, profileModCaptureStatusCallbackBySlot
        CancelPendingProfileModifierCaptureForSlot(slot)
        profileModRawCaptureArmedBySlot[slot] := false
        statusCtrl.Value := "Get ready... (waiting for your click to finish)"
        profileModCaptureCallbackBySlot[slot] := applyRaw
        profileModCaptureStatusCallbackBySlot[slot] := (text) => statusCtrl.Value := text
        SetTimer(armFn, -300)
    }
    StartProfileModifierRawCapture(*) {
        StartProfileModifierRawCaptureForSlot("Mod", txtPmStatus,
            (page, bytesHex, upBytesHex) => (pmKind := "raw", pmRawPage := page, pmRawBytesHex := bytesHex, pmRawUpBytesHex := upBytesHex, pmSc := 0, RefreshPmStatus(), UpdatePmUI()),
            ArmProfileModifierRawCapture)
    }
    ArmProfileModifierRawCaptureForSlot(slot, statusCtrl) {
        global profileModRawCaptureArmedBySlot
        profileModRawCaptureArmedBySlot[slot] := true
        statusCtrl.Value := "Waiting for button press (raw HID)..."
    }
    ArmProfileModifierRawCapture() {
        ArmProfileModifierRawCaptureForSlot("Mod", txtPmStatus)
    }
    btnPmCapture.OnEvent("Click", StartProfileModifierCapture)
    btnPmCaptureRaw.OnEvent("Click", StartProfileModifierRawCapture)
    btnPmClear.OnEvent("Click", (*) => (
        CancelPendingProfileModifierCapture(),
        pmKind := "none",
        pmSc := 0,
        pmRawPage := 0,
        pmRawBytesHex := "",
        pmRawUpBytesHex := "",
        pmMode := "toggle",
        chkPmLp.Value := 0,
        edPmLpMs.Value := 500,
        RefreshPmStatus(),
        UpdatePmUI()))

    grpPm.GetPos(, &pmGrp1Y, , &pmGrp1H)
    grpPm2 := gp.Add("GroupBox", "xm y" (pmGrp1Y + pmGrp1H + 12) " w420 h150", "Mod 2 button (this profile only)")
    btnPm2Capture := gp.Add("Button", "xp12 yp20 w110", "Capture")
    btnPm2CaptureRaw := gp.Add("Button", "x+12 yp", "Capture raw HID")
    btnPm2Clear := gp.Add("Button", "x+12 yp w110", "Clear (use main)")
    CenterPmRow([btnPm2Capture, btnPm2CaptureRaw, btnPm2Clear])
    txtPm2Status := gp.Add("Text", "xm+12 y+10 w396", "Not set (using main modifier)")
    lblPm2ModeCaption := gp.Add("Text", "xm+12 y+8", "Mode:")
    ddlPm2Mode := gp.Add("DropDownList", "x+8 yp w90 Choose1", ["Held", "Toggle"])
    chkPm2Lp := gp.Add("Checkbox", "x+20 yp", "Long press")
    chkPm2Lp.Value := pm2LpOnInit ? 1 : 0
    edPm2LpMs := gp.Add("Edit", "x+8 yp w55", pm2LpMsInit)
    lblPm2LpMsUnit := gp.Add("Text", "x+6 yp", "ms")
    pm2LpRowBottom := CenterPmRow([lblPm2ModeCaption, ddlPm2Mode, chkPm2Lp, edPm2LpMs, lblPm2LpMsUnit])
    txtPm2LpHint := gp.Add("Text", "xm+12 y" (pm2LpRowBottom + 4) " w396 c808080", "Unavailable: this button has no release report")
    txtPm2LpHint.GetPos(, &pm2LpHintY, , &pm2LpHintH)
    grpPm2.GetPos(, &pm2GrpY)
    chkPm2Pt := gp.Add("Checkbox", "xm+12 y" (pm2LpHintY + pm2LpHintH + 8), "Passthrough (don't suppress on combo)")
    chkPm2Pt.Value := pm2PtInit ? 1 : 0
    chkPm2Pt.GetPos(, &chkPm2PtY, , &chkPm2PtH)
    grpPm2.Move(, , , chkPm2PtY + chkPm2PtH + 10 - pm2GrpY)
    ddlPm2Mode.OnEvent("Change", (*) => (pm2Mode := ddlPm2Mode.Value = 2 ? "toggle" : "hold"))
    chkPm2Lp.OnEvent("Click", (*) => UpdatePm2UI())
    edPm2LpMs.OnEvent("LoseFocus", (*) => edPm2LpMs.Value := ParseLpMs(edPm2LpMs.Value))

    RefreshPm2Status() {
        if pm2Kind = "sc"
            txtPm2Status.Value := Format("Modifier: SC{:03X}", pm2Sc)
        else if pm2Kind = "raw" {
            holdNote := pm2RawUpBytesHex != "" ? " - Hold capable" : " - Single shot"
            pm2MouseKey := StdMouseButtonFromRawReport(pm2RawPage, pm2RawBytesHex)
            if pm2MouseKey != ""
                txtPm2Status.Value := "Modifier: " MouseButtonDisplayName(pm2MouseKey) holdNote
            else
                txtPm2Status.Value := Format("Modifier: Raw Page:0x{:X} Bytes:{}{}", pm2RawPage, pm2RawBytesHex, holdNote)
        } else
            txtPm2Status.Value := "Not set (using main modifier)"
    }

    PmFollowedMod1Mode() {
        global deviceModifiers
        return pmKind != "none" ? pmMode : deviceModifiers[ptDevTab].mode
    }

    UpdatePm2UI() {
        pm2UiOwn := pm2Kind != "none"
        pm2UiNoRelease := IsHoldIncapableMod({kind: pm2Kind, rawUpBytesHex: pm2RawUpBytesHex})
        if pm2UiNoRelease
            ddlPm2Mode.Choose(2)
        else {
            pm2UiShown := pm2Mode != "" ? pm2Mode : PmFollowedMod1Mode()
            ddlPm2Mode.Choose(pm2UiShown = "toggle" ? 2 : 1)
        }
        pm2UiUsable := pm2UiOwn && !pm2UiNoRelease
        ddlPm2Mode.Enabled := pm2UiUsable
        chkPm2Lp.Enabled := pm2UiUsable
        edPm2LpMs.Enabled := pm2UiUsable && chkPm2Lp.Value = 1
        chkPm2Pt.Enabled := pm2UiUsable
        if !pm2UiOwn
            txtPm2LpHint.Value := "Needs its own button (else main settings apply)"
        else if pm2UiNoRelease
            txtPm2LpHint.Value := "Toggle only: this button has no release report"
        else
            txtPm2LpHint.Value := ""
    }

    UpdatePmUI() {
        UpdatePmModeUI()
        UpdatePmLpUI()
        UpdatePm2UI()
    }
    RefreshPm2Status()
    UpdatePmUI()

    StartProfileModifier2Capture(*) {
        StartProfileModifierCaptureForSlot("Mod2", txtPm2Status,
            (SC) => (pm2Kind := "sc", pm2Sc := SC, pm2RawPage := 0, pm2RawBytesHex := "", pm2RawUpBytesHex := "", RefreshPm2Status()),
            (page, bytesHex, upBytesHex) => (pm2Kind := "raw", pm2RawPage := page, pm2RawBytesHex := bytesHex, pm2RawUpBytesHex := upBytesHex, pm2Sc := 0, RefreshPm2Status(), UpdatePmUI()))
    }
    StartProfileModifier2RawCapture(*) {
        StartProfileModifierRawCaptureForSlot("Mod2", txtPm2Status,
            (page, bytesHex, upBytesHex) => (pm2Kind := "raw", pm2RawPage := page, pm2RawBytesHex := bytesHex, pm2RawUpBytesHex := upBytesHex, pm2Sc := 0, RefreshPm2Status(), UpdatePmUI()),
            ArmProfileModifier2RawCapture)
    }
    ArmProfileModifier2RawCapture() {
        ArmProfileModifierRawCaptureForSlot("Mod2", txtPm2Status)
    }
    btnPm2Capture.OnEvent("Click", StartProfileModifier2Capture)
    btnPm2CaptureRaw.OnEvent("Click", StartProfileModifier2RawCapture)
    btnPm2Clear.OnEvent("Click", (*) => (
        CancelPendingProfileModifier2Capture(),
        pm2Kind := "none",
        pm2Sc := 0,
        pm2RawPage := 0,
        pm2RawBytesHex := "",
        pm2RawUpBytesHex := "",
        pm2Mode := "",
        chkPm2Lp.Value := 0,
        edPm2LpMs.Value := 500,
        RefreshPm2Status(),
        UpdatePmUI()))

    grpPm2.GetPos(, &pmGrp2Y, , &pmGrp2H)

    pmCol2X := gp.MarginX + 420 + 20
    grpPmLed := gp.Add("GroupBox", "x" pmCol2X " y" pmGrp1Y " w420 h150", "LED indicator and notification (this profile only)")
    lblPmNotify := gp.Add("Text", "xp12 yp24", "Notification on modifier toggle:")
    ddlPmNotify := gp.Add("DropDownList", "x+8 yp w150 Choose1", ["Follow tab default", "On", "Off"])
    ddlPmNotify.Choose(pmLedInit.notifyToggle = "On" ? 2 : pmLedInit.notifyToggle = "Off" ? 3 : 1)
    pmNotifyBottom := CenterPmRow([lblPmNotify, ddlPmNotify])

    pmLedChoiceNames := ["Inherit", "Off", "ScrollLock", "CapsLock", "NumLock"]
    pmLedDdlItems := ["Follow tab default", "Off", "Scroll Lock", "Caps Lock", "Num Lock"]
    lblPmLed1 := gp.Add("Text", "x" (pmCol2X + 12) " y" (pmNotifyBottom + 12) " w80", "Mod 1 LED:")
    ddlPmLed1 := gp.Add("DropDownList", "x+8 yp w140 Choose1", pmLedDdlItems)
    chkPmFl1 := gp.Add("Checkbox", "x+12 yp w55", "Flash")
    edPmFl1 := gp.Add("Edit", "x+8 yp w50", 500)
    lblPmFlUnit1 := gp.Add("Text", "x+6 yp", "ms")
    pmLed1Bottom := CenterPmRow([lblPmLed1, ddlPmLed1, chkPmFl1, edPmFl1, lblPmFlUnit1])
    lblPmLed2 := gp.Add("Text", "x" (pmCol2X + 12) " y" (pmLed1Bottom + 8) " w80", "Mod 2 LED:")
    ddlPmLed2 := gp.Add("DropDownList", "x+8 yp w140 Choose1", pmLedDdlItems)
    chkPmFl2 := gp.Add("Checkbox", "x+12 yp w55", "Flash")
    edPmFl2 := gp.Add("Edit", "x+8 yp w50", 500)
    lblPmFlUnit2 := gp.Add("Text", "x+6 yp", "ms")
    pmLed2Bottom := CenterPmRow([lblPmLed2, ddlPmLed2, chkPmFl2, edPmFl2, lblPmFlUnit2])
    txtPmLedHint := gp.Add("Text", "x" (pmCol2X + 12) " y" (pmLed2Bottom + 6) " w396 c808080", "Follow tab default = use the main window's setting for this tab.")
    txtPmLedHint.GetPos(, &pmLedHintY, , &pmLedHintH)
    grpPmLed.GetPos(, &pmGrpLedY)
    grpPmLed.Move(, , , pmLedHintY + pmLedHintH + 10 - pmGrpLedY)
    grpPmLed.GetPos(, &pmGrpLedY, , &pmGrpLedH)

    pmLedState := [
        {choice: pmLedInit.ledChoice, shown: ""
            , fl: Map("ScrollLock", {on: pmLedInit.scrollFlashOn, ms: pmLedInit.scrollFlashMs}
                , "CapsLock", {on: pmLedInit.capsFlashOn, ms: pmLedInit.capsFlashMs}
                , "NumLock", {on: pmLedInit.numFlashOn, ms: pmLedInit.numFlashMs})},
        {choice: pmLedInit.ledChoice2, shown: ""
            , fl: Map("ScrollLock", {on: pmLedInit.scrollFlashOn2, ms: pmLedInit.scrollFlashMs2}
                , "CapsLock", {on: pmLedInit.capsFlashOn2, ms: pmLedInit.capsFlashMs2}
                , "NumLock", {on: pmLedInit.numFlashOn2, ms: pmLedInit.numFlashMs2})}]
    pmLedDdl := [ddlPmLed1, ddlPmLed2]
    pmLedChk := [chkPmFl1, chkPmFl2]
    pmLedEd := [edPmFl1, edPmFl2]

    PmLedCommit(plcM) {
        plcSt := pmLedState[plcM]
        if plcSt.shown = "" || !plcSt.fl.Has(plcSt.shown)
            return
        plcSt.fl[plcSt.shown].on := pmLedChk[plcM].Value = 1
        plcSt.fl[plcSt.shown].ms := SanitizeFlashIntervalMs(pmLedEd[plcM].Value)
    }
    PmLedShow(plsM) {
        plsSt := pmLedState[plsM]
        plsIdx := 1
        for plsI, plsName in pmLedChoiceNames {
            if plsName = plsSt.choice
                plsIdx := plsI
        }
        pmLedDdl[plsM].Choose(plsIdx)
        plsIsLock := plsSt.fl.Has(plsSt.choice)
        if plsIsLock {
            pmLedChk[plsM].Value := plsSt.fl[plsSt.choice].on ? 1 : 0
            pmLedEd[plsM].Value := plsSt.fl[plsSt.choice].ms
            plsSt.shown := plsSt.choice
        } else {
            pmLedChk[plsM].Value := 0
            pmLedEd[plsM].Value := 500
            plsSt.shown := ""
        }
        pmLedChk[plsM].Enabled := plsIsLock
        pmLedEd[plsM].Enabled := plsIsLock && pmLedChk[plsM].Value = 1
    }
    PmLedDdlChanged(pldM) {
        PmLedCommit(pldM)
        pmLedState[pldM].choice := pmLedChoiceNames[pmLedDdl[pldM].Value]
        PmLedShow(pldM)
    }
    PmLedFlashChanged(plfM) {
        PmLedCommit(plfM)
        PmLedShow(plfM)
    }
    PmLedResult() {
        PmLedCommit(1)
        PmLedCommit(2)
        plrOut := {notifyToggle: (ddlPmNotify.Value = 2) ? "On" : (ddlPmNotify.Value = 3) ? "Off" : "Inherit"}
        for plrM in [1, 2] {
            plrSfx := (plrM = 2) ? "2" : ""
            plrChoiceFld := "ledChoice" plrSfx
            plrOut.%plrChoiceFld% := pmLedState[plrM].choice
            for plrPair in [["scroll", "ScrollLock"], ["caps", "CapsLock"], ["num", "NumLock"]] {
                plrEnFld := plrPair[1] "FlashOn" plrSfx
                plrMsFld := plrPair[1] "FlashMs" plrSfx
                plrSlot := pmLedState[plrM].fl[plrPair[2]]
                plrOut.%plrEnFld% := plrSlot.on
                plrOut.%plrMsFld% := plrSlot.ms
            }
        }
        return plrOut
    }
    ddlPmLed1.OnEvent("Change", (*) => PmLedDdlChanged(1))
    ddlPmLed2.OnEvent("Change", (*) => PmLedDdlChanged(2))
    chkPmFl1.OnEvent("Click", (*) => PmLedFlashChanged(1))
    chkPmFl2.OnEvent("Click", (*) => PmLedFlashChanged(2))
    edPmFl1.OnEvent("LoseFocus", (*) => PmLedFlashChanged(1))
    edPmFl2.OnEvent("LoseFocus", (*) => PmLedFlashChanged(2))
    PmLedShow(1)
    PmLedShow(2)
    btnSave := gp.Add("Button", "xm y" (Max(pmGrp2Y + pmGrp2H, pmGrpLedY + pmGrpLedH) + 12) " w100", "Save")
    btnSave.OnEvent("Click", (*) => SaveProfileDialog(mode, existingKey, edName.Value, edProc.Value, pmKind, pmSc, pmRawPage, pmRawBytesHex, pmRawUpBytesHex, pmMode, pm2Kind, pm2Sc, pm2RawPage, pm2RawBytesHex, pm2RawUpBytesHex, ptDevTab, gp
        , {modLpOn: chkPmLp.Value, modLpMs: edPmLpMs.Value, mod2Mode: pm2Mode, mod2LpOn: chkPm2Lp.Value, mod2LpMs: edPm2LpMs.Value, passthroughMod1: chkPmPt.Value, passthroughMod2: chkPm2Pt.Value, led: PmLedResult()}))
    btnCancel := gp.Add("Button", "x+10 w100", "Cancel")
    btnCancel.OnEvent("Click", (*) => (CancelPendingProfileModifierCapture(), CancelPendingProfileModifier2Capture(), gp.Destroy()))
    gp.OnEvent("Close", (*) => (CancelPendingProfileModifierCapture(), CancelPendingProfileModifier2Capture(), gp.Destroy()))
    gp.Show()
}

BrowseForProcessNameInto(edProc) {
    file := FileSelect(, , "Select application", "Executables (*.exe)")
    if file = ""
        return
    SplitPath(file, &exeName)
    current := Trim(edProc.Value)
    edProc.Value := current = "" ? exeName : current ", " exeName
}

FindProcessNameConflicts(procList, excludeKey, devTab) {
    global profiles
    conflicts := ""
    for procName in procList {
        for pkey, pdata in profiles {
            if pkey = "Default" || pkey = excludeKey
                continue
            if ProfileKeyTab(pkey) != devTab
                continue
            for other in pdata.processNames {
                if other = procName {
                    conflicts .= Format("`n- '{}' is already claimed by the {} profile '{}'", procName, devTab, ProfileKeyName(pkey))
                    break
                }
            }
        }
    }
    return conflicts
}

SaveProfileDialog(mode, oldKey, newNameRaw, procCsv, pmKind, pmSc, pmRawPage, pmRawBytesHex, pmRawUpBytesHex, pmMode, pm2Kind, pm2Sc, pm2RawPage, pm2RawBytesHex, pm2RawUpBytesHex, ptDevTab, gp, lpx) {
    global profiles, profileOrder, editingProfileName, activeProfileNameByTab, mappings, mapOrder
    global activeListByTag
    global editingListNameByProfileKey
    CancelPendingProfileModifierCapture()
    CancelPendingProfileModifier2Capture()
    lpModLpOn := lpx.modLpOn ? true : false
    lpModLpMs := ParseLpMs(lpx.modLpMs)
    lpMod2Mode := (lpx.mod2Mode = "hold" || lpx.mod2Mode = "toggle") ? lpx.mod2Mode : ""
    lpMod2LpOn := lpx.mod2LpOn ? true : false
    lpMod2LpMs := ParseLpMs(lpx.mod2LpMs)
    lpPt1 := lpx.HasOwnProp("passthroughMod1") ? !!lpx.passthroughMod1 : false
    lpPt2 := lpx.HasOwnProp("passthroughMod2") ? !!lpx.passthroughMod2 : false
    lpLed := ProfileLedFieldsFrom(lpx.HasOwnProp("led") ? lpx.led : "")
    oldName := mode = "rename" ? ProfileKeyName(oldKey) : ""
    newName := Trim(newNameRaw)
    if newName = "" {
        MsgBox("Enter a profile name.", "Missing name", "Icon!")
        return
    }
    if InStr(newName, "::") {
        MsgBox("Profile names can't contain '::'.", "Invalid name", "Icon!")
        return
    }
    procList := []
    for p in StrSplit(procCsv, ",") {
        p := Trim(p)
        if p != ""
            procList.Push(p)
    }
    conflictMsg := FindProcessNameConflicts(procList, mode = "rename" ? oldKey : "", ptDevTab)
    if conflictMsg != "" {
        result := MsgBox("Some of these process names are already claimed by another profile on the same '" ptDevTab "' tab (whichever profile comes first wins at runtime):" conflictMsg "`n`nSave anyway?", "Process name conflict", "YesNo Icon!")
        if result != "Yes"
            return
    }
    newKey := ProfileKey(ptDevTab, newName)
    if newName = "Default" {
        MsgBox("'Default' is the built-in shared profile name and can't be reused.", "Name taken", "Icon!")
        return
    }
    if mode = "new" {
        if profiles.Has(newKey) {
            MsgBox("A profile named '" newName "' already exists on the '" ptDevTab "' tab.", "Name taken", "Icon!")
            return
        }
        profiles[newKey] := {processNames: procList, modKind: pmKind, modSc: pmSc, modRawPage: pmRawPage, modRawBytesHex: pmRawBytesHex, modRawUpBytesHex: pmRawUpBytesHex, modMode: pmMode, mod2Kind: pm2Kind, mod2Sc: pm2Sc, mod2RawPage: pm2RawPage, mod2RawBytesHex: pm2RawBytesHex, mod2RawUpBytesHex: pm2RawUpBytesHex, modLpOn: lpModLpOn, modLpMs: lpModLpMs, mod2Mode: lpMod2Mode, mod2LpOn: lpMod2LpOn, mod2LpMs: lpMod2LpMs, passthroughMod1: lpPt1, passthroughMod2: lpPt2, devTab: ptDevTab, enabled: true
            , ledChoice: "Inherit", scrollFlashOn: false, scrollFlashMs: 500, capsFlashOn: false, capsFlashMs: 500, numFlashOn: false, numFlashMs: 500
            , ledChoice2: "Inherit", scrollFlashOn2: false, scrollFlashMs2: 500, capsFlashOn2: false, capsFlashMs2: 500, numFlashOn2: false, numFlashMs2: 500
            , notifyToggle: "Inherit"}
        ApplyProfileLedFields(profiles[newKey], lpLed)
        profileOrder.Push(newKey)
        editingProfileName := newName
        RefreshProfileList()
        RefreshList()
        ResetCaptureUI()
        if pmKind = "sc"
            RegisterHotkeyForButton(Format("SC{:03X}", pmSc))
        if pm2Kind = "sc"
            RegisterHotkeyForButton(Format("SC{:03X}", pm2Sc))
        RebuildProfileIndex()
        InvalidateActiveProfileExeCache()
        InvalidateMouseBlockCache()
        SaveProfile(newKey)
        txtStatus.Value := "Created " ptDevTab " profile '" newName "'."
    } else {
        if newKey != oldKey && profiles.Has(newKey) {
            MsgBox("A profile named '" newName "' already exists on the '" ptDevTab "' tab.", "Name taken", "Icon!")
            return
        }
        if !profiles.Has(oldKey) {
            MsgBox("That profile could not be found any more. Re-select it from the list and try again.", "Profile not found", "Icon!")
            return
        }
        priorModKind := ProfModKind(profiles[oldKey])
        priorModSc := ProfModSc(profiles[oldKey])
        priorMod2Kind := ProfMod2Kind(profiles[oldKey])
        priorMod2Sc := ProfMod2Sc(profiles[oldKey])
        priorCfgSig := ProfileModCfgSig(profiles[oldKey])
        priorDevTab := ProfileKeyTab(oldKey)
        if priorDevTab = ""
            priorDevTab := profiles[oldKey].HasOwnProp("devTab") ? profiles[oldKey].devTab : ""
        if priorDevTab != "" && priorDevTab != ptDevTab {
            ownsOldTagMapping := false
            for key in mapOrder {
                if (MapProfileKey(mappings[key])) = oldKey {
                    ownsOldTagMapping := true
                    break
                }
            }
            if ownsOldTagMapping {
                MsgBox("This profile still has mappings tagged '" priorDevTab "'. Remove or re-tag those mappings before changing this profile's tag to '" ptDevTab "'.", "Tag change blocked", "Icon!")
                return
            }
        }
        ledResyncTag := ""
        if priorDevTab != "" && activeProfileNameByTab.Has(priorDevTab) && activeProfileNameByTab[priorDevTab] = oldName
            && activeListByTag.Has(priorDevTab) && activeListByTag[priorDevTab] != "Main"
            && ProfileLedSig(profiles[oldKey]) != ProfileLedSig(lpLed) {
            ReleaseLedsForProfile(priorDevTab, oldName)
            ledResyncTag := priorDevTab
        }
        profiles[oldKey].processNames := procList
        profiles[oldKey].modKind := pmKind
        profiles[oldKey].modSc := pmSc
        profiles[oldKey].modRawPage := pmRawPage
        profiles[oldKey].modRawBytesHex := pmRawBytesHex
        profiles[oldKey].modRawUpBytesHex := pmRawUpBytesHex
        profiles[oldKey].modMode := pmMode
        profiles[oldKey].mod2Kind := pm2Kind
        profiles[oldKey].mod2Sc := pm2Sc
        profiles[oldKey].mod2RawPage := pm2RawPage
        profiles[oldKey].mod2RawBytesHex := pm2RawBytesHex
        profiles[oldKey].mod2RawUpBytesHex := pm2RawUpBytesHex
        profiles[oldKey].modLpOn := lpModLpOn
        profiles[oldKey].modLpMs := lpModLpMs
        profiles[oldKey].mod2Mode := lpMod2Mode
        profiles[oldKey].mod2LpOn := lpMod2LpOn
        profiles[oldKey].mod2LpMs := lpMod2LpMs
        profiles[oldKey].passthroughMod1 := lpPt1
        profiles[oldKey].passthroughMod2 := lpPt2
        ApplyProfileLedFields(profiles[oldKey], lpLed)
        profiles[oldKey].devTab := ptDevTab
        if newKey != oldKey {
            profiles[newKey] := profiles[oldKey]
            profiles.Delete(oldKey)
            renamedAtPos := 0
            for i, k in profileOrder {
                if k = oldKey {
                    renamedAtPos := i
                    break
                }
            }
            if renamedAtPos
                profileOrder[renamedAtPos] := newKey
            else
                profileOrder.Push(newKey)
            if editingListNameByProfileKey.Has(oldKey) {
                editingListNameByProfileKey[newKey] := editingListNameByProfileKey[oldKey]
                editingListNameByProfileKey.Delete(oldKey)
            }
        }
        if newName != oldName {
            renamedIds := Map()
            claimedIds := Map()
            for key in mapOrder {
                m := mappings[key]
                if (MapProfileKey(m)) != oldKey
                    continue
                m.profile := newName
                suffix := SubStr(key, StrLen(oldName) + 3)
                newId := UniqueMappingId(newName "::" suffix, claimedIds)
                claimedIds[newId] := true
                renamedIds[key] := newId
            }
            for id, newId in renamedIds {
                mappings[newId] := mappings[id]
                mappings.Delete(id)
            }
            for i, key in mapOrder {
                if renamedIds.Has(key)
                    mapOrder[i] := renamedIds[key]
            }
            if activeProfileNameByTab[ptDevTab] = oldName
                activeProfileNameByTab[ptDevTab] := newName
            if priorDevTab != "" && priorDevTab != ptDevTab && activeProfileNameByTab[priorDevTab] = oldName
                activeProfileNameByTab[priorDevTab] := "Default"
            if editingProfileName = oldName
                editingProfileName := newName
            ResetCaptureUI()
        }
        if (priorModKind = "sc" && priorModSc) || (pmKind = "sc" && pmSc) {
            ResetModifierStateForTag(ptDevTab)
            if priorDevTab != "" && priorDevTab != ptDevTab
                ResetModifierStateForTag(priorDevTab)
            RefreshModifierLiveIndicator()
            if priorModKind = "sc" && priorModSc && priorModSc != pmSc
                RegisterHotkeyForButton(Format("SC{:03X}", priorModSc))
            if pmKind = "sc" && pmSc
                RegisterHotkeyForButton(Format("SC{:03X}", pmSc))
        }
        if (priorMod2Kind = "sc" && priorMod2Sc) || (pm2Kind = "sc" && pm2Sc) {
            ResetModifierStateForTag(ptDevTab)
            if priorDevTab != "" && priorDevTab != ptDevTab
                ResetModifierStateForTag(priorDevTab)
            RefreshModifierLiveIndicator()
            if priorMod2Kind = "sc" && priorMod2Sc && priorMod2Sc != pm2Sc
                RegisterHotkeyForButton(Format("SC{:03X}", priorMod2Sc))
            if pm2Kind = "sc" && pm2Sc
                RegisterHotkeyForButton(Format("SC{:03X}", pm2Sc))
        }
        if ProfileModCfgSig(profiles[newKey]) != priorCfgSig {
            ResetModifierStateForTag(ptDevTab)
            if priorDevTab != "" && priorDevTab != ptDevTab
                ResetModifierStateForTag(priorDevTab)
            RefreshModifierLiveIndicator()
        }
        if ledResyncTag != ""
            ApplyLedIndicatorForTag(ledResyncTag)
        RefreshProfileList()
        RefreshList()
        UpdateActiveProfileStatus()
        RebuildProfileIndex()
        InvalidateActiveProfileExeCache()
        InvalidateMouseBlockCache()
        SaveProfile(newKey)
        txtStatus.Value := "Updated profile '" newName "'."
    }
    gp.Destroy()
}

DeleteProfileFlow() {
    global editingProfileName, editingDevTab, profiles, profileOrder, mappings, mapOrder, activeProfileNameByTab, profileFiles, activeListByTag
    global editingListNameByProfileKey
    if editingProfileName = "Default" {
        MsgBox("The Default profile can't be deleted.", "Not allowed", "Icon!")
        return
    }
    target := editingProfileName
    targetKey := ProfileKey(editingDevTab, target)
    if !profiles.Has(targetKey) {
        MsgBox("That profile could not be found on the '" editingDevTab "' tab. Re-select it from the list and try again.", "Profile not found", "Icon!")
        return
    }
    count := 0
    for key in mapOrder {
        if (MapProfileKey(mappings[key])) = targetKey
            count++
    }
    result := MsgBox(Format("Delete the {} profile '{}'? This will permanently remove its {} mapping(s).`n`nProfiles with the same name on other tabs are not affected.", editingDevTab, target, count), "Delete Profile", "YesNo Icon!")
    if result != "Yes"
        return
    anchorRow := 1
    for i, n in BuildProfileNamesList() {
        if n = target {
            anchorRow := i
            break
        }
    }
    removeSet := Map()
    for key in mapOrder {
        if (MapProfileKey(mappings[key])) = targetKey
            removeSet[key] := true
    }
    buttonKeysToRefresh := Map()
    for key in removeSet {
        m := mappings[key]
        if (MapKind(m)) = "sc"
            buttonKeysToRefresh[Format("SC{:03X}", m.sc)] := true
        StopRepeat(key)
        mappings.Delete(key)
    }
    newOrder := []
    for key in mapOrder {
        if !removeSet.Has(key)
            newOrder.Push(key)
    }
    mapOrder := newOrder
    deletedModKind := ProfModKind(profiles[targetKey])
    deletedModSc := ProfModSc(profiles[targetKey])
    deletedMod2Kind := ProfMod2Kind(profiles[targetKey])
    deletedMod2Sc := ProfMod2Sc(profiles[targetKey])
    ledDelActive := activeProfileNameByTab[editingDevTab] = target
    if ledDelActive && activeListByTag.Has(editingDevTab) && activeListByTag[editingDevTab] != "Main"
        ReleaseLedsForProfile(editingDevTab, target)
    profiles.Delete(targetKey)
    if editingListNameByProfileKey.Has(targetKey)
        editingListNameByProfileKey.Delete(targetKey)
    for i, k in profileOrder {
        if k = targetKey {
            profileOrder.RemoveAt(i)
            break
        }
    }
    if ledDelActive {
        SwitchActiveProfile(editingDevTab, "Default")
        ApplyLedIndicatorForTag(editingDevTab)
    } else {
        if deletedModKind = "sc" && deletedModSc
            RegisterHotkeyForButton(Format("SC{:03X}", deletedModSc))
        if deletedMod2Kind = "sc" && deletedMod2Sc
            RegisterHotkeyForButton(Format("SC{:03X}", deletedMod2Sc))
    }
    for bk in buttonKeysToRefresh
        RegisterHotkeyForButton(bk)
    if editingProfileName = target {
        namesAfter := BuildProfileNamesList()
        newIdx := Min(anchorRow, namesAfter.Length)
        editingProfileName := namesAfter[newIdx]
        RestoreEditingListForCurrentProfile()
    }
    RefreshProfileList()
    RefreshList()
    ResetCaptureUI()
    fileFate := "deleted"
    oldProfilePath := ""
    if profileFiles.Has(targetKey) {
        oldProfilePath := profileFiles[targetKey]
        fileFate := DeleteProfileFileOrNeutralize(oldProfilePath)
    }
    RebuildProfileIndex()
    InvalidateActiveProfileExeCache()
    InvalidateMouseBlockCache()
    if fileFate = "stuck" {
        txtStatus.Value := "Deleted " editingDevTab " profile '" target "', but its file couldn't be removed or cleared."
        MsgBox("The profile '" target "' was removed from the app, but its file could not be deleted or emptied:`n`n" oldProfilePath "`n`nIt may reappear (with its old mappings) the next time the app starts. Close anything that has the file open (or pause your sync client), then delete it manually.", "Profile file still on disk", "Icon!")
    } else if fileFate = "emptied" {
        txtStatus.Value := "Deleted " editingDevTab " profile '" target "' and its mappings, but its file couldn't be removed (contents cleared). An empty '" target "' profile may reappear on next start - delete it again then."
    } else
        txtStatus.Value := "Deleted " editingDevTab " profile '" target "' and its mappings."
}

ToggleProfileEnabledFlow() {
    global editingProfileName, editingDevTab, profiles, activeProfileNameByTab
    if editingProfileName = "Default" {
        MsgBox("The Default profile can't be disabled.", "Not allowed", "Icon!")
        return
    }
    pkey := ProfileKey(editingDevTab, editingProfileName)
    if !profiles.Has(pkey) {
        MsgBox("That profile could not be found on the '" editingDevTab "' tab. Re-select it from the list and try again.", "Profile not found", "Icon!")
        return
    }
    newEnabled := !ProfileIsEnabled(pkey)
    profiles[pkey].enabled := newEnabled
    if !newEnabled && activeProfileNameByTab[editingDevTab] = editingProfileName
        SwitchActiveProfile(editingDevTab, "Default")
    RebuildProfileIndex()
    InvalidateActiveProfileExeCache()
    InvalidateMouseBlockCache()
    SaveProfile(pkey)
    RefreshProfileList()
    txtStatus.Value := newEnabled
        ? "Enabled profile '" editingProfileName "'."
        : "Disabled profile '" editingProfileName "' - it won't become active until re-enabled."
}
