
LoadLegacyMappings() {
    global legacyLoadFailed
    global masterEnabled, mappings, mapOrder, startHidden, legacyLongPressMs, MinHoldReleaseGapMs
    global profiles, appWatchEnabled, notifyModifierToggleByTag, ledIndicatorChoiceByTag, capsLockLedDeviceIndex, runElevated, runAtStartup, runAtStartupMode
    global ledIndicatorChoiceByTag2
    global lockFlashEnabledByTagSlot, lockFlashIntervalMsByTagSlot
    global modifierKind, modifierSc, modifierRawPage, modifierRawBytesHex, modifierRawUpBytesHex, modifierMode
    global deviceModifiers, DEVICE_TAGS
    global lvColW1, lvColW2, lvColW3, lvColW4
    global macroLvColW1, macroLvColW2, macroLvColW3, macroLvColW4
    global savedMacros, savedMacroOrder
    global profileOrder
    global failedLoadProfiles
    try {
    if !FileExist(mapFile)
        return
    masterEnabled := IniRead(mapFile, "Settings", "MasterEnabled", "1") = "1"
    startHidden := IniRead(mapFile, "Settings", "StartHidden", "0") = "1"
    longPressMsRaw := IniRead(mapFile, "Settings", "LongPressMs", "500")
    legacyLongPressMs := IsInteger(longPressMsRaw) ? Integer(longPressMsRaw) : 500
    minHoldGapRaw := IniRead(mapFile, "Settings", "MinHoldReleaseGapMs", "100")
    MinHoldReleaseGapMs := IsInteger(minHoldGapRaw) ? Integer(minHoldGapRaw) : 100
    appWatchEnabled := IniRead(mapFile, "Settings", "AppWatchEnabled", "0") = "1"
    legacyNotify := IniRead(mapFile, "Settings", "NotifyModifierToggle", "0") = "1"
    for tag in DEVICE_TAGS
        notifyModifierToggleByTag[tag] := legacyNotify
    legacyScrollLock := IniRead(mapFile, "Settings", "SendScrollLockOnModifierToggle", "0") = "1"
    legacyCapsLock := IniRead(mapFile, "Settings", "SendCapsLockOnModifierToggle", "0") = "1"
    legacyChoice := legacyCapsLock ? "CapsLock" : (legacyScrollLock ? "ScrollLock" : "Off")
    for tag in DEVICE_TAGS {
        ledIndicatorChoiceByTag[tag] := legacyChoice
        ledIndicatorChoiceByTag2[tag] := "Off"
        for lockKey in ["ScrollLock", "CapsLock", "NumLock"] {
            lockFlashEnabledByTagSlot[lockKey][tag][1] := false
            lockFlashIntervalMsByTagSlot[lockKey][tag][1] := 500
            lockFlashEnabledByTagSlot[lockKey][tag][2] := false
            lockFlashIntervalMsByTagSlot[lockKey][tag][2] := 500
        }
    }
    capsLockLedIdxRawLegacy := IniRead(mapFile, "Settings", "CapsLockLedDeviceIndex", "0")
    capsLockLedDeviceIndex := (IsInteger(capsLockLedIdxRawLegacy) && Integer(capsLockLedIdxRawLegacy) >= 0) ? Integer(capsLockLedIdxRawLegacy) : 0
    runElevated := IniRead(mapFile, "Settings", "RunElevated", "0") = "1"
    runAtStartup := IniRead(mapFile, "Settings", "RunAtStartup", "0") = "1"
    runAtStartupMode := IniRead(mapFile, "Settings", "RunAtStartupMode", "shortcut")
    modifierKind := IniRead(mapFile, "Settings", "ModifierKind", "none")
    modifierScRaw := IniRead(mapFile, "Settings", "ModifierSc", "0")
    modifierSc := IsXDigit(modifierScRaw) ? Integer("0x" modifierScRaw) : 0
    modifierRawPageRaw := IniRead(mapFile, "Settings", "ModifierRawPage", "0")
    modifierRawPage := IsXDigit(modifierRawPageRaw) ? Integer("0x" modifierRawPageRaw) : 0
    modifierRawBytesHex := IniRead(mapFile, "Settings", "ModifierRawBytesHex", "")
    modifierRawUpBytesHex := IniRead(mapFile, "Settings", "ModifierRawUpBytesHex", "")
    modifierMode := IniRead(mapFile, "Settings", "ModifierMode", "toggle")
    anyNewModifierSectionPresent := false
    for tag in DEVICE_TAGS {
        if IniRead(mapFile, "Modifier_" tag, "Kind", "") != ""
            anyNewModifierSectionPresent := true
    }
    if !anyNewModifierSectionPresent {
        for tag in DEVICE_TAGS
            deviceModifiers[tag] := {kind: modifierKind, sc: modifierSc, rawPage: modifierRawPage, rawBytesHex: modifierRawBytesHex, rawUpBytesHex: modifierRawUpBytesHex, mode: modifierMode, lpOn: false, lpMs: 500}
    } else {
        for tag in DEVICE_TAGS {
            dmSection := "Modifier_" tag
            dmKind := IniRead(mapFile, dmSection, "Kind", "none")
            dmScRaw := IniRead(mapFile, dmSection, "Sc", "0")
            dmSc := IsXDigit(dmScRaw) ? Integer("0x" dmScRaw) : 0
            dmRawPageRaw := IniRead(mapFile, dmSection, "RawPage", "0")
            dmRawPage := IsXDigit(dmRawPageRaw) ? Integer("0x" dmRawPageRaw) : 0
            dmRawBytesHex := IniRead(mapFile, dmSection, "RawBytesHex", "")
            dmRawUpBytesHex := IniRead(mapFile, dmSection, "RawUpBytesHex", "")
            dmMode := IniRead(mapFile, dmSection, "Mode", "toggle")
            deviceModifiers[tag] := {kind: dmKind, sc: dmSc, rawPage: dmRawPage, rawBytesHex: dmRawBytesHex, rawUpBytesHex: dmRawUpBytesHex, mode: dmMode, lpOn: false, lpMs: 500}
        }
    }
    lvColW1Raw := IniRead(mapFile, "Settings", "LvColW1", lvColW1)
    lvColW1 := IsInteger(lvColW1Raw) ? Integer(lvColW1Raw) : lvColW1
    lvColW2Raw := IniRead(mapFile, "Settings", "LvColW2", lvColW2)
    lvColW2 := IsInteger(lvColW2Raw) ? Integer(lvColW2Raw) : lvColW2
    lvColW3Raw := IniRead(mapFile, "Settings", "LvColW3", lvColW3)
    lvColW3 := IsInteger(lvColW3Raw) ? Integer(lvColW3Raw) : lvColW3
    lvColW4Raw := IniRead(mapFile, "Settings", "LvColW4", lvColW4)
    lvColW4 := IsInteger(lvColW4Raw) ? Integer(lvColW4Raw) : lvColW4
    macroLvColW1Raw := IniRead(mapFile, "Settings", "MacroLvColW1", macroLvColW1)
    macroLvColW1 := IsInteger(macroLvColW1Raw) ? Integer(macroLvColW1Raw) : macroLvColW1
    macroLvColW2Raw := IniRead(mapFile, "Settings", "MacroLvColW2", macroLvColW2)
    macroLvColW2 := IsInteger(macroLvColW2Raw) ? Integer(macroLvColW2Raw) : macroLvColW2
    macroLvColW3Raw := IniRead(mapFile, "Settings", "MacroLvColW3", macroLvColW3)
    macroLvColW3 := IsInteger(macroLvColW3Raw) ? Integer(macroLvColW3Raw) : macroLvColW3
    macroLvColW4Raw := IniRead(mapFile, "Settings", "MacroLvColW4", macroLvColW4)
    macroLvColW4 := IsInteger(macroLvColW4Raw) ? Integer(macroLvColW4Raw) : macroLvColW4

    profiles := Map("Default", {processNames: []})
    profileOrder := []
    migratedDevTabProfiles := []
    failedProfiles := []
    profileNamesCsv := IniRead(mapFile, "Settings", "ProfileNames", "")
    for pname in StrSplit(profileNamesCsv, ",") {
        pname := Trim(pname)
        if pname = "" || pname = "Default"
            continue
        devTab := "Remote"
        try {
        procCsv := IniRead(mapFile, "Profile::" pname, "ProcessNames", "")
        procList := []
        for p in StrSplit(procCsv, ",") {
            p := Trim(p)
            if p != ""
                procList.Push(p)
        }
        modKind := IniRead(mapFile, "Profile::" pname, "ModKind", "none")
        modScRaw := IniRead(mapFile, "Profile::" pname, "ModSc", "0")
        modSc := IsXDigit(modScRaw) ? Integer("0x" modScRaw) : 0
        modRawPageRaw := IniRead(mapFile, "Profile::" pname, "ModRawPage", "0")
        modRawPage := IsXDigit(modRawPageRaw) ? Integer("0x" modRawPageRaw) : 0
        modRawBytesHex := IniRead(mapFile, "Profile::" pname, "ModRawBytesHex", "")
        modMode := IniRead(mapFile, "Profile::" pname, "ModMode", "toggle")
        modRawUpBytesHex := IniRead(mapFile, "Profile::" pname, "ModRawUpBytesHex", "")
        mod2Kind := IniRead(mapFile, "Profile::" pname, "Mod2Kind", "none")
        mod2ScRaw := IniRead(mapFile, "Profile::" pname, "Mod2Sc", "0")
        mod2Sc := IsXDigit(mod2ScRaw) ? Integer("0x" mod2ScRaw) : 0
        mod2RawPageRaw := IniRead(mapFile, "Profile::" pname, "Mod2RawPage", "0")
        mod2RawPage := IsXDigit(mod2RawPageRaw) ? Integer("0x" mod2RawPageRaw) : 0
        mod2RawBytesHex := IniRead(mapFile, "Profile::" pname, "Mod2RawBytesHex", "")
        mod2RawUpBytesHex := IniRead(mapFile, "Profile::" pname, "Mod2RawUpBytesHex", "")
        devTabRaw := IniRead(mapFile, "Profile::" pname, "DevTab", "")
        if HasVal(["Mouse", "Keyboard", "Remote"], devTabRaw) {
            devTab := devTabRaw
        } else {
            migratedDevTabProfiles.Push(pname)
        }
        profiles[ProfileKey(devTab, pname)] := {processNames: procList, modKind: modKind, modSc: modSc, modRawPage: modRawPage, modRawBytesHex: modRawBytesHex, modRawUpBytesHex: modRawUpBytesHex, modMode: modMode, mod2Kind: mod2Kind, mod2Sc: mod2Sc, mod2RawPage: mod2RawPage, mod2RawBytesHex: mod2RawBytesHex, mod2RawUpBytesHex: mod2RawUpBytesHex, modLpOn: false, modLpMs: 500, mod2Mode: "", mod2LpOn: false, mod2LpMs: 500, passthroughMod1: false, passthroughMod2: false, devTab: devTab
            , ledChoice: "Inherit", scrollFlashOn: false, scrollFlashMs: 500, capsFlashOn: false, capsFlashMs: 500, numFlashOn: false, numFlashMs: 500
            , ledChoice2: "Inherit", scrollFlashOn2: false, scrollFlashMs2: 500, capsFlashOn2: false, capsFlashMs2: 500, numFlashOn2: false, numFlashMs2: 500
            , notifyToggle: "Inherit"}
        profileOrder.Push(ProfileKey(devTab, pname))
        } catch as e {
            pkey := ProfileKey(devTab, pname)
            LogWarn("load", "LoadLegacyMappings: " pname " (" mapFile "): " e.Message " (What=" e.What ", Line=" e.Line ")")
            failedProfiles.Push(pname)
            failedLoadProfiles[pkey] := true
            if profiles.Has(pkey)
                profiles.Delete(pkey)
            continue
        }
    }

    savedMacros := Map()
    savedMacroOrder := []
    savedMacroNamesCsv := IniRead(mapFile, "Settings", "SavedMacroNames", "")
    for mname in StrSplit(savedMacroNamesCsv, ",") {
        mname := Trim(mname)
        if mname = ""
            continue
        savedMacroOrder.Push(mname)
        savedMacros[mname] := MacroStepsDecode(IniRead(mapFile, "SavedMacro::" mname, "Steps", ""))
    }

    sections := IniRead(mapFile)
    for section in StrSplit(sections, "`n", "`r") {
        if section = "" || section = "Settings" || SubStr(section, 1, 9) = "Profile::" || SubStr(section, 1, 12) = "SavedMacro::"
            continue
        kind := IniRead(mapFile, section, "Kind", "sc")
        actionType := IniRead(mapFile, section, "ActionType", "key")
        desc := IniRead(mapFile, section, "Desc", section)
        target := IniRead(mapFile, section, "Target", "")
        appArgs := IniRead(mapFile, section, "AppArgs", "")
        enabled := IniRead(mapFile, section, "Enabled", "1") = "1"
        pressType := IniRead(mapFile, section, "PressType", "short")
        listVal := IniRead(mapFile, section, "List", "Main")
        devTabVal := IniRead(mapFile, section, "DevTab", DefaultDevTabForKind(kind))
        runMode := IniRead(mapFile, section, "RunMode", "single")
        repeatMsRaw := IniRead(mapFile, section, "RepeatMs", "100")
        repeatMs := IsInteger(repeatMsRaw) ? Integer(repeatMsRaw) : 100
        delayEnabled := IniRead(mapFile, section, "DelayEnabled", "0") = "1"
        delayMsRaw := IniRead(mapFile, section, "DelayMs", "200")
        delayMs := IsInteger(delayMsRaw) ? Integer(delayMsRaw) : 200
        longPressMsRaw := IniRead(mapFile, section, "LongPressMs", String(legacyLongPressMs))
        longPressMs := IsInteger(longPressMsRaw) ? Integer(longPressMsRaw) : legacyLongPressMs
        macroSteps := actionType = "macro" ? MacroStepsDecode(IniRead(mapFile, section, "MacroSteps", "")) : []
        macroName := (actionType = "macro") ? FindSavedMacroNameForSteps(macroSteps) : ""
        profileVal := IniRead(mapFile, section, "Profile", "")
        if target = "" && actionType != "macro"
            continue
        isLegacy := profileVal = ""
        mProfile := isLegacy ? "Default" : profileVal
        id := UniqueMappingId(isLegacy ? ("Default::" section) : section)
        ownerKey := ""
        for pk in profiles {
            if ProfileKeyName(pk) = mProfile {
                ownerKey := pk
                break
            }
        }
        if ownerKey = "" {
            ownerKey := ProfileKey(devTabVal, mProfile)
            profiles[ownerKey] := {processNames: [], modKind: "none", modSc: 0, modRawPage: 0, modRawBytesHex: "", modRawUpBytesHex: "", modMode: "toggle", mod2Kind: "none", mod2Sc: 0, mod2RawPage: 0, mod2RawBytesHex: "", mod2RawUpBytesHex: "", modLpOn: false, modLpMs: 500, mod2Mode: "", mod2LpOn: false, mod2LpMs: 500, passthroughMod1: false, passthroughMod2: false, devTab: devTabVal
                , ledChoice: "Inherit", scrollFlashOn: false, scrollFlashMs: 500, capsFlashOn: false, capsFlashMs: 500, numFlashOn: false, numFlashMs: 500
                , ledChoice2: "Inherit", scrollFlashOn2: false, scrollFlashMs2: 500, capsFlashOn2: false, capsFlashMs2: 500, numFlashOn2: false, numFlashMs2: 500
                , notifyToggle: "Inherit"}
            profileOrder.Push(ownerKey)
            migratedDevTabProfiles.Push(mProfile)
        }
        ownerTab := ProfileKeyTab(ownerKey)
        if ownerTab != "" && devTabVal != ownerTab
            devTabVal := ownerTab
        if kind = "raw" {
            pageRaw := IniRead(mapFile, section, "Page", "0")
            page := IsInteger(pageRaw) ? Integer(pageRaw) : 0
            bytesHex := IniRead(mapFile, section, "BytesHex", "")
            upBytesHex := IniRead(mapFile, section, "UpBytesHex", "")
            if upBytesHex = "" {
                pressType := "short"
                runMode := "single"
            }
            stdMouseButton := StdMouseButtonFromRawReport(page, bytesHex)
            if stdMouseButton != "" {
                mappings[id] := {profile: mProfile, kind: "mouse", actionType: actionType, button: stdMouseButton, desc: desc, target: target, appArgs: appArgs, macroSteps: macroSteps, macroName: macroName, enabled: enabled, pressType: pressType, runMode: runMode, repeatMs: repeatMs, delayEnabled: delayEnabled, delayMs: delayMs, longPressMs: longPressMs, list: listVal, devTab: devTabVal}
            } else {
                mappings[id] := {profile: mProfile, kind: "raw", actionType: actionType, page: page, bytesHex: bytesHex, upBytesHex: upBytesHex, desc: desc, target: target, appArgs: appArgs, macroSteps: macroSteps, macroName: macroName, enabled: enabled, pressType: pressType, runMode: runMode, repeatMs: repeatMs, delayEnabled: delayEnabled, delayMs: delayMs, longPressMs: longPressMs, list: listVal, devTab: devTabVal}
            }
            mapOrder.Push(id)
        } else if kind = "mouse" {
            buttonName := IniRead(mapFile, section, "Button", "")
            if buttonName = "" {
                base := section
                hashPos := InStr(base, "#")
                if hashPos
                    base := SubStr(base, 1, hashPos - 1)
                if IsMouseButtonKey(base)
                    buttonName := base
            }
            if buttonName != "" {
                mappings[id] := {profile: mProfile, kind: "mouse", actionType: actionType, button: buttonName, desc: desc, target: target, appArgs: appArgs, macroSteps: macroSteps, macroName: macroName, enabled: enabled, pressType: pressType, runMode: runMode, repeatMs: repeatMs, delayEnabled: delayEnabled, delayMs: delayMs, longPressMs: longPressMs, list: listVal, devTab: devTabVal}
                mapOrder.Push(id)
            }
        } else {
            scHexStr := IniRead(mapFile, section, "ScHex", "")
            if scHexStr = "" {
                base := section
                hashPos := InStr(base, "#")
                if hashPos
                    base := SubStr(base, 1, hashPos - 1)
                scHexStr := SubStr(base, 3)
            }
            sc := IsXDigit(scHexStr) ? Integer("0x" scHexStr) : 0
            mappings[id] := {profile: mProfile, kind: "sc", actionType: actionType, sc: sc, desc: desc, target: target, appArgs: appArgs, macroSteps: macroSteps, macroName: macroName, enabled: enabled, pressType: pressType, runMode: runMode, repeatMs: repeatMs, delayEnabled: delayEnabled, delayMs: delayMs, longPressMs: longPressMs, list: listVal, devTab: devTabVal}
            mapOrder.Push(id)
            RegisterHotkeyForButton(Format("SC{:03X}", sc))
        }
    }
    if failedProfiles.Length {
        msg := failedProfiles.Length " profile(s) could not be read and were skipped - the rest of your profiles loaded normally:`n`n"
        for pname in failedProfiles
            msg .= "- " pname "`n"
        msg .= "`nThe file on disk was not touched. Fix or remove the affected section(s) and restart to try loading them again."
        MsgBox(msg, "Some profiles could not be loaded", "Icon!")
    }
    if migratedDevTabProfiles.Length {
        msg := "The following profile(s) predate the per-profile device tag feature and had no tag saved. They've been defaulted to 'Remote' - open each one and re-tag it if it should be Mouse or Keyboard instead:`n`n"
        for pname in migratedDevTabProfiles
            msg .= "- " pname "`n"
        MsgBox(msg, "Profiles defaulted to Remote", "Icon!")
    }
    } catch as e {
        legacyLoadFailed := true
        LogWarn("load", mapFile ": " e.Message " (What=" e.What ", Line=" e.Line ")")
        MsgBox("The legacy configuration could not be fully loaded from:`n" mapFile "`n`n"
            . "Reason: " e.Message "`n`n"
            . "Only part of it was read. Saving has been disabled for this session so the "
            . "existing file is not overwritten with an incomplete migration.`n`n"
            . "Close the app, fix or remove the file above, then start it again."
            , "MF Button Mapper - Load Error", "Icon!")
    }
}

MarkLegacyMigrationComplete() {
    try {
        IniWrite("1", SettingsFile(), "Settings", "MigratedFromLegacy")
    } catch as e {
        LogWarn("load", "MarkLegacyMigrationComplete: flag write failed: " e.Message)
    }
    try {
        if FileExist(mapFile)
            FileMove(mapFile, mapFile ".migrated", 1)
    } catch as e {
        LogWarn("load", "MarkLegacyMigrationComplete: rename of " mapFile " failed: " e.Message)
    }
}
