
InstallMouseHook() {
    global mouseHookHandle, mouseHookProcPtr, WH_MOUSE_LL
    if mouseHookHandle
        return true
    mouseHookProcPtr := CallbackCreate(MouseHookProc, "F", 3)
    if !mouseHookProcPtr {
        MsgBox("Could not create the mouse hook callback.", "Mouse hook error", "Icon!")
        return false
    }
    mouseHookHandle := DllCall("SetWindowsHookEx", "int", WH_MOUSE_LL, "ptr", mouseHookProcPtr, "ptr", 0, "uint", 0, "ptr")
    if !mouseHookHandle {
        MsgBox("Could not install the low-level mouse hook (LastError " A_LastError ").", "Mouse hook error", "Icon!")
        CallbackFree(mouseHookProcPtr)
        mouseHookProcPtr := 0
        return false
    }
    return true
}

MouseHookProc(nCode, wParam, lParam) {
    global mouseHookHandle, WM_MOUSEMOVE, WM_LBUTTONDOWN, WM_LBUTTONUP,
        WM_RBUTTONDOWN, WM_RBUTTONUP, WM_MBUTTONDOWN, WM_MBUTTONUP,
        WM_MOUSEWHEEL, WM_MOUSEHWHEEL, WM_XBUTTONDOWN, WM_XBUTTONUP,
        LLMHF_INJECTED, mouseCaptureArmed, mouseSwallowedDown, modMouseCaptureArmed, mouseModSwallowed
    tHookStart := QpcNow()
    try {
    if nCode < 0
        return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)
    RecordMouseHookQueueWait(A_TickCount - NumGet(lParam, 16, "UInt"))
    if wParam = WM_MOUSEMOVE
        return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)

    flags := NumGet(lParam, 12, "UInt")
    if (flags & LLMHF_INJECTED)
        return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)

    mouseData := NumGet(lParam, 8, "UInt")
    buttonKey := ""
    actionWord := ""
    wheelDelta := 0
    switch wParam {
        case WM_LBUTTONDOWN:
            buttonKey := "LButton", actionWord := "down"
        case WM_LBUTTONUP:
            buttonKey := "LButton", actionWord := "up"
        case WM_RBUTTONDOWN:
            buttonKey := "RButton", actionWord := "down"
        case WM_RBUTTONUP:
            buttonKey := "RButton", actionWord := "up"
        case WM_MBUTTONDOWN:
            buttonKey := "MButton", actionWord := "down"
        case WM_MBUTTONUP:
            buttonKey := "MButton", actionWord := "up"
        case WM_XBUTTONDOWN, WM_XBUTTONUP:
            xButtonNum := (mouseData >> 16) & 0xFFFF
            buttonKey := xButtonNum = 2 ? "XButton2" : "XButton1"
            actionWord := wParam = WM_XBUTTONDOWN ? "down" : "up"
        case WM_MOUSEWHEEL:
            delta := (mouseData >> 16) & 0xFFFF
            if delta > 32767
                delta -= 65536
            if delta = 0
                return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)
            wheelDelta := delta
            buttonKey := delta > 0 ? "WheelUp" : "WheelDown"
            actionWord := "notch (" delta ")"
        case WM_MOUSEHWHEEL:
            delta := (mouseData >> 16) & 0xFFFF
            if delta > 32767
                delta -= 65536
            if delta = 0
                return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)
            wheelDelta := delta
            buttonKey := delta > 0 ? "WheelRight" : "WheelLeft"
            actionWord := "notch (" delta ")"
        default:
            return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)
    }

    isWheel := SubStr(buttonKey, 1, 5) = "Wheel"

    if mouseCaptureArmed && (actionWord = "down" || isWheel) {
        mouseCaptureArmed := false
        SetTimer(OnMouseButtonCaptured.Bind(buttonKey), -1)
        return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)
    }

    if modMouseCaptureArmed && (actionWord = "down" || isWheel) {
        modMouseCaptureArmed := false
        SetTimer(DispatchModifierMouseCapture.Bind(buttonKey), -1)
        return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)
    }

    if actionWord = "up" {
        if mouseSwallowedDown.Has(buttonKey) {
            mouseSwallowedDown.Delete(buttonKey)
            QueueMouseDispatch(buttonKey, false)
            return 1
        }
        if mouseModSwallowed.Has(buttonKey) {
            modRoles := mouseModSwallowed[buttonKey]
            mouseModSwallowed.Delete(buttonKey)
            QueueMouseDispatch(buttonKey, false, modRoles)
            return 1
        }
        return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)
    }

    if !isWheel && mouseModSwallowed.Has(buttonKey)
        mouseModSwallowed.Delete(buttonKey)
    if MouseHookEventShouldBlock(buttonKey, lParam) {
        if isWheel {
            wheelAxis := (buttonKey = "WheelUp" || buttonKey = "WheelDown") ? "V" : "H"
            Loop WheelNotchesForDelta(wheelAxis, wheelDelta) {
                QueueMouseDispatch(buttonKey, true)
                QueueMouseDispatch(buttonKey, false)
            }
        } else {
            mouseSwallowedDown[buttonKey] := true
            QueueMouseDispatch(buttonKey, true)
        }
        return 1
    }
    if !isWheel {
        modRoles := MouseModifierSwallowRoles(buttonKey, lParam)
        if modRoles.Length {
            mouseModSwallowed[buttonKey] := modRoles
            QueueMouseDispatch(buttonKey, true, modRoles)
            return 1
        }
    }
    if !isWheel && mouseSwallowedDown.Has(buttonKey)
        mouseSwallowedDown.Delete(buttonKey)

    return DllCall("CallNextHookEx", "ptr", 0, "int", nCode, "ptr", wParam, "ptr", lParam)
    } finally {
        RecordMouseHookLatency(tHookStart)
    }
}

MouseHookEventShouldBlock(buttonKey, lParam) {
    if !MouseButtonShouldBlock(buttonKey)
        return false
    if (buttonKey = "LButton" || buttonKey = "RButton") && MouseEventOverOwnProcess(lParam)
        return false
    return true
}

QueueMouseDispatch(buttonKey, isDown, roles := "") {
    global mouseDispatchSeq
    mouseDispatchSeq += 1
    SetTimer(MouseDispatch.Bind({seq: mouseDispatchSeq, key: buttonKey, isDown: isDown, roles: roles, t: A_TickCount}), -1)
}

MouseDispatch(ev) {
    global mouseDispatchNextSeq, MOUSE_DISPATCH_STALL_MS, mouseDownInFlight
    if ev.seq != mouseDispatchNextSeq {
        if ev.seq < mouseDispatchNextSeq
            return
        if Abs(A_TickCount - ev.t) <= MOUSE_DISPATCH_STALL_MS {
            SetTimer(MouseDispatch.Bind(ev), -1)
            return
        }
        mouseDispatchNextSeq := ev.seq
    }
    mouseDispatchNextSeq += 1
    if IsObject(ev.roles) {
        ModSwallowedDispatch(ev.key, ev.isDown, ev.roles)
        return
    }
    if !ev.isDown && mouseDownInFlight.Has(ev.key) && mouseDownInFlight[ev.key] {
        SetTimer(MouseDispatchDeferredUp.Bind(ev), -1)
        return
    }
    if ev.isDown {
        mouseDownInFlight[ev.key] := true
        try
            OnButtonDown(ev.key, "mouse")
        finally
            mouseDownInFlight[ev.key] := false
    } else
        OnButtonUp(ev.key, "mouse")
}

MouseDispatchDeferredUp(ev) {
    global mouseDownInFlight, MOUSE_DISPATCH_STALL_MS
    if mouseDownInFlight.Has(ev.key) && mouseDownInFlight[ev.key] && Abs(A_TickCount - ev.t) <= MOUSE_DISPATCH_STALL_MS {
        SetTimer(MouseDispatchDeferredUp.Bind(ev), -1)
        return
    }
    OnButtonUp(ev.key, "mouse")
}

MouseModifierSwallowRoles(buttonKey, lParam) {
    global masterEnabled, mouseBlockDecisionCache, mouseBlockCacheDirty
    if !masterEnabled || A_IsSuspended
        return []
    if mouseBlockCacheDirty
        RebuildMouseBlockDecisionCache()
    roles := mouseBlockDecisionCache.Has(buttonKey) ? mouseBlockDecisionCache[buttonKey].modRoles : []
    if roles.Length && (buttonKey = "LButton" || buttonKey = "RButton") && MouseEventOverOwnProcess(lParam)
        return []
    return roles
}
