
FireButtonMappings(buttonKey, pressType, kind := "sc", candidateIds := "") {
    if !IsObject(candidateIds)
        candidateIds := MatchingMappingIds(buttonKey, kind)
    for id in candidateIds {
        m := mappings[id]
        if MapRunMode(m) != "single"
            continue
        mPressType := MapPressType(m)
        if mPressType != pressType
            continue
        FireMapping(m)
    }
}

StartRepeat(id) {
    global repeatActive, repeatTimerFns, repeatPendingHoldUp, mappings
    if repeatActive.Has(id) && repeatActive[id]
        return
    if !mappings.Has(id)
        return
    m := mappings[id]
    repeatActive[id] := true
    AcquireHighResTimer()
    isTypematic := MapRunMode(m) = "typematic"
    delayMs := MapDelayEnabled(m) ? (m.HasOwnProp("delayMs") ? Max(0, m.delayMs) : 0) : 0
    if delayMs > 0 && (MapActionType(m)) = "key" && !IsCursorSpeedTarget(m.target) {
        strs := BuildHoldSendStrings(m.target)
        repeatPendingHoldUp[id] := strs.up
        Send(strs.down)
        delayFn := () => BeginRepeatTimer(id)
        repeatTimerFns[id] := delayFn
        SetTimer(delayFn, -delayMs)
    } else if delayMs > 0 {
        FireMapping(m)
        delayFn := () => BeginRepeatTimer(id)
        repeatTimerFns[id] := delayFn
        SetTimer(delayFn, -delayMs)
    } else if isTypematic && (MapActionType(m)) = "key" && !IsCursorSpeedTarget(m.target) {
        strs := BuildHoldSendStrings(m.target)
        repeatPendingHoldUp[id] := strs.up
        Send(strs.down)
        BeginRepeatTimer(id)
    } else {
        FireMapping(m)
        BeginRepeatTimer(id)
    }
}

BeginRepeatTimer(id) {
    global repeatActive, repeatTimerFns, repeatStartQpc, repeatFireCount, repeatPendingHoldUp, mappings
    if !repeatActive.Has(id) || !repeatActive[id]
        return
    if !mappings.Has(id)
        return
    m := mappings[id]
    isTypematic := MapRunMode(m) = "typematic"
    if !isTypematic && repeatPendingHoldUp.Has(id) {
        Send(repeatPendingHoldUp[id])
        repeatPendingHoldUp.Delete(id)
    }
    ms := MapRepeatMs(m)
    if ms < 1
        ms := 1
    fn := () => RepeatTick(id)
    repeatTimerFns[id] := fn
    repeatStartQpc[id] := QpcNow()
    repeatFireCount[id] := 1
    ScheduleNextRepeatTick(id, ms)
}

RepeatTick(id) {
    global mappings, repeatActive, repeatStartQpc, repeatFireCount
    if !repeatActive.Has(id) || !repeatActive[id] || !repeatStartQpc.Has(id) || !repeatFireCount.Has(id)
        return
    if !mappings.Has(id) || !mappings[id].enabled {
        StopRepeat(id)
        return
    }
    m := mappings[id]
    ms := MapRepeatMs(m)
    if ms < 1
        ms := 1
    elapsedMs := (QpcNow() - repeatStartQpc[id]) * 1000 / QpcFreq()
    expected := Floor(elapsedMs / ms) + 1
    loopCount := Min(expected - repeatFireCount[id], 50)
    isTypematicKey := (MapRunMode(m) = "typematic") && (MapActionType(m)) = "key" && !IsCursorSpeedTarget(m.target)
    downStr := isTypematicKey ? BuildHoldSendStrings(m.target).down : ""
    loop loopCount {
        if !repeatActive.Has(id) || !repeatActive[id] || !repeatFireCount.Has(id)
            return
        if isTypematicKey
            Send(downStr)
        else
            FireMapping(m)
        if !repeatFireCount.Has(id)
            return
        repeatFireCount[id] += 1
    }
    ScheduleNextRepeatTick(id, ms)
}

StopRepeat(id) {
    global repeatActive, repeatTimerFns, repeatStartQpc, repeatFireCount, repeatPendingHoldUp
    wasActive := repeatActive.Has(id) && repeatActive[id]
    if repeatTimerFns.Has(id) {
        SetTimer(repeatTimerFns[id], 0)
        repeatTimerFns.Delete(id)
    }
    if repeatPendingHoldUp.Has(id) {
        Send(repeatPendingHoldUp[id])
        repeatPendingHoldUp.Delete(id)
    }
    if repeatStartQpc.Has(id)
        repeatStartQpc.Delete(id)
    if repeatFireCount.Has(id)
        repeatFireCount.Delete(id)
    if repeatActive.Has(id)
        repeatActive.Delete(id)
    if wasActive
        ReleaseHighResTimer()
}

SPGuardStart() {
    SPGuardStartDesktopSwitchWatch()
    SPGuardStartWtsWatch()
    OnExit(SPGuardOnExit)
}

SPGuardStartDesktopSwitchWatch() {
    global spDesktopSwitchHook, spDesktopSwitchCallback, spGuardStatus
    static EVENT_SYSTEM_DESKTOPSWITCH := 0x0020
    static WINEVENT_OUTOFCONTEXT := 0x0000
    static WINEVENT_SKIPOWNPROCESS := 0x0002
    if spDesktopSwitchHook
        return true
    try {
        spDesktopSwitchCallback := CallbackCreate(SPGuardDesktopSwitchProc, "", 7)
        spDesktopSwitchHook := DllCall("SetWinEventHook"
            , "UInt", EVENT_SYSTEM_DESKTOPSWITCH
            , "UInt", EVENT_SYSTEM_DESKTOPSWITCH
            , "Ptr", 0
            , "Ptr", spDesktopSwitchCallback
            , "UInt", 0
            , "UInt", 0
            , "UInt", WINEVENT_OUTOFCONTEXT | WINEVENT_SKIPOWNPROCESS
            , "Ptr")
        if !spDesktopSwitchHook
            LogWarn("spguard", "SetWinEventHook returned NULL - desktop-switch guard inactive. A_LastError=" A_LastError)
        else
            spGuardStatus.desktopHook := true
    } catch as e {
        LogWarn("spguard", "SetWinEventHook threw: " e.Message " A_LastError=" A_LastError)
    }
}

SPGuardDesktopSwitchProc(hWinEventHook, event, hwnd, idObject, idChild, dwEventThread, dwmsEventTime) {
    SetTimer(SPGuardRun, -1)
}

SPGuardStartWtsWatch() {
    global spGuardStatus
    static NOTIFY_FOR_THIS_SESSION := 0
    static WM_WTSSESSION_CHANGE := 0x02B1
    try {
        ok := DllCall("wtsapi32\WTSRegisterSessionNotification", "Ptr", A_ScriptHwnd, "UInt", NOTIFY_FOR_THIS_SESSION, "Int")
        if ok {
            OnMessage(WM_WTSSESSION_CHANGE, SPGuardOnWtsSessionChange)
            spGuardStatus.wtsNotify := true
        } else {
            LogWarn("spguard", "WTSRegisterSessionNotification returned 0 - session-change guard inactive. A_LastError=" A_LastError)
        }
    } catch as e {
        LogWarn("spguard", "WTSRegisterSessionNotification threw: " e.Message " A_LastError=" A_LastError)
    }
}

SPGuardOnWtsSessionChange(wParam, lParam, msg, hwnd) {
    SetTimer(SPGuardRun, -1)
    return 0
}

SPGuardOnExit(exitReason, exitCode) {
    global spDesktopSwitchHook, spDesktopSwitchCallback
    try DllCall("wtsapi32\WTSUnRegisterSessionNotification", "Ptr", A_ScriptHwnd)
    if spDesktopSwitchHook {
        try DllCall("UnhookWinEvent", "Ptr", spDesktopSwitchHook)
        spDesktopSwitchHook := 0
    }
    if spDesktopSwitchCallback {
        CallbackFree(spDesktopSwitchCallback)
        spDesktopSwitchCallback := 0
    }
    return 0
}

SPGuardIsHeldDriven(id) {
    global mappings
    if !mappings.Has(id)
        return true
    m := mappings[id]
    rm := MapRunMode(m)
    return rm = "repeat" || rm = "typematic" || rm = "hold"
}

SPGuardRun() {
    global repeatActive, repeatTimerFns, heldMappings, mappings, buttonPressState
    Critical
    name := SPGuardCurrentDesktopName()
    onDefault := (name = "Default")
    if !onDefault {
        for id, isOn in repeatActive {
            if !isOn || !repeatTimerFns.Has(id) || !SPGuardIsHeldDriven(id)
                continue
            SetTimer(repeatTimerFns[id], 0)
            repeatTimerFns.Delete(id)
        }
    } else {
        buttons := Map()
        for id, isOn in repeatActive.Clone() {
            if !isOn || !SPGuardIsHeldDriven(id)
                continue
            if mappings.Has(id)
                buttons[MappingButtonKey(mappings[id])] := true
            StopRepeat(id)
        }
        for id, upStr in heldMappings.Clone() {
            if !SPGuardIsHeldDriven(id)
                continue
            if mappings.Has(id)
                buttons[MappingButtonKey(mappings[id])] := true
            Send(upStr)
            heldMappings.Delete(id)
        }
        for bk, unused in buttons {
            if buttonPressState.Has(bk)
                buttonPressState[bk].pressed := false
        }
    }
}

SPGuardCurrentDesktopName() {
    static DESKTOP_READOBJECTS := 0x0001
    static UOI_NAME := 2
    name := "?"
    try {
        hDesk := DllCall("OpenInputDesktop", "UInt", 0, "Int", 0, "UInt", DESKTOP_READOBJECTS, "Ptr")
        if hDesk {
            buf := Buffer(256, 0)
            if DllCall("GetUserObjectInformationW", "Ptr", hDesk, "Int", UOI_NAME, "Ptr", buf, "UInt", 256, "UInt*", &needed := 0)
                name := StrGet(buf, "UTF-16")
            DllCall("CloseDesktop", "Ptr", hDesk)
        }
    }
    return name
}

FireMapping(m) {
    actionType := MapActionType(m)
    if actionType = "app"
        LaunchApp(m.target, MapAppArgs(m))
    else if actionType = "macro"
        RunMacroOnce(ResolveMacroSteps(m))
    else if actionType = "ps"
        RunPsScript(m.target, MapHideWindow(m))
    else if actionType = "cmd"
        RunCmdScript(m.target, MapHideWindow(m))
    else if IsCursorSpeedTarget(m.target)
        RunCursorSpeedTarget(m.target)
    else
        Send(m.target)
}

RunMacroOnce(steps) {
    AcquireHighResTimer()
    try {
        for s in steps {
            if s.type = "key"
                Send(s.target)
            else if s.type = "keydown"
                Send(BuildHoldSendStrings(s.target).down)
            else if s.type = "keyup"
                Send(BuildHoldSendStrings(s.target).up)
            else if s.type = "app"
                LaunchApp(s.target, s.HasOwnProp("args") ? s.args : "")
            if s.delayAfterMs > 0
                Sleep(s.delayAfterMs)
        }
    } finally {
        ReleaseHighResTimer()
    }
}
